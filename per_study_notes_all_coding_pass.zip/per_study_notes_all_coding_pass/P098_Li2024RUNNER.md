# P098 — Li2024RUNNER

Acceptance criteria stated: No
Citation: Li, Tianlin, Yue Cao, Jian Zhang, Shiqian Zhao, Yihao Huang, Aishan Liu, Qing Guo, and Yang Liu. "RUNNER: Responsible UNfair NEuron Repair for Enhancing Deep Neural Network Fairness." In Proceedings of the 46th IEEE/ACM International Conference on Software Engineering (ICSE ’24), April 14–20, 2024, Lisbon, Portugal. ACM, 13 pages. https://doi.org/10.1145/3597503.3623334
DES content: Yes
DES snippet: Proposes RUNNER, a two-phase diagnosis+repair framework: (1) Importance-based Neuron Diagnosis identifies responsible unfair neurons in one step using a Taylor-approximated unfairness-importance score based on gradients of relaxed fairness gaps (GapDP/GapEO); (2) Neuron Stabilizing Retraining adds a loss term that penalizes subgroup activation-distance of those neurons; uses an iterative diagnose–retrain loop.
Data Type: Multi-modal
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: Frames unfairness of DNNs as a social concern for high-stakes applications (loan approval, criminal risk assessment) and positions fairness alongside robustness/privacy as key properties that limit deep learning usability; criticizes prior adversary-based repair as computationally expensive and black-box for developers.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other, Unstable subgroup definitions
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides an efficient, interpretable diagnosis+repair loop for improving group fairness in DNNs (neuron-importance localization + activation-stabilizing retraining) validated on tabular and image datasets, but does not define acceptance thresholds/decision rules for “fair enough” nor any post-deployment monitoring and revision governance.
Governance maturity: Absent
Measurement procedure: Defines ΔDP and ΔEO; for diagnosis, computes neuron unfairness importance UI^l_m ≈ (∂GapDP/EO/∂w^l_m · w^l_m)^2 via first-order Taylor expansion, selects top-k neurons per layer. For repair, adds neuron-stabilizing loss term λ·Σ_{selected neurons} L1 distance between expected activations across sensitive subgroups (and conditioned on y for EO). Runs iterative diagnose+retrain; evaluates on multiple random splits and reports mean±std for AP/ACC and fairness metrics; compares to baselines (vanilla, oversample, reweighing, adversarial, FairNeuron, FairSmote, ROC).
Metrics used: Fairness: ΔDP (demographic parity) and ΔEO (equalized odds: |TPR_a=0−TPR_a=1| + |FPR_a=0−FPR_a=1|). Optimization surrogates: GapDP and GapEO (expectation gaps) for gradient-based neuron importance and loss. Accuracy: Average Precision (AP) and Accuracy (ACC). Efficiency: time cost (seconds) and epochs.
Monitoring present: No
Notes: White-box method requiring model access (gradients). Focuses on group fairness; discusses inherent trade-off between ΔDP and ΔEO and optimizes them separately. Provides code repo: https://github.com/Ace0001/RUNNER
Operationalization present: Yes
Protected attrs / groups: Binary sensitive attribute a∈{0,1} (examples: gender; also mentions race for COMPAS context). Uses four EO subgroups split by (a,y) for ΔEO training. Datasets include Adult (gender), COMPAS (race/gender context), Credit (gender), LSAC (gender), CelebA (gender groups for face attributes).
QA notes: Clear technical objective (efficient unfair-neuron diagnosis + effective fairness repair) and detailed method with explicit fairness metrics (ΔDP/ΔEO) and optimization surrogates (GapDP/GapEO). Strong offline evaluation across 5 datasets including CelebA and includes efficiency + hyperparameter analysis. Notes threats to validity and limitations (datasets/models; white-box access). Does not include stakeholder elicitation or deployment-time monitoring/acceptance criteria.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Treats discrimination against protected groups (e.g., gender, race) as harmful in domains like criminal justice and lending; focuses on group fairness as prevalent and hard to repair, and aims for parity of prediction quality across protected groups.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines group-fairness evaluation metrics ΔDP (demographic parity difference) and ΔEO (equalized odds difference as ΔTPR+ΔFPR), and uses relaxed counterparts GapDP/GapEO to enable backprop-based neuron-importance scoring; fairness improvement objective is to reduce ΔDP/ΔEO toward 0 while maintaining accuracy/AP.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Study ID: P098
System Type: Classification
Threshold value: Hyperparameter k controls fraction/number of neurons selected (tested at 5%, 10%, 20%, 50%). Uses λ as fairness-loss weight; aims for ΔDP/ΔEO close to 0 but no explicit acceptance threshold is prescribed.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates on 5 datasets (Adult, COMPAS, Credit, LSAC, CelebA) across tabular + high-resolution images; reports fairness gains (up to 79.3% improvement) and efficiency gains (e.g., diagnosis overhead reduced vs FairNeuron) and includes hyperparameter sensitivity analysis for k.
Validation/testing present: Yes
Venue Type: Conference
Year: 2024