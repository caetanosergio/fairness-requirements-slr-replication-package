# P036 — Creager2019

Acceptance criteria stated: No
Citation: Creager2019
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes Flexibly Fair VAE (FFVAE) to learn representations that can be modified at test time (discard/noise sensitive latent dimensions) to achieve subgroup demographic parity across multiple sensitive attributes and their conjunctions; defines desiderata via independence constraints among latent subspaces and predictiveness MI alignment between sensitive attributes and designated latent dimensions.
Data Type: Multi-modal
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates fairness as avoiding discriminatory behavior in high-stakes domains (law, finance, medicine) and notes legal/ethical constraints and practical/legal barriers to collecting sensitive attributes, motivating methods that can reduce discrimination even when sensitive attributes are unavailable at inference time.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Other, Outcome parity
Gap summary (1 sentence): Provides a formal, testable operationalization of multi-attribute subgroup demographic parity via flexibly fair representations and offline audits, but does not address sociotechnical governance, deployment-time monitoring, or how fairness validity is maintained under distribution shift.
Governance maturity: Absent
Measurement procedure: Train encoder FFVAE using multiple sensitive attributes at training time; at audit/test time, modify representation by dropping/noising sensitive latent dimensions to enforce subgroup demographic parity; evaluate via auditing scheme on held-out data: train downstream MLP on modified representation to predict held-out label y and report accuracy–DP trade-offs across groups and conjunctions; compare to baselines (β-VAE, FactorVAE, CVAE variants).
Metrics used: Demographic parity distance (DP) for group/subgroup fairness; accuracy vs DP Pareto fronts in audits; disentanglement and predictiveness audits via classifiers to test whether sensitive attribute can be predicted from designated latent b_i and not from the remainder; uses held-out labels y for downstream tasks (e.g., XPosition, violentCrimesPerCapita, HeavyMakeup).
Monitoring present: No
Notes: Mark as multi-modal because evaluated on both tabular and image datasets. Note that fairness notion is primarily outcome parity (DP), not error parity. Highlights test-time adaptation without requiring sensitive attributes (useful in legally constrained settings).
Operationalization present: Yes
Protected attrs / groups: Multiple sensitive attributes a (binary vector) and their intersections/subgroups. Experiments use (i) DSpritesUnfair: sensitive attributes Shape and Scale; (ii) Communities & Crime: racePctBlack, blackPerCapIncome, pctNotSpeakEnglWell; (iii) CelebA: Chubby, Eyeglasses, Male.
QA notes: Technical contribution: multi-attribute/subgroup fair representation learning with compositional test-time adaptation; clear formalization of demographic parity and auditing-based measurement. Strong RQ2 (operationalization) but limited on ENV/SOC: no stakeholder elicitation, governance, monitoring, or revision mechanisms; acknowledges distribution shift robustness as future work.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: No
SOC explicit requirement: Unclear
Spec explicitness/testability: Explicit + testable
Spec snippet: Fairness criterion is demographic parity (ŷ ⟂ a). Uses demographic parity distance DP = |E[ŷ=1|a=1] − E[ŷ=1|a=0]|, and extends to multi-attribute/subgroup fairness by requiring independence w.r.t. each sensitive attribute and conjunctions; enables compositional adaptation by removing the corresponding latent dimensions {b_j}.
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P036
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Empirical evaluation on synthetic DSpritesUnfair plus real datasets Communities & Crime (tabular) and CelebA (images), reporting fairness–accuracy trade-offs across multiple sensitive attributes and subgroups.
Validation/testing present: Yes
Venue Type: Conference
Year: 2019