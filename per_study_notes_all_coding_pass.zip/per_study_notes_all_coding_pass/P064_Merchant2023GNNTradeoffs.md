# P064 — Merchant2023GNNTradeoffs

Acceptance criteria stated: No
Citation: Merchant2023GNNTradeoffs
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines a standardized benchmarking setup for fairness–accuracy tradeoffs in GNN node classification and proposes two GNN-agnostic interventions: PFR-AX (pre-processing debiasing of attributes + adjacency via PFR + DeepWalk + graph reconstruction) and PostProcess (post-processing policy flipping a γ-fraction of protected nodes predicted negative). Evaluates across 4 datasets and 3 GNN backbones (GCN, GraphSAGE, GIN) using AUC-ROC and fairness metrics (ΔSP, ΔEO).
Data Type: Other
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates fairness in high-risk applications of GNNs (e.g., credit risk, crime forecasting) where sensitive attributes indicate protected demographic membership and biased predictions can cause systematic disadvantage; notes adjacency can act as an indirect proxy and propagate bias via message passing.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides explicit, testable fairness operationalization for GNN node classification (ΔSP/ΔEO) and shows mitigation tradeoffs via pre- and post-processing interventions, but it is evaluation/benchmarking-focused with no stakeholder elicitation, no explicit acceptance thresholds for deployment, and no monitoring/revision governance for long-term validity.
Governance maturity: Absent
Measurement procedure: Defines ΔSP and ΔEO formally; evaluates interventions by training GNN backbones on stratified train/val/test splits and measuring AUC-ROC vs ΔSP/ΔEO. PFR-AX: apply PFR to node attributes and to DeepWalk embeddings, then reconstruct debiased graph (EmbeddingReverser) to preserve degree distribution; train GNN on debiased data. PostProcess: identify protected nodes predicted negative, flip a γ fraction to positive (do-no-harm policy) and set scores to MAX-SCORE; sweep γ and smooth over multiple trials. Compare against baselines (Unaware, EDITS, NIFTY) and report runtime.
Metrics used: Accuracy: AUC-ROC (and F1 at threshold 0 in description). Fairness: Statistical Disparity ΔSP (difference in positive prediction rates across protected vs non-protected) and Inequal Opportunity ΔEO (difference in true positive rates across groups). Reports tradeoff plots across interventions/backbones/datasets; analyzes model confidence (logit density) effects.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Binary sensitive attribute on nodes indicating protected demographic membership. Datasets: German (gender), Credit (age), Penn94 (gender), Pokec-z (region). Protected class indicated by s=1, non-protected by s=0.
QA notes: CIKM’23 paper benchmarks fairness–accuracy tradeoffs for GNN node classification using ΔSP (statistical disparity) and ΔEO (inequal opportunity) and proposes two model-agnostic interventions: PFR-AX (pre-processing debiasing of attributes+adjacency) and PostProcess (γ-controlled do-no-harm post-processing by flipping some protected negatives). Strong operationalization and empirical study; lacks stakeholder elicitation and does not specify deployment acceptance criteria, monitoring, or revision governance.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames algorithmic discrimination in sociotechnical settings regulated by anti-discrimination laws (mentions GDPR, Civil Rights Act, etc.), with protected groups as subjects of potential harm; discusses fairness as a constraint in decision-making contexts but does not elaborate stakeholder processes or governance beyond benchmarking.
Spec explicitness/testability: Explicit + testable
Spec snippet: Formalizes fairness for node classification using Statistical Disparity (ΔSP) and Inequal Opportunity (ΔEO) as constraints/objectives, with the task stated as maximizing accuracy while having low ΔSP and ΔEO (Problem 1).
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Regulators
Study ID: P064
System Type: Classification
Threshold value: PostProcess uses flip parameter γ ∈ [0,1] (varied 0.1–0.4 in experiments; described as 1%–40% in text) to control strength; prediction threshold at logit 0 for positive class in their binary setup.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Extensive offline experiments on 4 datasets (two semi-synthetic credit datasets and two real-world social network datasets) and 3 GNN architectures; reports fairness–accuracy tradeoff and sensitivity to γ, plus runtime comparisons and confidence distribution analyses.
Validation/testing present: Yes
Venue Type: Conference
Year: 2023