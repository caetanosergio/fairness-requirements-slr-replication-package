# P022 — GrgicHlaca2018Procedural

Acceptance criteria stated: Partial
Citation: GrgicHlaca2018Procedural
DES content: Yes
DES explicit requirement: Yes
DES snippet: We introduce three scalar measures of procedural fairness ... and provide fast submodular mechanisms to optimize the tradeoff between procedural fairness and prediction accuracy.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: Policing
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: We leverage the rich literature on organizational justice ... distinguish between ... distributive and procedural fairness ... humans’ moral judgments ... rooted in prevailing cultural or social norms, political beliefs, and legal regulations.
Elicitation artifact: Fairness notions list, Other
Elicitation method: Surveys
Elicitation present: Yes
Elicitation snippet: For gathering human judgments, we use the Amazon Mechanical Turk (AMT) platform ... asking ... yes or no to three questions ... each feature is judged by 200 different workers.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Error parity, Other, Procedural fairness
Gap summary (1 sentence): Defines and operationalizes procedurally fair learning as explicit, testable constraints over feature sets grounded in human moral judgments and optimizes fairness–accuracy trade-offs, but does not address deployment-time monitoring or revision processes to keep procedural fairness requirements valid over time.
Governance maturity: Absent
Measurement procedure: Collect AMT judgments (200 US-based master workers) per feature for three questions (apr./acc./disp.); compute fraction judging feature fair; define set-function fairness as fraction judging all features in subset fair with conditioning on whether feature increases accuracy/disparity; evaluate feature subsets via logistic regression (L2) on COMPAS and NYPD SQF; optimize acc(S) subject to unf(S)≤t (and converse) using constrained submodular optimization; measure outcome fairness via FPR/FNR gaps between white vs non-white.
Metrics used: Procedural/process fairness set functions over feature subsets: feature-apriori fairness(F), feature-accuracy fairness(F), feature-disparity fairness(F); disparity uses disparate mistreatment (Zafar et al. 2017a) and outcome unfairness uses |FPR_w−FPR_nw|+|FNR_w−FNR_nw| (in COMPAS experiments).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: COMPAS recidivism: race (white vs non-white; also mentions African American vs white in survey question), sex, age. NYPD SQF: race, sex, age (plus other stop context features). Outcome disparity measured for whites vs non-whites.
QA notes: Introduces procedural/process fairness as fairness of feature usage (organizational justice lens), operationalizes via human moral judgments collected through AMT surveys, defines three explicit set-function measures (apr./acc./disp.) and proves (super/sub)modularity properties enabling constrained optimization for fairness–accuracy trade-offs. Evaluated on COMPAS and NYPD SQF with extensive feature-subset experiments; also compares to outcome fairness via FPR/FNR gaps (white vs non-white). No lifecycle monitoring/revision governance beyond offline evaluation.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Our key insight ... is to rely on humans’ moral judgments ... Their collective opinions ... reflect societal consensus on the desirability of using particular features.
Spec explicitness/testability: Explicit + testable
Spec snippet: We define the process fairness of C to be the fraction of all users who consider the use of every feature in F to be fair ... feature-apriori fairness(F) := |⋂_{f∈F} U_f| / |U|.
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Users
Study ID: P022
System Type: Classification
Threshold value: ε = 5% of full range (used to decide whether a feature increases accuracy/disparity); multiple unfairness/accuracy thresholds (21 values) for constrained optimization trade-offs.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation, User study
Validation snippet: We operationalize these measures on two real world datasets using human surveys on the Amazon Mechanical Turk (AMT) platform ... and demonstrate good performance empirically ... compare approximate solutions with brute-force optimum over feature subsets.
Validation/testing present: Yes
Venue Type: Conference
Year: 2018