# P087 — Anderson1999

Acceptance criteria stated: No
Citation: Anderson1999
DES content: No
Data Type: Other
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: Critiques luck egalitarianism and proposes democratic equality as an ideal of social relations among citizens (non-domination; equal standing).
Elicitation present: No
End-to-end coverage: None
Fairness notions: Contestability/recourse, Contextual/legal compliance, Other, Procedural fairness
Gap summary (1 sentence): Develops "democratic equality" as an anti-oppression ideal and critiques luck egalitarian compensation schemes, but does not operationalize fairness requirements into testable metrics or acceptance criteria.
Governance maturity: Absent
Monitoring present: No
Operationalization present: No
Protected attrs / groups: Class/poverty; disability; gender; race (discussed as examples of oppression/segregation and social hierarchy)
QA notes: Normative political philosophy paper: rejects luck egalitarianism as disrespectful; argues equality aims at ending oppression and securing equal social standing among citizens (democratic equality). Not an empirical study; no metrics/thresholds/validation protocol.
QA pass: Pass
QA score: 6.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: Yes
SOC snippet: Focuses on social relations of oppression (domination, marginalization, stigmatization) and what egalitarian justice requires to avoid them.
Spec explicitness/testability: Explicit not testable
Spec snippet: Anderson argues that the point of equality is to end oppressive social relations and secure "democratic equality" rather than compensate for brute luck (critique of luck egalitarianism).
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Org leadership, Regulators, Users
Study ID: P087
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation/testing present: No
Venue Type: Journal
Year: 1999