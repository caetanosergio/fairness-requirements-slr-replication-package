# P067 — CorbettDavies2023MeasureMismeasure

Acceptance criteria stated: No
Citation: CorbettDavies2023MeasureMismeasure
DES content: Yes
DES explicit requirement: Yes
DES snippet: Assembles a two-part taxonomy of formal fairness definitions (constraints on disparities vs constraints on effects of protected attributes) and shows analytically and empirically that enforcing many popular criteria yields strongly Pareto dominated decision policies. Provides formal decision-theoretic setup with randomized rules d(x), budgets, utility functions, threshold rules, and measure-theoretic results (e.g., incompatibility of threshold-optimal policies with classification parity via inframarginality).
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Conceptual
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames algorithmic fairness as policy-like design in consequential decision domains (banking, criminal justice, medicine, college admissions) with legal protected characteristics (race, gender) and societal goals (e.g., diversity, health outcomes). Highlights that fairness must be evaluated by context-specific consequences rather than abstract axioms.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Missing context assumptions, No thresholds / acceptance criteria, Other
Fairness notions: Contextual/legal compliance, Error parity, Other, Outcome parity
Gap summary (1 sentence): Critiques parity-based and attribute-effect fairness constraints as often producing Pareto-dominated policies and argues for policy-aligned, consequence-based design, but does not provide concrete operational acceptance thresholds or lifecycle monitoring/revision mechanisms for maintaining fairness requirements over time.
Governance maturity: Absent
Measurement procedure: Develops formal decision framework: individuals with covariates X, protected attributes A, binary decision D via randomized policy d(x), budget constraint E[D] ≤ b, outcomes Y (and potential outcomes Y(0), Y(1)). Shows optimal decision rules are threshold policies (in no-externalities case) and multiple-threshold policies (with trade-offs), and proves measure-theoretic results that common fairness constraints are almost surely incompatible with optimal/Pareto-efficient policies (inframarginality; prevalence arguments). Provides empirical illustrations (e.g., diabetes screening risk distributions; COMPAS miscalibration; simulated college admissions feasibility regions).
Metrics used: Formal fairness metrics/constraints: demographic parity; equalized false positive rates; confusion-matrix parity statistics; AUC parity; causal counterparts (counterfactual predictive parity, counterfactual equalized odds, principal/conditional principal fairness); blinding and calibration; counterfactual fairness and path-specific fairness. Uses utility/decision-theoretic metrics (expected utility u(d)), Pareto dominance/efficiency, and trade-off geometry (diversity vs academic index).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected attributes discussed include race and gender (and other legally protected characteristics). Examples include race groups in diabetes screening and college admissions; gender in recidivism risk assessment (COMPAS) and general discussions of protected characteristics.
QA notes: JMLR’23 conceptual+theoretical synthesis: taxonomy of fairness definitions, measure-theoretic critique (inframarginality/prevalence) and Pareto-domination results, plus empirical illustrations (NHANES diabetes screening; COMPAS miscalibration; simulated college admissions). Strong on trade-offs, policy framing, and links to law/economics; limited as an RE artifact (no elicitation study, no acceptance thresholds, no monitoring/revision governance).
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Connects technical fairness criteria to legal doctrines (disparate treatment vs disparate impact) and economic notions (taste-based vs statistical discrimination); discusses policy and governance implications, including how legislation and practice can misuse formal fairness metrics, motivating a consequentialist, policy-aligned approach.
Spec explicitness/testability: Explicit not testable
Spec snippet: Defines multiple formal fairness constraints (e.g., demographic parity, equalized FPR, counterfactual predictive parity, counterfactual equalized odds, (conditional) principal fairness, blinding, counterfactual fairness, path-specific fairness) as conditional independence / counterfactual conditions over decisions, outcomes, and protected attributes.
Specification format: Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P067
System Type: Decision support
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: Supports claims with both analytic proofs and empirical illustrations: diabetes screening example using NHANES risk distributions, COMPAS score calibration illustration, and a simulated college admissions setting showing constrained fairness regions lie below the Pareto frontier; provides general theorems showing Pareto domination and incompatibility results.
Validation/testing present: Yes
Venue Type: Journal
Year: 2023