# P045 — Mitchell2021

Acceptance criteria stated: Partial
Citation: Mitchell2021
DES content: Yes
DES explicit requirement: Yes
DES snippet: Provides a structured taxonomy of choices/assumptions in prediction-based decisions and a notationally consistent catalog of formal fairness definitions (oblivious parity metrics, metric/individual fairness, and causal/path-specific notions), plus impossibility results showing incompatibilities among definitions.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames fairness issues in prediction-based decision-making deployed in real domains (lending, pretrial detention, welfare, hiring) and highlights key background assumptions (population selection, decision space, measurement) that shape fairness outcomes beyond the model itself.
Elicitation present: Yes
Elicitation snippet: Argues for involving impacted communities across the development process and calls for community input, independent revalidation, and meaningful oversight (example: pretrial risk assessment statement of civil rights concerns).
End-to-end coverage: Full loop
Failure modes: Missing context assumptions, Other
Fairness notions: Error parity, Individual consistency, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Offers a comprehensive, consistent catalog of fairness definitions and the often-implicit assumptions behind prediction-based decision-making (including data/measurement and policy framing), highlighting impossibility trade-offs and urging documentation and community oversight, but does not provide an end-to-end operational method for turning these considerations into concrete, monitored fairness requirements for a deployed system.
Governance maturity: Developing
Measurement procedure: Conceptual synthesis: lays out decision-theoretic setup (V=(A,X), score S=ψ(V), decision D=δ(V)), links fairness notions to conditional independence statements and confusion-matrix rates; explains impossibility results (e.g., separation vs sufficiency under unequal base rates and imperfect prediction) and when different fairness notions are motivated (measurement error, visibility of decisions, stakeholder perspectives).
Metrics used: Catalogs parity-based metrics from the confusion matrix (FPR, TPR, FNR, TNR, PPV, NPV, accuracy), equalized odds/separation, sufficiency/predictive parity/calibration, demographic parity/statistical parity, metric fairness/individual fairness (Lipschitz), and causal counterfactual/path-specific definitions (counterfactual fairness, no direct effect, path-specific effects). Also discusses assumptions like selective labels, measurement error (including differential measurement error), and dynamic/temporal assumptions (no interference, static vs dynamic evaluation).
Monitoring present: Yes
Monitoring signals: Calls for regular revalidation, independent audits, and documentation of data/model performance (e.g., model cards, datasheets) plus public reporting and oversight.
Monitoring snippet: Recommends documentation and oversight, and notes a principle that tools should be “revalidated regularly by independent data scientists” with community input and subjected to oversight.
Notes: Set Monitoring/Revision to YES because the paper explicitly recommends regular revalidation/auditing and oversight, though not as a detailed operational process.
Operationalization present: Yes
Protected attrs / groups: Discusses protected characteristics (race, gender, class) and intersectionality (e.g., Black women; darker-skinned females) and notes cultural/context dependence of salient group categories; emphasizes that entry into the modeled population (e.g., arrest, loan application) can itself be biased.
QA notes: Annual Review (2021) that systematizes algorithmic fairness for prediction-based decision-making: clarifies policy/problem-formulation assumptions (goals, population selection, decision space), data issues (selective labels, sampling bias, differential measurement error, societal bias), and provides a notationally consistent catalog of fairness definitions (parity metrics from confusion matrix, calibration/sufficiency, equalized odds/separation, demographic parity, metric fairness, and causal/path-specific notions). Emphasizes impossibility results, documentation/auditing, and community input/oversight; limited on concrete RE-style lifecycle artifacts or implementable acceptance/monitoring triggers beyond high-level recommendations.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: Yes
Revision snippet: Suggests regular revalidation and meaningful oversight as part of responsible deployment; does not specify operational triggers/owners in a concrete system lifecycle.
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Explicitly connects formal fairness metrics to social goals, stakeholders, and power structures (e.g., policing and lending institutions), emphasizes community input/oversight and documentation, and warns about gaps between mathematical convenience and societal objectives.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines many fairness criteria as parity/conditional independence constraints over (A,X,Y,S,D), e.g., equalized odds (D ⟂ A | Y), sufficiency (Y ⟂ A | D or S), demographic parity (D ⟂ A), and individual/metric fairness (|δ(v)−δ(v′)| ≤ m(v,v′)).
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P045
System Type: Classification
Threshold value: Discusses threshold-based decision rules δ(v)=I(ψ(v)≥c) and notes thresholding choices; does not prescribe universal numeric thresholds (context-dependent).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Other
Validation snippet: Review article that surveys and harmonizes definitions/assumptions/terminology, using canonical examples (pretrial risk assessment and lending) to illustrate how fairness criteria, data issues, and decision assumptions interact; not an empirical evaluation of a new algorithm.
Validation/testing present: Yes
Venue Type: Journal
Year: 2021