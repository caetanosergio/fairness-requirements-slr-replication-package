# P109 — Pleiss2017NeurIPS

Acceptance criteria stated: No
Citation: Pleiss, Geoff, Manish Raghavan, Felix Wu, Jon Kleinberg, and Kilian Q. Weinberger. "On Fairness and Calibration." In Advances in Neural Information Processing Systems (NeurIPS), 2017.
DES content: Yes
DES snippet: Formal analysis of the incompatibility between calibration and error-rate parity constraints (Equalized Odds and relaxations). Provides geometric characterization in generalized FP/FN space, feasibility conditions, and an optimal post-processing algorithm (information withholding / randomization) to satisfy calibrated equal-cost constraints when feasible.
Data Type: Tabular
Decision rule tied to metric: No
Domain: Policing
ENV content: Yes
ENV snippet: Frames fairness concerns about predictive errors in sensitive domains (criminal justice, online advertising, medical testing) and motivates calibration as necessary for risk scores to have consistent meaning across protected groups (to avoid incentivizing decision makers to use group membership).
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides rigorous, testable results on calibration–fairness incompatibilities and an optimal (but ethically troubling) randomized post-processing for calibrated parity, yet offers no stakeholder elicitation, acceptance criteria, or deployment-time monitoring/revision guidance for choosing among incompatible fairness goals.
Governance maturity: Absent
Measurement procedure: Given calibrated classifiers for each group, characterize feasible calibrated solutions as points on group-specific calibration lines in generalized FP/FN space. For relaxed equal-cost parity, compute interpolation parameter α and post-process by replacing h_2(x) with trivial base-rate predictor μ_2 with probability α (information withholding) so that g_2(tilde h_2)=g_1(h_1) while preserving calibration; evaluate empirically on Adult, Heart, and COMPAS datasets comparing to EO post-processing/training.
Metrics used: Calibration (within-group), generalized false-positive and false-negative rates for probabilistic classifiers, Equalized Odds (matching both error types), relaxed equal-cost parity g_t, plus evaluation via plotted FP/FN trade-off geometry; discusses base rates μ_t as key parameter.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Discusses group attribute defining subpopulations G1,G2 (e.g., race: African-American vs Caucasian in COMPAS; gender: women vs men in Adult; age groups: middle-aged vs seniors in Heart).
QA notes: Strong theory + clear operational definitions (calibration, generalized FP/FN, EO and relaxations) and empirical confirmation. Explicitly discusses troubling implications (random information withholding; degrading one group) and feasibility limits; still does not provide concrete stakeholder elicitation or governance/monitoring process for selecting fairness targets in practice.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Highlights normative tension: group-level parity under calibration may require intentionally degrading one group’s classifier and using random coin flips to withhold information for individuals, raising individual fairness and acceptability concerns in high-stakes settings.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines probabilistic classifiers h_t(x)∈[0,1] with generalized FP/FN rates cfp(h_t)=E[h_t(x)|y=0], cfn(h_t)=E[1−h_t(x)|y=1]; Probabilistic Equalized Odds requires matching both across groups. Group calibration requires P(y=1|h_t(x)=p)=p within each group. Shows impossibility of satisfying calibration with multiple distinct equal-cost (incl. EO) constraints unless perfect prediction; proposes calibrated relaxation via equalizing a single linear cost g_t(h_t)=a_t cfp(h_t)+b_t cfn(h_t).
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Regulators
Study ID: P109
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Empirically confirms theoretical findings on multiple datasets (Adult income prediction, Heart health prediction, COMPAS recidivism), comparing calibrated relaxations vs Equalized Odds post-processing/training using generalized FP/FN plots.
Validation/testing present: Yes
Venue Type: Conference
Year: 2017