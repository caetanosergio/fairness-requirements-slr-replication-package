# P099 — Monjezi2023

Acceptance criteria stated: Partial
Citation: Monjezi, Verya, Gang Tan, Ashutosh Trivedi, and Saeid Tizpaz-Niari. "Information-Theoretic Testing and Debugging of Fairness Defects in Deep Neural Networks." In 2023 IEEE/ACM 45th International Conference on Software Engineering (ICSE). IEEE/ACM, 2023. https://doi.org/10.1109/ICSE48619.2023.00136
DES content: Yes
DES snippet: Proposes DICE, an information-theoretic testing + debugging framework for DNN fairness defects. Key ideas: quantify fairness defects as protected information used (bits) via Quantitative Individual Discrimination (QID); use QID as a smooth objective to guide search-based test generation; and apply causal debugging (interventions on layers/neurons) to localize components responsible for discrimination and support simple mitigation (activate/deactivate neurons).
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: Motivates DNN-based decision support in socio-economic/legal-critical domains (recidivism, benefits eligibility, tax audits) and argues fairness defects can arise from biased training data or improper training and may violate legal protections; highlights developer need for severity and causal explanations to triage defects.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other, Unstable subgroup definitions
Fairness notions: Error parity, Individual consistency, Other, Outcome parity
Gap summary (1 sentence): Introduces an information-theoretic, testable severity measure for individual fairness defects (QID in bits) and couples it with search-based test generation and causal neuron/layer localization to guide mitigation, but does not provide stakeholder-grounded acceptance thresholds or any deployment-time monitoring and revision governance for maintaining fairness under drift.
Governance maturity: Absent
Measurement procedure: For a seed input x (non-protected features), generate m counterfactuals varying protected attributes; obtain DNN prediction scores; cluster outputs with tolerance ε to form equivalence classes; compute QID from number/size of clusters using Shannon and min-entropy (information flow in bits). Search: global+local phases using quantitative feedback (cluster spread / QID) with LBFGS and gradient-based perturbations to maximize discrimination. Debugging: layer localization by sensitivity to protected attributes (rate of change in δ_i), then neuron causal effects via interventions do(l,j,v) (activate vs deactivate) while keeping accuracy within tolerance; compute ACD on QID and suggest mitigation by activating/deactivating top neurons.
Metrics used: QID based on information theory: Q∞ (min-entropy-based) and Q1 (Shannon-entropy-based) measured in bits via clustering of DNN outputs over counterfactual protected-attribute perturbations; also reports classic individual discrimination (ID) counts for comparison baselines; performance/utility: model accuracy; search metrics: number of clusters K (output partitions), number of discriminatory instances, success rates, time-to-first and time-to-1k IDs; debugging metrics: average causal difference (ACD) and resulting QID reduction vs accuracy loss.
Monitoring present: No
Notes: Key novelty for your SLR: severity-ranked individual fairness defects via information flow (bits), plus causal debugging via interventions on neurons/layers. Limitation noted: counterfactual protected-attribute perturbations may produce unrealistic counterfactuals (false positives) unless constrained.
Operationalization present: Yes
Protected attrs / groups: Protected attributes Z include sex, race, age (and others listed as legally protected); experiments consider multiple protected attributes simultaneously with m as the total number of protected-value combinations; datasets include Adult (sex,race,age), COMPAS (sex,race,age), German Credit (sex,age), Default Credit (sex,age), Heart Health (sex,age), Bank Marketing (age), Diabetes (age), Students (sex,age), MEPS15/16 (age,race,sex).
QA notes: Strong technical paper: defines QID (min-/Shannon-entropy information flow) as quantitative individual discrimination severity; uses it to smooth search for discriminatory instances and provides causal debugging via interventions with accuracy constraints. Extensive offline experiments on 10 tabular socio-critical datasets, comparisons against AEQUITAS/ADF/NEURONFAIR, and mitigation results (QID reduction with limited accuracy loss). Does not include stakeholder elicitation or deployment monitoring/revision process; acceptance criteria for QID are only partial (tolerances for algorithms, not fairness thresholds).
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Frames discrimination against protected individuals/groups as harmful and potentially illegal in decision-support systems; treats fairness defects as software bugs requiring prioritization by severity and developer-facing explanations.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines a DNN decision function D: X×Z → [0,1]^t with protected attributes Z and non-protected attributes X; defines Quantitative Individual Discrimination (QID) as the amount of protected information (bits) used in decision making, characterized via information-flow measures based on Shannon entropy and min-entropy over counterfactual protected-attribute perturbations; QID=0 implies absence of individual discrimination.
Specification format: Constraint (formal/informal), NFR statement
Specification present: Yes
Study ID: P099
System Type: Decision support
Threshold value: Clustering tolerance ε; layer-localization ε1=1e-7; accuracy-loss tolerance ε2=0.05; top-k for debugging k=3; search hyperparameters include max global/local iterations and step sizes (e.g., m=10 samples per protected setting; local iterations up to 1000; ε (cluster) around 0.025 as reported). No domain acceptance threshold for “fair enough” QID is specified.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates DICE on 10 tabular socio-critical datasets with trained 6-layer fully connected DNNs; compares to AEQUITAS, ADF, and NEURONFAIR for generating individual discrimination instances; reports QID characterization (bits), efficiency (time), and causal localization + mitigation reducing QID (down to ~15% of initial) with ≤5% accuracy loss.
Validation/testing present: Yes
Venue Type: Conference
Year: 2023