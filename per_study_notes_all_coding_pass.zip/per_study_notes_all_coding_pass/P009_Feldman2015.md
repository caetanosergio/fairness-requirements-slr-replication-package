# P009 — Feldman2015

Acceptance criteria stated: Yes
Citation: Feldman2015
DES content: Yes
DES explicit requirement: Yes
DES snippet: They define certifying and removing disparate impact as data-centric procedures: certify DI risk by predicting protected attribute X from other attributes Y using balanced error rate (BER), and repair/transform Y (via quantile/median distribution repair, with partial repair parameter λ) to reduce predictability and satisfy DI threshold while preserving utility.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: Hiring
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: The paper grounds bias in U.S. disparate impact doctrine (Griggs v. Duke Power) and adopts a generalized EEOC “80% rule” threshold t=0.8 as the legal criterion for disparate impact on selection outcomes.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Other, Outcome parity
Gap summary (1 sentence): Provides legally grounded, explicit and testable disparate-impact requirements (t=0.8) plus certification and data-repair procedures with quantified fairness–utility trade-offs, but does not specify ongoing monitoring or revision mechanisms to keep fairness requirements valid over time.
Governance maturity: Absent
Measurement procedure: Certification: train a classifier optimized for BER to predict X from Y; compute error e and compare to derived threshold e0 (using b, the minority selection rate) from Theorem 4.1; if e0 < e, certify dataset as free from disparate impact for any classifier on Y. Removal/repair: transform each numerical (or ordered) attribute by matching conditional quantiles across protected groups to a median distribution (full repair λ=1); partial repair λ∈[0,1] using combinatorial (rank-space) or geometric (value-space) interpolation; evaluate with LR/SVM/GNB on Ricci firefighter exam, German Credit (Age, split at 25), Adult Income (Gender; also Race as additional protected attribute) measuring DI vs utility.
Metrics used: Disparate Impact DI (80% rule, threshold t=0.8) computed from outcome rates by protected group; LR+ and DI=1/LR+ restatement; certification metric: balanced error rate (BER) for predicting protected attribute X from Y; utility measured as 1−BER for predicting class C from repaired attributes; experimental fairness/utility curves as λ varies (partial repair).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected attribute X (e.g., race, sex, religion); experiments use Gender (Adult), Age (German Credit; young vs old at 25), Race (Ricci; non-white vs white; black+Hispanic grouped), and joint protected attributes (race+gender) in Adult.
QA notes: Strong requirements-style contribution: turns a legal fairness requirement (EEOC 80% rule DI<0.8) into certifiable, testable data requirements using predictability (BER) of protected attribute and provides concrete data repair mechanisms with a tunable fairness–utility parameter λ. Includes explicit thresholds/decision rules and empirical validation, but does not address post-deployment monitoring/revision processes to maintain fairness under distribution shift.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: They model a compliance/audit setting with two parties: Alice (decision maker using proprietary algorithm) and Bob (auditor) who assesses disparate impact without access to the algorithm; focuses on outcome-based certification aligned with legal precedent rather than intent, but does not define operational monitoring or governance roles beyond this audit framing.
Spec explicitness/testability: Explicit + testable
Spec snippet: Disparate impact (80% rule): dataset D has DI if Pr(C=YES|X=0)/Pr(C=YES|X=1) < t with t=0.8. They restate DI via likelihood ratio LR+ and define DI=1/LR+. They define ε-fairness via non-predictability: D is ε-fair if any predictor f:Y→X has BER(f(Y),X) > ε.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Other, Regulators
Study ID: P009
System Type: Decision support
Threshold value: Disparate impact threshold t = 0.8 (EEOC 80% rule). Certification uses derived BER threshold e = 1/2 − b/8 (for t=0.8) based on minority selection rate b; partial repair parameter λ ∈ [0,1] controls fairness–utility trade-off.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Empirical evaluation on three datasets (Ricci, German Credit, Adult Income) showing certification effectiveness and fairness–utility trade-offs of partial repair; compares to prior methods (FNB, RLR, LFR) across fairness and accuracy.
Validation/testing present: Yes
Venue Type: Conference
Year: 2015