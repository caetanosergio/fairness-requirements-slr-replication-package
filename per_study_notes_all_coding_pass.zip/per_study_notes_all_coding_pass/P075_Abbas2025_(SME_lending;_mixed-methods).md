# P075 — Abbas2025 (SME lending; mixed-methods)

Acceptance criteria stated: No
Citation: Abbas2025LendingByAlgorithm
DES content: Yes
DES explicit requirement: Partial
DES snippet: Trains/evaluates a random forest credit scoring classifier on 5,000 anonymized loan applications (AUC ≈ 0.998) and runs fairness diagnostics showing approval-rate disparity by education level (low education approved ~3× lower than advanced degrees) despite similar false positive rates; frames pipeline as an information-processing system and discusses feature emphasis (income, digital banking activity).
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Lending
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames credit allocation as a high-stakes domain where fairness, transparency, and trust are critical; highlights financial inclusion concerns in SME lending and notes that anonymized datasets lacking demographics limit evaluation of intersectional fairness.
Elicitation artifact: Other
Elicitation method: Interviews
Elicitation present: Yes
Elicitation snippet: Conducts twelve semi-structured interviews with SME owners and financial managers (US/UK), analyzed using the COM-B framework to capture perceived fairness/validity cues in lending decisions.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria, Unstable subgroup definitions
Fairness notions: Error parity, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Combines offline credit-model fairness diagnostics with stakeholder interviews to surface misalignment between statistical and experiential fairness in SME lending, but does not specify measurable acceptance thresholds or any deployment-time monitoring and revision governance for fairness over time.
Governance maturity: Absent
Measurement procedure: Offline simulation of lending conditions: train/evaluate random forest on US dataset of 5,000 anonymized SME loan applications; compute performance (AUC) and fairness diagnostics across groups (education-level approval rates; false positive rates). Complement with qualitative interviews analyzed via COM-B; triangulate to assess alignment between model-recognized signals and perceived fairness cues.
Metrics used: Reports AUC for model performance; compares approval rates across education groups; compares false positive rates across groups (implying error-rate parity analysis). Mentions fairness diagnostics but specific named fairness metrics are not provided in excerpt.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Groups compared primarily by education level (proxy/socioeconomic indicator). Paper notes demographic attributes like gender and race are absent in the anonymized dataset, preventing intersectional fairness evaluation.
QA notes: Coded from abstract + early introduction excerpt only. Strong on sociotechnical framing and stakeholder elicitation (interviews; COM-B) plus quantitative diagnostic by education-level disparities; explicitly notes missing demographics (gender/race) and limits on intersectional fairness. No explicit operational acceptance criteria, monitoring, or revision process described in excerpt.
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: p
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: N
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Uses a convergent mixed-methods design with 12 semi-structured interviews (SME owners/financial managers; US/UK) coded with COM-B; finds misalignment between algorithm’s structural indicators and users’ behavioral fairness cues (payment reliability, resilience). Argues statistical fairness does not guarantee experiential fairness; calls for integrating behavioral indicators and for policy reforms addressing sociotechnical gaps.
Spec explicitness/testability: Explicit not testable
Spec snippet: Aims to assess fairness, transparency, and trust in AI-based credit decision pipelines and to diagnose misalignment between statistical diagnostics and experiential fairness; does not provide explicit acceptance thresholds or formal fairness requirement statements in the provided excerpt.
Specification format: Narrative goal
Specification present: Yes
Stakeholders Mentioned: Affected groups, Regulators, Users
Study ID: P075
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation, User study
Validation snippet: Triangulates quantitative model evaluation (AUC + group fairness diagnostics) with qualitative interview findings to argue statistical fairness can diverge from experiential fairness; cautions performance given constrained anonymized dataset and missing demographic attributes.
Validation/testing present: Yes
Venue Type: Journal
Year: 2025