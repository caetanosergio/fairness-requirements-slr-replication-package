# P108 — Kilbertus2017NeurIPS

Acceptance criteria stated: No
Citation: Kilbertus, Niki, Mateo Rojas-Carulla, Giambattista Parascandolo, Moritz Hardt, Dominik Janzing, and Bernhard Schölkopf. "Avoiding Discrimination through Causal Reasoning." In Advances in Neural Information Processing Systems (NeurIPS), 2017.
DES content: Yes
DES snippet: Introduces a causal-graph/structural-equation framework with resolving variables and proxy variables; defines causal non-discrimination notions (unresolved discrimination, proxy discrimination) and gives procedures/algorithms (notably under linearity/expression assumptions) to construct predictors satisfying these criteria.
Data Type: Tabular
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: Motivates societal concern about discrimination in consequential ML decisions and critiques observational/statistical fairness criteria as insufficient to resolve fairness without assumptions about the causal data-generating process.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Missing context assumptions, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides clear, testable causal definitions and constructive procedures for avoiding certain forms of discrimination, but depends on strong causal-model assumptions and does not address stakeholder elicitation, acceptance criteria, or deployment-time monitoring/revision governance.
Governance maturity: Absent
Measurement procedure: Assume/construct a causal graph + structural equation model (SEM). Define discrimination as path-based properties (unresolved discrimination) and interventional invariances (proxy discrimination). For linear SEMs, derive parameter constraints (e.g., choose predictor Rθ(P,X) so that distribution of R is invariant to do(P=p)), enabling learning under constraints from labeled data.
Metrics used: Causal/discrimination criteria expressed via causal graphs and interventional distributions (do-calculus), not via fixed numeric thresholds; constraints are invariance conditions under interventions on proxy P (and analogous intervention-based criteria for unresolved discrimination).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected attribute A (e.g., gender, race, religion). Discusses proxies P (e.g., name, visual features, language spoken at home) that correlate with A.
QA notes: Strong conceptual/technical framing: precisely explains why observational criteria fail (unidentifiability), proposes causal criteria (unresolved vs proxy discrimination), and gives algorithmic removal procedures (especially under linearity/expressibility assumptions). Limited empirical validation (explicitly out of scope). Stakeholder elicitation and governance/monitoring are not covered beyond abstract legal/protected-group framing; limitations include reliance on correct causal graph/SEM and functional form assumptions.
QA pass: Pass
QA score: 7.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Frames fairness as avoiding harmful discrimination on legally protected attributes; discusses normative subtleties (concept of protected attribute vs observable proxies) and how different assumptions lead to different fairness conclusions.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines unresolved discrimination via existence of an unblocked directed path from protected attribute A to variable V not mediated by resolving variables; defines proxy discrimination via interventional invariance: P(R|do(P=p)) = P(R|do(P=p′)) for all p,p′ (and variants such as individual proxy discrimination).
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Regulators
Study ID: P108
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Conference
Year: 2017