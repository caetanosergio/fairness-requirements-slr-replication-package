# P062 — Qin2026Prune

Acceptance criteria stated: No
Citation: qin2026prune
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes attribute pruning as a post-processing intervention on a pre-trained DNN by zeroing out sensitive-attribute weights in the input layer; evaluates pruning for (i) bias removal and (ii) multi-attribute group fairness estimation, across 32 models and multiple datasets, comparing to baseline post-processing debiasing methods.
Data Type: Tabular
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes pre-trained DNNs deployed in high-stakes domains can inherit and amplify bias from training data, and that fairness must be assessed across potentially multiple sensitive attributes; notes existing fairness metrics may be non-robust for multi-attribute group fairness and that post-processing methods may not address individual fairness.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Missing context assumptions, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Individual consistency, Other, Outcome parity
Gap summary (1 sentence): Shows that pruning sensitive-attribute inputs in pre-trained DNNs is a practical post-processing method that tends to preserve accuracy and support individual-fairness enforcement, but yields inconsistent group-fairness improvements and lacks explicit acceptance thresholds or lifecycle governance for deployment-time monitoring and revision.
Governance maturity: Absent
Measurement procedure: Given a pre-trained DNN, prune (zero out) sensitive-attribute input weights and measure resulting changes in fairness and accuracy. Run experiments over 32 models and 4 datasets, comparing single-attribute group bias removal and accuracy preservation against 3 post-processing baselines. For multi-attribute settings, apply pruning across multiple sensitive attributes and use resulting group-fairness estimates to support multi-attribute fairness-aware model selection; analyze trade-offs between individual and group fairness.
Metrics used: Fairness estimation uses group-fairness metrics (single-attribute and multi-attribute group fairness estimation) and considers individual fairness (claimed enforced by design through pruning). Also evaluates predictive performance (accuracy preservation) and compares against 3 baseline post-processing methods across 32 models and 4 datasets; additionally uses 3 multi-sensitive-attribute datasets for multi-attribute fairness-aware model selection.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive attributes such as race, gender, and age (multi-attribute setting); paper focuses on pruning sensitive-attribute inputs and estimating fairness across multiple attributes/groups.
QA notes: IST (2026) special issue paper: post-processing ‘attribute pruning’ (zeroing sensitive-attribute input weights) to remove bias and to estimate multi-attribute group fairness for model selection. Strong empirical evaluation across many models/datasets and explicit discussion of individual vs group fairness trade-off; limited stakeholder elicitation, no explicit acceptance thresholds, and no monitoring/revision governance described in excerpt.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Motivates fairness in high-stakes decision-making (finance, healthcare, law) and frames fairness as a requirement for selecting and enhancing models; discusses the fundamental trade-off between individual and group fairness objectives and the need for fairness-aware model selection, especially under multiple sensitive attributes.
Spec explicitness/testability: Explicit + testable
Spec snippet: Specifies a concrete debiasing transformation (prune sensitive-attribute weights in the input layer) and evaluates its impact on fairness metrics and accuracy; positions pruning as enforcing individual fairness by design, while acknowledging group-fairness effects are inconsistent and data-dependent, and uses pruning as a mechanism to estimate multi-attribute group fairness for model selection.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Users
Study ID: P062
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: Empirical evaluation across 32 models and 4 datasets for bias removal and accuracy preservation, plus demonstration on 3 multi-sensitive-attribute datasets for multi-attribute group fairness estimation.
Validation/testing present: Yes
Venue Type: Journal
Year: 2026