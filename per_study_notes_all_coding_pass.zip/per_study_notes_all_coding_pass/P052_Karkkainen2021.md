# P052 — Karkkainen2021

Acceptance criteria stated: Partial
Citation: Karkkainen2021
DES content: Yes
DES explicit requirement: Yes
DES snippet: Constructs FairFace (108,501 images) with labels for race (7 groups), gender, and age, using controlled collection from YFCC-100M plus other sources and multi-annotator adjudication; trains baseline attribute classifiers (ResNet-34) and provides evaluation protocol for cross-dataset generalization and balanced accuracy; includes benchmarking of commercial APIs.
Data Type: Image
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Motivates that existing public face datasets are compositionally biased toward White/Caucasian faces, leading to inconsistent accuracy for non-White groups; positions FairFace as a data-centric mitigation by balancing race, gender, and age to improve generalization and enable bias measurement/mitigation in face analytics.
Elicitation artifact: Other
Elicitation method: Other, Surveys
Elicitation present: Yes
Elicitation snippet: Uses human annotation via Amazon Mechanical Turk with 3 annotators per face (re-annotation if disagreement), plus manual re-verification of items where model predictions disagree with labels; this functions as a structured elicitation/labeling workflow for protected attributes.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Missing context assumptions, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Introduces FairFace, a large in-the-wild face attribute dataset balanced across 7 race groups plus gender and age to reduce representation bias and enable more consistent subgroup accuracy and auditing of commercial APIs, but it does not provide deployment-time monitoring/governance for ongoing bias, nor does it define explicit acceptance thresholds for subgroup disparity beyond reporting metrics like ε and STD.
Governance maturity: Absent
Measurement procedure: Collect images from YFCC-100M (CC BY/SA) with adaptive country sampling to avoid over-dominance by White faces; detect faces (min 50×50) and label race/gender/age via MTurk with agreement rule (2/3 majority; re-annotate otherwise; discard unresolved). Refine labels by training a model and manually re-verifying disagreements. Train ResNet-34 attribute classifiers with Adam; evaluate (i) dataset composition bias via race proportions, (ii) cross-dataset classification across FairFace, UTKFace, LFWA+, CelebA, (iii) generalization to novel datasets (geo-tagged tweets, media photos, protest images) and subgroup consistency (STDV, ε), and (iv) commercial API bias for gender classification.
Metrics used: Balanced accuracy across race/gender/age groups; subgroup-wise accuracies and standard deviations; maximum accuracy disparity ε(Ŷ) based on ratios of conditional accuracies across demographic groups; cross-dataset generalization accuracy for race/gender/age; commercial API accuracy by subgroup; supplemental skin-color (ITA) analyses.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Race (7 groups: White, Black, Indian, East Asian, Southeast Asian, Middle Eastern, Latino), gender (M/F), and age groups; also considers skin color (ITA) as a complementary proxy measure but argues race is multidimensional and cannot be reduced to skin tone alone.
QA notes: WACV 2021 paper creating FairFace to address composition bias in face datasets by balancing race (7 groups), gender, and age. Strong dataset-spec + operationalization via subgroup accuracy parity metrics and extensive cross-dataset/generalization evaluations, including audits of commercial APIs. Stakeholder elicitation is limited to labeling workflow (MTurk) rather than participatory governance; acceptance thresholds and monitoring over time are not specified.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Yes
Revision present: Yes
Revision snippet: Dataset construction includes iterative label refinement and manual re-verification when model predictions disagree with initial annotations; code/data/models are released (implying ownership for future dataset/model revisions) but no operational monitoring process is described.
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Frames fairness as avoiding demographic performance disparities in face analytics (notably gender classifiers failing on dark-skinned females) and notes downstream harms (public trust, service termination, demographic surveys with policy implications); explicitly treats race, gender, and age as protected attributes and emphasizes representation of groups (Latino, Middle Eastern, SE Asian).
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines dataset requirements: balanced composition across 7 race groups (White, Black, Indian, East Asian, Southeast Asian, Middle Eastern, Latino) with gender and age group labels; defines fairness target as balanced accuracy / accuracy equality across demographic groups (links to equalized-odds/accuracy-equality style constraints). Defines maximum accuracy disparity ε(Ŷ)=max_{j,k∈D} |log(P(Ŷ=Y|A=j)/P(Ŷ=Y|A=k))| as a group-disparity measure; includes protocol for evaluating cross-dataset performance and subgroup gaps.
Specification format: Constraint (formal/informal), Other, Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Regulators, Users
Study ID: P052
System Type: CV
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: Validates via extensive offline evaluation: cross-dataset and external generalization tests with subgroup breakdowns, plus an audit-style benchmark of commercial gender classifiers (Amazon, Microsoft, Face++, IBM) on a balanced FairFace subset; reports improved generalization and reduced subgroup disparities for models trained on FairFace.
Validation/testing present: Yes
Venue Type: Conference
Year: 2021