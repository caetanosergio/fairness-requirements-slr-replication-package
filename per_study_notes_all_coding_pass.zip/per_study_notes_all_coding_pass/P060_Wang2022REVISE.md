# P060 — Wang2022REVISE

Acceptance criteria stated: No
Citation: Wang2022REVISE
DES content: Yes
DES explicit requirement: Yes
DES snippet: Presents REVISE, a Jupyter-notebook-based tool that takes a visual dataset and annotations as input and outputs bias-related metrics and suggested actions across three axes: object-based, person-based, and geography-based analyses; runs locally for privacy and can generate a static PDF summary report; includes tests/scripts to validate dataset formatting.
Data Type: Image
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes visual datasets encode under- and mis-representation that may not be apparent until after deployment, and that dataset bias can stem from object frequency/scale/context/diversity, demographic portrayal, and geographic representation; also assumes external annotations and pretrained models used for auditing can introduce their own biases and must be interpreted critically.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Other, Unstable subgroup definitions
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Provides a pre-deployment, dataset-centric auditing tool that operationalizes many bias dimensions in visual datasets and suggests mitigation actions, but leaves normative judgments and governance of interventions to users and does not define monitoring/revision processes for deployed pipelines.
Governance maturity: Absent
Measurement procedure: Run REVISE locally on a dataset with available annotations (object labels, boxes, sensitive-attribute labels, geolocation, tags/captions). Tool computes a suite of metrics by axis (object/person/geography) and surfaces statistically significant anomalies; may incorporate external pretrained models/tools (e.g., scene classifier, language detection) and notes these introduce confounds. Provides ranked actionable augmentation/cleanup suggestions (e.g., pairwise query terms; reconcile duplicate labels; remove dubious gender labels).
Metrics used: Dataset-bias audit metrics across object/person/geography dimensions (frequency, scale, context/co-occurrence, scene diversity, appearance diversity; demographic prominence and contextual representation; geography distribution and correlations with tags/language/income/weather). Uses statistical significance tests (e.g., permutation tests, regression trend tests) to surface anomalous patterns. Focus is dataset-level bias rather than model outcome parity.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Gender (binary perceived); skin tone (Fitzpatrick 1–6, ordinal); geography/region/country; language-as-proxy for locals vs tourists; income and weather as external region-level attributes (BDD100K case study).
QA notes: REVISE (IJCV 2022) is a dataset-bias auditing and mitigation-support tool for CV datasets, covering object/person/geography bias dimensions with statistically grounded metrics and actionable data-collection/cleanup suggestions. Strong operationalization and empirical audits on COCO/OpenImages/YFCC100m/BDD100K, plus clear limitations about normative bias judgments and risks of demographic labeling; no stakeholder elicitation or lifecycle monitoring/governance plan.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Emphasizes that determining which surfaced patterns are problematic is a normative judgment that requires cultural and historical context; discusses contested nature of “bias”, risks of reifying gender/skin-tone categories, and potential societal harms from biased datasets; recommends clearer annotation guidance and removal of questionable demographic labels (e.g., gender when person is too small/no face).
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines a catalog of measurable dataset-bias metrics and statistical tests (e.g., counts, co-occurrence, scale bins, entropy-based scene diversity, feature-space appearance diversity; demographic prominence/context measures; geography distribution and correlations; permutation tests / regression trend tests) and positions these as a structured audit that can be run pre-deployment on datasets.
Specification format: Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Users
Study ID: P060
System Type: CV
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: Validates usefulness by applying REVISE to multiple widely used CV datasets (COCO, OpenImages, YFCC100m, BDD100K) and reporting example insights and mitigation suggestions; includes statistical testing to identify significant representation differences.
Validation/testing present: Yes
Venue Type: Journal
Year: 2022