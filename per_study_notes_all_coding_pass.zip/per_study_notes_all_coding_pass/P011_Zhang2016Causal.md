# P011 — Zhang2016Causal

Acceptance criteria stated: Yes
Citation: Zhang2016Causal
DES content: Yes
DES explicit requirement: Yes
DES snippet: Models direct/indirect discrimination as path-specific causal effects in a learned causal DAG and provides algorithms to (1) discover discrimination by estimating these effects from observational data and (2) remove discrimination by modifying the decision node’s CPT via quadratic programming to keep both direct and indirect effects below τ while preserving data utility and ensuring models trained on modified data are non-discriminatory.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: Lending
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Grounded in anti-discrimination law (e.g., Equal Credit Opportunity Act) and legal notions of direct vs indirect discrimination (redlining). Uses a user-defined legal threshold τ (e.g., 0.05 per British sex discrimination legislation example) for claiming discrimination based on causal effects.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Other, Procedural fairness
Gap summary (1 sentence): Provides an explicit, legally grounded causal specification of direct and indirect discrimination (path-specific effects with threshold τ) and a data repair method that prevents discrimination in downstream model predictions, but does not define monitoring or revision processes to maintain these guarantees as data and causal structure evolve over time.
Governance maturity: Absent
Measurement procedure: Build/learn causal network (DAG) from historical data (e.g., PC algorithm with CI test significance 0.01; uses temporal tiers). Specify protected attribute C (binary), decision attribute E (binary), and redlining attributes R (unjustified). Compute SE_d via Equation (3) and SE_i via Equation (4) when identifiable; if recanting witness criterion blocks identifiability, cut arcs into E that transmit through redlining attributes to restore identifiability. Removal: solve quadratic program to modify CPT P'(E|Pa(E)) so SE_d and SE_i for both directions are ≤ τ, while keeping P' close to P; generate modified dataset from modified causal model; train classifiers on modified training data and test predictions on held-out test data; re-run PSE-DD on predictions to verify no direct/indirect discrimination remains.
Metrics used: Causal path-specific effects for discrimination: SE_d (direct) and SE_i (indirect) on positive decision E=e+ when changing protected attribute C between groups, computed using do-calculus / truncated factorization and identifiability conditions (recanting witness criterion). Uses τ as discrimination threshold. Utility preservation objective: minimize squared Euclidean distance between original and modified joint distributions Σ_v (P'(v)−P(v))^2 subject to discrimination constraints. Reports data utility (L2 distance) and prediction accuracy after repair, and tests discrimination in predictions via PSE-DD.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected attributes include gender, age, sexual orientation, race, religion/belief, disability/illness; experiments treat Sex as protected attribute (Adult and Dutch Census). Redlining attribute example: Zip code (race proxy) and in experiments: Marital status. Decision attributes: Income (Adult) and Occupation (Dutch).
QA notes: Key contribution is a requirements-like causal operationalization distinguishing direct vs indirect discrimination via path-specific effects and a repair procedure that modifies the causal mechanism for the decision (CPT of E) so that both effects fall below a legal threshold τ, with evidence that discrimination does not reappear in downstream model predictions. Strong on specification/operationalization and on validating the ‘no discrimination in predictions’ claim, but does not address post-deployment monitoring or revision under drift.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames fairness as a data-governance/preprocessing intervention prior to model building, with explicit roles for ‘data owners’ choosing protected attribute, decision attribute, and redlining attributes; aims to guarantee downstream predictive models trained on released data will not discriminate, but does not specify ongoing monitoring or revision governance after deployment.
Spec explicitness/testability: Explicit + testable
Spec snippet: Direct discrimination claimed if path-specific effect SE_d(c+,c−) > τ or SE_d(c−,c+) > τ, where SE_d is the effect along direct path C→E. Indirect discrimination claimed if SE_i(c+,c−) > τ or SE_i(c−,c+) > τ, where SE_i is the effect along paths from C to E that pass through redlining attributes R.
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Other, Regulators
Study ID: P011
System Type: Decision support
Threshold value: User-defined discrimination threshold τ (example τ=0.05; also reports measured effects such as SE_i=0.175 on Adult). Uses CI test threshold 0.01 for causal discovery (PC algorithm).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation, Other
Validation snippet: Experiments on Adult and Dutch Census datasets: estimate SE_d and SE_i, apply PSE-DR to remove discrimination, then train SVM/Decision Tree and re-test discrimination of predictions; compares to LMSG/LPS and Feldman DI repair, showing their method uniquely removes discrimination in downstream predictions with lower utility loss.
Validation/testing present: Yes
Venue Type: Preprint
Year: 2016