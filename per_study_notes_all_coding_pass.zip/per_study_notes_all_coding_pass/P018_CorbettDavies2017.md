# P018 — CorbettDavies2017

Acceptance criteria stated: Partial
Citation: CorbettDavies2017
DES content: Yes
DES explicit requirement: Yes
DES snippet: Reformulates fairness as constrained optimization: maximize immediate utility (public safety benefit minus detention cost) subject to formal fairness constraints (statistical parity, conditional statistical parity, predictive equality). Proves optimal constrained rules are deterministic threshold rules on risk p(Y=1|X) with group-specific thresholds t_g (and for conditional parity, thresholds depend on group + legitimate factors). Unconstrained optimum is a single uniform threshold c for all individuals.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: Policing
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames the deployment context as pretrial release decisions where algorithmic risk tools can create racial disparities; also surfaces a competing normative/legal notion of equality: holding all individuals to the same standard irrespective of race, contrasted with group-parity definitions that imply race-specific treatment.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides explicit, testable formulations of common fairness constraints and proves utility-optimal (often race-specific) threshold decision rules, empirically quantifying substantial public-safety trade-offs on Broward County data, but does not address post-deployment monitoring or revision of fairness requirements under shifting data or governance contexts.
Governance maturity: Absent
Measurement procedure: Model decisions as threshold rules over estimated risk p(Y=1|X) (learned via L1-regularized logistic regression + Platt scaling on Broward County data, excluding race). For each fairness constraint, choose group-specific thresholds to (i) satisfy the constraint, (ii) detain a fixed fraction (e.g., 30%), and (iii) maximize expected public safety/utility; evaluate via repeated train-test splits (e.g., 100 random 70/30 splits) and report impact on violent recidivism and proportion of detained low-risk individuals.
Metrics used: Fairness constraints: statistical parity (equal detention rates), conditional statistical parity (equal detention rates conditional on ‘legitimate’ factors), predictive equality (equal FPR). Also discusses calibration for risk scores. Utility metric: immediate utility u(d,c)=E[Y d(X) − c d(X)] with Y indicating benefit of detention (e.g., would recidivate if released).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Race groups (black vs white) in Broward County COMPAS dataset; notes logic applies to other protected attributes (e.g., gender).
QA notes: Strong formalization of fairness requirements as explicit constraints and utility objective; derives optimal threshold-based decision rules and shows constrained fairness can require race-specific thresholds (raising normative/legal concerns). Provides offline empirical quantification of cost-of-fairness on Broward County data with repeated splits. Does not address lifecycle monitoring/revision; acknowledges outcome-data bias, subgroup validity, and long-term utility limits.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Discusses policy and governance implications: constrained rules require explicit race-specific thresholds which may raise strict scrutiny under Equal Protection; highlights that fairness constraints can detain low-risk individuals and release higher-risk ones, and emphasizes that algorithm choice is only one intervention among others (services, supervision, discretion). Does not specify monitoring/revision processes.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines decision rule d: R^p → [0,1] (probability of detain). Statistical parity: E[d(X)|g(X)] = E[d(X)] (Eq.1). Conditional statistical parity: E[d(X)|ℓ(X),g(X)] = E[d(X)|ℓ(X)] (Eq.2). Predictive equality (equal FPR): E[d(X)|Y=0,g(X)] = E[d(X)|Y=0] (Eq.3). Utility u(d,c)=E[Y d(X) − c d(X)]. Theorem: optimal constrained rules are threshold rules on p(Y=1|X) with group-specific thresholds; unconstrained optimum is d*(X)=1{p(Y|X) ≥ c}.
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P018
System Type: Decision support
Threshold value: Decision rules are explicit thresholds on risk p(Y|X). Unconstrained threshold: c (detain if p(Y|X) ≥ c). Constrained thresholds: group-specific t_g (and for conditional parity, t_{g,ℓ}). Empirical section fixes detention rate at 30% and reports group-specific detention rates (e.g., single-threshold detains ~40% black vs ~18% white in Broward).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Uses Broward County pretrial dataset to quantify trade-offs: under fairness constraints, more low-risk defendants are detained and estimated violent crime among released defendants increases (reported via repeated train/test splits and summarized in Table 1).
Validation/testing present: Yes
Venue Type: Conference
Year: 2017