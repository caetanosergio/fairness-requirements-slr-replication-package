# P089 — PerryZarsky2014

Acceptance criteria stated: No
Citation: PerryZarsky2014
DES content: No
Data Type: Other
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: Defines fairness vs efficiency as cornerstones for evaluating random allocation schemes in law and policy.
Elicitation present: No
End-to-end coverage: None
Fairness notions: Contextual/legal compliance, Other, Procedural fairness
Gap summary (1 sentence): Comprehensive normative framework for when lotteries are fair/efficient in legal allocation, but does not operationalize fairness into measurable system requirements, metrics, or monitoring/revision processes.
Governance maturity: Absent
Monitoring present: No
Operationalization present: No
Protected attrs / groups: Not specified (general discussion of equality and non-discrimination in allocation contexts)
QA notes: Legal theory article on random-based allocation (lotteries) in law. Distinguishes positive vs normative fairness; surveys contexts (licenses, housing, drafts, jury selection) and weighs fairness vs efficiency; highlights caveats (relevance, pre-screening, gaming, dignity, accountability).
QA pass: Pass
QA score: 7.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: p
QA9 Limitations/threats/ethics: Y
Revision present: No
SOC content: Yes
SOC snippet: Discusses fairness perceptions, equality, legitimacy, and dignity concerns in random selection; includes second-order fairness (e.g., jury/judge assignment).
Spec explicitness/testability: Explicit not testable
Spec snippet: Provides a systematic theoretical framework for assessing lotteries’ role in legal resource allocation, integrating fairness and efficiency concerns.
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Org leadership, Regulators, Users
Study ID: P089
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation/testing present: No
Venue Type: Journal
Year: 2015