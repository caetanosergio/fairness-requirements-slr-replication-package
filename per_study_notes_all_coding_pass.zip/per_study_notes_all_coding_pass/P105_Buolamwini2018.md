# P105 — Buolamwini2018

Acceptance criteria stated: No
Citation: Buolamwini, Joy, and Timnit Gebru. “Gender Shades: Intersectional Accuracy Disparities in Commercial Gender Classification.” In Proceedings of Machine Learning Research, vol. 81, Conference on Fairness, Accountability, and Transparency (FAT*), 2018, pp. 1–15. (PPB dataset: http://gendershades.org/)
DES content: Yes
DES explicit requirement: Yes
Data Type: Image
Decision rule tied to metric: Unclear
Deployment Status: Deployed
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Other
Fairness notions: Contestability/recourse, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Demonstrates large intersectional performance disparities in commercial gender classification and shows that benchmark composition hides these gaps, motivating fairness requirements for disaggregated evaluation and representative datasets, but it does not propose deployment monitoring/revision or quantitative acceptance thresholds for when performance is ‘fair enough’.
Governance maturity: Absent
Measurement procedure: Create Pilot Parliaments Benchmark (PPB) with 1270 individuals balanced by binary gender label and Fitzpatrick skin type; annotate existing benchmarks (IJB-A, Adience) for skin type to quantify representation; evaluate 3 commercial gender classifiers (Microsoft, IBM, Face++) on PPB and report performance disaggregated by gender, skin type, and intersectional subgroups; analyze confidence scores (IBM) and discuss dataset/measurement implications.
Metrics used: Audit/benchmark metrics: subgroup error rate (1−TPR), TPR, FPR, PPV, overall accuracy; intersectional subgroup breakdown (darker female, darker male, lighter female, lighter male) using Fitzpatrick skin type (I–VI aggregated to lighter I–III vs darker IV–VI).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Gender (binary labels used by APIs: female/male) and skin type (Fitzpatrick I–VI; aggregated to lighter vs darker). Discusses race/ethnicity contextually (e.g., African-American individuals in policing use cases) but primary measured attribute is skin type.
QA notes: Seminal algorithmic audit/benchmarking paper. Strong on problem framing (intersectional harms), operationalization (Fitzpatrick skin type + subgroup metrics), and empirical evaluation of commercial systems with clear disparity magnitudes. Partial: does not define formal fairness acceptance criteria or remediation process; limited lifecycle governance (monitoring/revision) beyond calling for transparency/accountability; uses binary gender labels per available APIs.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Yes
Spec explicitness/testability: Explicit + testable
Spec snippet: “The substantial disparities in the accuracy of classifying darker females, lighter females, darker males, and lighter males … require urgent attention if commercial companies are to build genuinely fair, transparent and accountable facial analysis algorithms.”
Specification format: Constraint (formal/informal), NFR statement
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Regulators, Users
Study ID: P105
System Type: CV
Thresholds stated: No
Trade-offs managed: Unclear
Validation method: Audit, Offline evaluation
Validation snippet: Evaluates commercial API classifiers on PPB and reports subgroup performance gaps (e.g., darker-skinned female error rates up to 34.7% vs lighter-skinned male max 0.8%).
Validation/testing present: Yes
Venue Type: Conference
Year: 2018