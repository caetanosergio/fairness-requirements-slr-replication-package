# P082 — Black2020FlipTest

Acceptance criteria stated: No
Citation: Black2020FlipTest
DES content: Yes
DES snippet: “FlipTest leverages optimal transport to match individuals in different protected groups, creating similar pairs of in-distribution samples.”
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: “We present FlipTest, a black-box technique for uncovering discrimination in classifiers… had an individual been of a different protected status, would the model have treated them differently?”
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria
Gap summary (1 sentence): Strong black-box individual/subgroup discrimination testing and diagnostic reporting, but does not define deployment acceptance thresholds, monitoring signals, or a revision/ownership process.
Governance maturity: Absent
Measurement procedure: Construct optimal transport map G between protected groups (uses GAN-approximated OT with cost = squared L1; generator loss adds transport cost term). For each x in source group S, compare h(x) vs h(G(x)) to form flipsets; compare flipset distributions vs population to identify affected subgroups; compute transparency report rankings from feature differences between x and G(x).
Metrics used: Flipset size and asymmetry: |F+(h,G)| and |F−(h,G)|; net flipset size and relation to demographic parity / equalized odds; transparency report feature rankings based on average (x−G(x)) and sign(x−G(x)) over flipset.
Monitoring present: No
Notes: Uses optimal transport between protected-group distributions; OT approximated by Wasserstein GAN with added transport cost; cost function used in experiments: squared L1; compares with counterfactual fairness (causal model) and FairTest; provides transparency report as feature-difference rankings for flipsets.
Operationalization present: Yes
Protected attrs / groups: Protected attribute defining groups S and S′ (examples: race (black/white), gender (women/men), age; privileged/unprivileged framing depends on application).
QA notes: Black-box fairness testing using optimal transport (GAN approximation) to generate in-distribution counterfactual-like pairs; introduces flipsets + transparency reports; shows can reveal subgroup discrimination even when demographic parity / equalized odds hold; stresses that flipsets are evidence for investigation, not proof of unlawful discrimination (e.g., business necessity).
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: Definition 1 (Flipset): “F(h,G) = {x ∈ S | h(x) ≠ h(G(x))}” (with F+ and F− partitions).
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P082
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: “Evaluating the approach on three case studies… identify subgroups that may be harmed… including in cases where the model satisfies group fairness criteria.”
Validation/testing present: Yes
Venue Type: Conference
Year: 2020