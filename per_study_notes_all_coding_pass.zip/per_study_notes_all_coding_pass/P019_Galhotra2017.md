# P019 — Galhotra2017

Acceptance criteria stated: Yes
Citation: Galhotra2017
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines fairness/discrimination measures and introduces Themis, an automated fairness testing approach that generates test suites from an input schema to measure group, causal, and apparent discrimination in black-box decision software, using caching, adaptive sampling, and sound pruning based on monotonicity proofs.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames discrimination as a critical quality attribute for software used in societal domains (criminal justice, finance, promotions), where unfair outcomes can trigger public backlash and regulatory concern; argues fairness is undervalued in the development lifecycle and should be tested like other quality properties.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Individual consistency, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Provides explicit, testable fairness/discrimination specifications and an automated fairness testing method (Themis) that quantifies causal and group discrimination (including in subdomains) across many software instances, but focuses on pre-deployment testing and does not define post-deployment monitoring or revision governance.
Governance maturity: Absent
Measurement procedure: Given input schema for valid inputs, generate random test inputs; estimate discrimination scores via adaptive sampling to reach error bound ε with confidence conf (z*√(p(1-p)/r)); reuse executions via caching; search for discriminating characteristic subsets using pruning based on monotonicity (if X′ discriminates ≥θ then any superset does) and relation d~≤d⃗. Evaluate on 20 instances of 8 systems (Adult and German Credit datasets), including 12 discrimination-aware algorithms and 8 standard ML baselines.
Metrics used: Group discrimination (generalized CV score) over categorical characteristics; causal discrimination (counterfactual-style input perturbation); apparent discrimination on a partial domain/operational profile; supports discrimination thresholds θ for search.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive characteristics include race and gender (also age, marital status, country, relationship in Adult). Experiments primarily measure discrimination w.r.t. race and gender; credit dataset includes gender (marital status+gender).
QA notes: Provides explicit, testable discrimination/fairness specifications and a concrete RE-relevant artifact: a fairness testing method (Themis) that operationalizes discrimination as measurable scores without requiring a conventional oracle. Strong on operationalization (schema, θ, ε/conf), and offline validation across many software instances; highlights that fairness-aware learning methods can still causally discriminate, especially in subdomains. Does not address post-deployment monitoring/revision.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Highlights stakeholder use (companies, government agencies) and policy implications (need to set and verify nondiscrimination requirements before deployment); discusses operational profiles to represent real-world input distributions and warns that focusing on global fairness can hide severe discrimination in subdomains. Does not define monitoring/revision processes beyond pre-deployment testing.
Spec explicitness/testability: Explicit + testable
Spec snippet: Causal discrimination: d⃗_{X′}(S) is fraction of inputs k for which there exists k′ differing only in characteristics X′ with S(k)≠S(k′). Group discrimination: d~{X′}(S)=max(P)−min(P) over outcome frequencies by groups. Discrimination checking problem: given threshold θ, find all X′ such that d~{X′}(S)≥θ or d⃗_{X′}(S)≥θ.
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Org leadership, Other, Regulators
Study ID: P019
System Type: Decision support
Threshold value: Uses discrimination threshold θ (e.g., θ=0.75 for search) plus confidence and error bound settings (e.g., conf=99%, ε=0.05) in experiments; also reports discrimination rates (e.g., up to 98.1% in some subdomains).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates Themis on 20 software instances, showing it detects discrimination (including in discrimination-aware systems) and that optimizations/pruning reduce test-suite sizes by orders of magnitude; reports discrimination scores for race/gender and examples of severe subdomain discrimination (up to ~98%).
Validation/testing present: Yes
Venue Type: Conference
Year: 2017