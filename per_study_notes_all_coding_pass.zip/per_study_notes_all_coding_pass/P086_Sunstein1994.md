# P086 — Sunstein1994

Acceptance criteria stated: No
Citation: Sunstein1994
DES content: No
Data Type: Other
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: ...the anticaste principle forbids social and legal practices from translating highly visible and morally irrelevant differences into systemic social disadvantage...
Elicitation present: No
End-to-end coverage: None
Fairness notions: Contextual/legal compliance, Other
Gap summary (1 sentence): Normative legal theory of equality-as-anticaste (linking liberty and equality) with empirical illustrations; no operationalized fairness metrics, decision thresholds, or implementation process artifacts.
Governance maturity: Absent
Monitoring present: No
Operationalization present: No
Protected attrs / groups: Race; gender (sex); disability (occasional reference)
QA notes: Legal theory essay arguing equality should be understood as anti-caste and largely for legislative/executive enforcement; discusses tensions among market freedom, preferences, and formal equality; uses data (e.g., HDI comparisons) as illustration, not as evaluation of an intervention.
QA pass: Pass
QA score: 6.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: Yes
SOC snippet: ...I also offer some information about racial and gender disparities in the United States...
Spec explicitness/testability: Explicit not testable
Spec snippet: ...the anticaste principle forbids social and legal practices from translating highly visible and morally irrelevant differences into systemic social disadvantage, unless there is a very good reason for society to do so.
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Org leadership, Regulators, Users
Study ID: P086
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation/testing present: No
Venue Type: Journal
Year: 1994