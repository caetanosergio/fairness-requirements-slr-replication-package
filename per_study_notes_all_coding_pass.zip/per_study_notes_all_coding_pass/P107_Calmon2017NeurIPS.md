# P107 — Calmon2017NeurIPS

Acceptance criteria stated: Partial
Citation: Calmon, Flavio P., Dennis Wei, Bhanukiran Vinzamuri, Karthikeyan Natesan Ramamurthy, and Kush R. Varshney. "Optimized Pre-Processing for Discrimination Prevention." In Advances in Neural Information Processing Systems (NeurIPS), 2017.
DES content: Yes
DES snippet: Formulates a probabilistic pre-processing transformation learned via (quasi)convex optimization to trade off discrimination control, utility preservation, and per-sample distortion constraints; provides pipeline (train/apply) and solver-based implementation details.
Data Type: Tabular
Decision rule tied to metric: No
Domain: Policing
ENV content: Yes
ENV snippet: Frames discrimination in algorithmic decision-making, distinguishes direct vs indirect discrimination (disparate treatment vs disparate impact), and positions the method in the ML pipeline (pre-processing) with legal/ societal context (e.g., 80% rule).
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides a rigorous, testable optimization framework for pre-processing to reduce group discrimination with individual distortion and utility constraints, but does not address stakeholder elicitation, deployment-time monitoring, or governance/revision processes beyond offline evaluation trade-offs.
Governance maturity: Absent
Measurement procedure: Estimate (p_{D,X,Y}) empirically from training data, solve optimization to learn randomized mapping (p_{hat X,hat Y|X,Y,D}), transform train and test data (test uses marginalized (p_{hat X|D,X})), train standard classifiers (LR, RF), evaluate discrimination on test via max over groups of ratio-based J on model outputs and evaluate AUC via 5-fold CV.
Metrics used: Discrimination metric based on probability ratio J(p,q)=p/q−1 (motivated by the 80% rule) applied to (p_{tilde Y|D}(1|d)); utility loss via total variation distance between (p_{X,Y}) and (p_{hat X,hat Y}); prediction performance via AUC.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Race (African-American vs Caucasian) in COMPAS; Gender in UCI Adult (male vs female).
QA notes: Strong technical clarity and operationalization (formal constraints, convexity conditions, train/apply pipeline, empirical evaluation on COMPAS and Adult). Stakeholders are mentioned mainly as abstract legal/protected groups and practitioner choice of fairness parameters; no concrete elicitation method or artifacts. Limitations discussed around distribution mismatch / finite samples and feasibility of constraints; ethics and governance beyond the optimization are limited.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Motivates fairness as non-discrimination for legally protected groups; discusses societal/legal considerations and group vs individual fairness notions and their tension/trade-offs.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines discrimination control constraints that limit dependence of transformed outcome (hat Y) on protected variables (D) (e.g., constraints on (p_{hat Y|D}) using a ratio metric motivated by the “80% rule”), while constraining individual distortion and preserving utility via distributional closeness.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Regulators
Study ID: P107
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: Benchmarks the learned pre-processing transformations on COMPAS recidivism and UCI Adult datasets, training LR/RF on transformed data and reporting discrimination–AUC trade-off curves; compares to baselines (original, dropping D, LFR).
Validation/testing present: Yes
Venue Type: Conference
Year: 2017