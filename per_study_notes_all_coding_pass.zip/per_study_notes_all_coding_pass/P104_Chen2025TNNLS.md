# P104 — Chen2025TNNLS

Acceptance criteria stated: Partial
Citation: Chen, Huiqiang, Tianqing Zhu, Wanlei Zhou, and Wei Zhao. “AFed: Algorithmic Fair Federated Learning.” IEEE Transactions on Neural Networks and Learning Systems 36, no. 8 (Aug 2025). DOI: https://doi.org/10.1109/TNNLS.2025.3528012.
DES content: Yes
DES explicit requirement: Yes
Data Type: Image
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Other, Outcome parity
Gap summary (1 sentence): Proposes AFed-G/AFed-GAN, a practical FL framework to improve demographic-parity group fairness under non-i.i.d. client data by learning a global latent distribution via conditional generative models and using generated-sample mixup regularization, but does not specify deployment-time monitoring/revision or concrete acceptance thresholds for deciding when fairness is sufficient.
Governance maturity: Absent
Measurement procedure: AFed framework for algorithmic fairness in federated learning without centralized data access: learn global data distribution in latent space via (i) AFed-G (server-side conditional generator trained using aggregated sensitive-attribute head feedback) or (ii) AFed-GAN (client-side conditional GAN with discriminator feedback). Use generated latent features conditioned on sensitive attribute to augment local training. Debias via mixup-style interpolation between real and generated latent features and regularize prediction invariance w.r.t. interpolation parameter t (derivative penalty).
Metrics used: Group fairness metric: Demographic Parity (DP) with ΔDP = |Pr(Ŷ=1|A=0) − Pr(Ŷ=1|A=1)|. Also reports accuracy–fairness trade-off curves by varying λ.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive attribute A is binary in formulation; experiments use race (UTKFace, FairFace) and gender (CelebA, Adult) as sensitive attributes.
QA notes: Technical ML-systems paper on algorithmic fairness in federated learning. Strong: explicit fairness metric (DP) and operationalization, detailed method (AFed-G and AFed-GAN; aux sensitive-attribute head; latent-space generation; mixup derivative regularizer), and extensive empirical evaluation/ablations on multiple datasets with non-i.i.d. splits. Weak/partial for RE lifecycle extraction: no explicit stakeholder elicitation process; no monitoring/revision/governance procedure for post-deployment; no fixed numeric acceptance criteria (fairness/accuracy selected via λ trade-off).
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
Spec explicitness/testability: Explicit + testable
Spec snippet: “The task of fair supervised learning is to train a classification model f that can accurately label samples while minimizing discrimination… The discrimination level in terms of DP can be measured by the absolute difference… ΔDP = |γ0(Ŷ) − γ1(Ŷ)|.”
Specification format: Constraint (formal/informal), NFR statement
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Users
Study ID: P104
System Type: Classification
Threshold value: DP target is ΔDP→0; no fixed numeric threshold. Fairness controlled via λ (trade-off hyperparameter) and mixup Beta(α,α) parameter (α not fixed in excerpt).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: Empirical evaluation on four datasets (UTKFace, FairFace, CelebA, Adult) under non-i.i.d. client splits; compares AFed-G/AFed-GAN against FL baselines (FedAvg, FedReg, FairFed, FairFB, FedGFT) and centralized fair mixup; reports accuracy–ΔDP trade-offs and ablations (aux head, participant ratio).
Validation/testing present: Yes
Venue Type: Journal
Year: 2025