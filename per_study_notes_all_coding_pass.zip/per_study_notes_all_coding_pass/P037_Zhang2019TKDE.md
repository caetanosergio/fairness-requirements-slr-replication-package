# P037 — Zhang2019TKDE

Acceptance criteria stated: Yes
Citation: Zhang2019TKDE
DES content: Yes
DES explicit requirement: Yes
DES snippet: Models direct and indirect discrimination as causal path-specific effects in a causal graph; provides criteria (SE_pd, SE_pi > t) and algorithms (PSE-DD discovery; PSE-DR removal via optimizing modified CPT of decision node under discrimination constraints) including handling unidentifiable indirect effects via upper/lower bounds.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames anti-discrimination as a legal/ethical requirement, citing laws like the Equal Credit Opportunity Act and distinguishing direct vs indirect discrimination (e.g., redlining via ZIP code as proxy for race), motivating non-discrimination constraints on data and decisions.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Other, Outcome parity
Gap summary (1 sentence): Provides a causal, testable specification of direct and indirect discrimination (path-specific effects with legal threshold t) and utility-preserving removal algorithms with bounds for unidentifiable cases, but does not address sociotechnical governance or how fairness requirements remain valid under deployment-time drift.
Governance maturity: Absent
Measurement procedure: 1) Learn causal graph (e.g., PC algorithm via TETRAD). 2) Compute SE_pd and SE_pi using path-specific effect formulas; if recanting witness criterion holds, compute bounds ub/lb for SE_pi. 3) Discovery flags direct/indirect discrimination when SE>t. 4) Removal: solve quadratic program to modify CPT P(e|pa_E) minimizing Euclidean/χ² distance between joint distributions subject to discrimination constraints; generate modified dataset from resulting causal model; re-test discrimination and evaluate downstream classifier outcomes.
Metrics used: Causal path-specific effects (SE_pd for direct; SE_pi for indirect) computed from observational data on a learned causal graph using truncated factorization; discrimination threshold t (default 0.05; examples include 0.05 legal threshold) used as acceptance bound. Also reports utility loss as χ² distance between original and modified joint distributions; evaluates downstream classifier discrimination after preprocessing.
Monitoring present: No
Notes: Maps well to your ‘requirements as testable constraints’ theme: explicit acceptance bound t and a decision rule (modify CPT) tied to measured discrimination effects. Also provides a clear example of how legal/causal notions translate into measurable requirements.
Operationalization present: Yes
Protected attrs / groups: Protected attribute C examples include sex, race, age; redlining (unjustified) attributes R include ZIP code / marital_status / education level etc. Experiments: Adult (protected=sex, decision=income, redlining=marital_status and others in unidentifiable setting); Dutch Census (protected=sex, decision=occupation, redlining=marital_status).
QA notes: Strong RQ2 operationalization paper: formalizes discrimination as causal path-specific effects (direct vs indirect) with explicit threshold t; provides algorithms for discovery and removal with utility-preserving optimization, plus treatment of unidentifiable indirect effects via bounds (recanting witness/kite pattern). Evaluates on real datasets and checks downstream prediction discrimination. Limited on SOC/over-time: no monitoring or revision process; focuses on pre-release data remediation and offline evaluation; acknowledges future work on fair predictive models.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: No
SOC explicit requirement: Unclear
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines direct discrimination as pd-specific effect SE_pd(c⁺,c) along C→E and indirect discrimination as pi-specific effect SE_pi(c⁺,c) along paths through redlining attributes R; discrimination exists if SE > t for either direction, where t is a user-defined legal threshold (e.g., 0.05 in British sex-discrimination legislation).
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Auditors/Compliance, Developers, Other, Regulators
Study ID: P037
System Type: Decision support
Threshold value: Discrimination threshold t: default 0.05 (varied 0.025–0.1); cites example legal threshold t=0.05. Constraints require SE_pd and SE_pi ≤ t (both directions) after removal.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Experiments on Adult and Dutch Census datasets evaluate discrimination discovery/removal, utility loss, and whether classifiers trained on modified data still produce discriminatory predictions; also analyzes unidentifiable situations via bounds and compares refined vs crude removal.
Validation/testing present: Yes
Venue Type: Journal
Year: 2019