# P013 — BarocasSelbst2016

Acceptance criteria stated: Partial
Citation: BarocasSelbst2016
DES content: Yes
DES explicit requirement: Partial
DES snippet: Provides a taxonomy of technical mechanisms by which data mining can produce discriminatory outcomes across the pipeline (target variable and class labels, training data labeling/collection, feature selection, proxies, masking), highlighting how design choices operationalize or undermine legal fairness requirements.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Conceptual
Domain: Hiring
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Analyzes algorithmic discrimination through the lens of U.S. anti-discrimination law (Title VII) and disparate impact doctrine; frames fairness as non-discrimination obligations toward protected classes and highlights tensions between anticlassification and antisubordination theories.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Missing context assumptions, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Other, Procedural fairness
Gap summary (1 sentence): Provides a legally grounded taxonomy linking data-mining pipeline choices to disparate impact risks and doctrinal criteria (including the EEOC four-fifths guideline and business necessity analysis), but offers no concrete, testable engineering acceptance criteria or lifecycle monitoring/revision mechanisms to maintain fairness over time.
Governance maturity: Absent
Measurement procedure: Conceptual/legal analysis (not an empirical study): identify where discrimination can arise in data mining (target definition, labeling, collection, feature selection, proxies, masking). Evaluate how Title VII disparate treatment vs disparate impact doctrines apply, including evidentiary burdens, business necessity/job-relatedness defenses, and practical difficulties in proving/repairing discrimination.
Metrics used: Primarily legal/analytical operationalization: disparate impact measured as statistical disparity in selection rates (EEOC ‘four-fifths’ / 80% rule as guideline) and doctrinal tests for disparate impact liability (show disparate impact, then business necessity/job-relatedness, then less discriminatory alternative). Provides conceptual mapping from ML pipeline steps to potential disparate impact mechanisms.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected classes under Title VII (race, sex, national origin, etc.); discusses historical disadvantage, vulnerable groups; examples include employment, credit, housing; references race-related proxying and disparate outcomes.
QA notes: Key contribution is a detailed, legally grounded taxonomy of how data mining discriminates across the ML pipeline and how (and why) Title VII disparate impact / disparate treatment doctrine struggles to address unintentional algorithmic discrimination. Provides requirements-relevant ENV foundations and design-time failure mechanisms, but does not give testable system acceptance criteria beyond legal guidelines and includes no empirical validation/monitoring/revision process.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: p
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Discusses institutional discrimination, proof challenges, accountability, and the limits of existing legal doctrine for regulating algorithmic decision making; addresses governance/policy reform difficulties but does not specify concrete monitoring or revision procedures for deployed systems.
Spec explicitness/testability: Explicit not testable
Spec snippet: Frames the core requirement as avoiding discriminatory effects on protected classes under Title VII (disparate treatment and disparate impact); discusses the four-fifths (80%) rule in EEOC Uniform Guidelines as a presumptive threshold for adverse impact, and the business necessity / job-relatedness defense and less discriminatory alternatives analysis.
Specification format: Narrative goal, Other, Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Org leadership, Other, Regulators
Study ID: P013
System Type: Decision support
Threshold value: EEOC Uniform Guidelines ‘four-fifths’ / 80% rule for adverse impact (as a guideline, not a strict legal formula).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Journal
Year: 2016