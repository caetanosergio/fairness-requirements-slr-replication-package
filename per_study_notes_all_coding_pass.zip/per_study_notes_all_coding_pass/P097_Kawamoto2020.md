# P097 — Kawamoto2020

Acceptance criteria stated: No
Citation: Kawamoto, Yusuke. "Towards Logical Specification of Statistical Machine Learning." arXiv:1907.10327v2 [cs.LO] (28 Mar 2020).
DES content: Yes
DES snippet: Proposes a distributional Kripke model + statistical epistemic logic (StatEL) to formalize statistical classification properties. Encodes performance (confusion-matrix metrics), robustness (via divergence-based accessibility relations between perturbed-input worlds), and fairness (via conditional indistinguishability) in logical formulas; introduces counterfactual epistemic operators to express fairness notions.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Conceptual
Domain: General
ENV content: Yes
ENV snippet: Motivates a gap: while robustness verification/testing for ML (especially DNNs) has advanced, formal specification of ML properties is relatively underdeveloped; positions logical approaches as useful for classifying/relating desired security and ML properties (performance, robustness, fairness).
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Introduces a rigorous logical specification framework (StatEL + distributional Kripke models + counterfactual epistemic operators) for performance, robustness, and fairness properties of classifiers, but does not provide empirical validation or scalable checking/model-checking procedures nor any deployment-time monitoring/revision governance.
Governance maturity: Absent
Measurement procedure: Defines a distributional Kripke model where each possible world is a probability distribution over states; assigns measurement variables (input x, true label y, predicted label ŷ) with stochastic semantics. Uses divergence/metric-based accessibility relations (e.g., total variation on outputs, Wasserstein on inputs) to interpret epistemic operators. Formalizes performance via conditional probabilities (e.g., Precision: ψ_ℓ(x) ⊃ P_I h_ℓ(x)); robustness via K^D_ε over perturbed-input worlds; fairness via counterfactual operators expressing conditional indistinguishability.
Metrics used: Formal logical counterparts of confusion-matrix metrics (precision/recall/accuracy, FPR/FNR etc.) and fairness notions (statistical parity/group fairness, individual fairness as Lipschitz continuity, equal opportunity) expressed as StatEL formulas; robustness expressed via divergence/metric constraints between input distributions (e.g., Wasserstein, total variation) and knowledge operators.
Monitoring present: No
Notes: Primarily a specification language / formalization contribution. Explicitly notes it does not provide checking/guaranteeing/improving methods; leaves testing/model checking for future work.
Operationalization present: Yes
Protected attrs / groups: Discusses protected attributes and groups abstractly; uses group membership predicates η_G(x) and compares groups G0 vs G1 in statistical parity and equal opportunity formulas; does not fix a domain-specific protected attribute list in the formalism.
QA notes: Strong formal/specification paper: clear logical language (StatEL) and semantics, with explicit formalizations of common performance metrics, robustness notions, and several fairness definitions using counterfactual epistemic operators. It explicitly states it does not provide checking/guarantees/improvement or empirical evaluation; limitations include lack of scalable model checking/testing algorithms and limited coverage of system/process-level aspects (monitoring, revision, data/learning pipeline issues).
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Frames robustness and fairness of ML as safety/security concerns in real-world systems; fairness is treated as indistinguishability/impact parity across groups/individuals and formalized using counterfactual knowledge operators (conceptual contribution rather than empirical study).
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines StatEL syntax/semantics (probability quantification, conditional probability, epistemic operators over divergence-based accessibility) and uses it to formally define metrics like precision/recall/accuracy, robustness properties (e.g., K^D_ε Recall), and fairness properties (statistical parity, individual fairness as Lipschitz, equal opportunity) as logical formulas.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Study ID: P097
System Type: Classification
Threshold value: Abstract thresholds/parameters: ε for divergences/metrics defining accessibility; δ for robustness probability bounds; intervals I for probability constraints (e.g., P_(0.95,1]); significance level α and sample size n appear in the StatEL background (statistical secrecy) but the ML-spec paper is primarily about specification rather than selecting numeric thresholds.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Preprint
Year: 2020