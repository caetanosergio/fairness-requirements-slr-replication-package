# P024 — Liu2018Delayed

Acceptance criteria stated: Partial
Citation: Liu2018Delayed
DES content: No
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: Lending
ENV content: No
Elicitation present: No
End-to-end coverage: Partial
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Shows that static fairness constraints can worsen protected-group long-term outcomes under feedback, motivating fairness requirements that explicitly model delayed impact and measurement error; does not provide concrete deployment-time monitoring or revision processes.
Governance maturity: Absent
Measurement procedure: Model: two-group score distributions π_A, π_B over discrete score set X; success probability ρ(x); institution utility u(x); outcome Δ(x) as expected score change if selected. Evaluate fairness constraints by solving utility maximization under (i) no constraint, (ii) equal selection rate, (iii) equal TPR, then compute Δμ outcomes. Empirics: FICO TransUnion TransRisk 2003 scores (300–850), default label (≥90 days delinquency within 18–24 months), set c+=75, c−=−150; compare MaxUtil vs DemParity vs EqOpt across bank profit/loss ratios.
Metrics used: Demographic parity (equal selection rates), equality of opportunity (equal TPR), MaxUtil utility U(τ); outcome metric is change in mean score Δμ_j(τ)=Σ_x π_j(x) τ_j(x) Δ(x); outcome curve maps selection rate β→Δμ.
Monitoring present: No
Notes: Key claim: static fairness constraints (DemParity/EqOpt) do not generally guarantee long-term improvement; can cause active harm in a one-step feedback model. Introduces 'outcome curve' and characterizes regimes; discusses measurement error and outcome-based alternative objective.
Operationalization present: Yes
Protected attrs / groups: Two groups A (protected/disadvantaged) and B; experiments on race groups (Black vs White non-Hispanic) using FICO credit scores.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines Demographic Parity as equal selection rates: Σ_x π_A(x) τ_A(x) = Σ_x π_B(x) τ_B(x). Defines Equal Opportunity as equal true positive rates: TPR_A(τ_A) = TPR_B(τ_B), where TPR_j(τ)= (Σ_x π_j(x) ρ(x) τ(x)) / (Σ_x π_j(x) ρ(x)).
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P024
System Type: Classification
Threshold value: Symbolic selection-rate thresholds: β_MaxUtil, harm threshold β0 (Δμ=0), outcome-optimal β*; plus group-dependent score thresholds (not given as fixed numbers).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: "We perform experiments on FICO credit score data from 2003 ... and show that under various models of bank utility and score change, the outcomes of applying fairness criteria are in line with our theoretical predictions."
Validation/testing present: Yes
Venue Type: Conference
Year: 2018