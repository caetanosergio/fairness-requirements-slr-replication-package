# P088 — Bertrand2004

Acceptance criteria stated: No
Citation: Bertrand2004
DES content: No
Data Type: Tabular
Decision rule tied to metric: No
Domain: Hiring
ENV content: Yes
ENV snippet: Every measure of economic success reveals significant racial inequality in the US labor market... debate on whether employers discriminate by race.
Elicitation present: No
End-to-end coverage: Partial
Fairness notions: Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Provides strong empirical evidence of hiring discrimination via name signaling and unequal returns to credentials, but does not propose a fairness requirement specification with explicit thresholds, acceptance criteria, monitoring, or revision processes.
Governance maturity: Absent
Measurement procedure: Send fictitious resumes to help-wanted ads (Boston/Chicago); randomize racially distinctive names and resume quality; measure employer callbacks for interviews.
Metrics used: Callback rate; callback ratio/difference (White-sounding vs African-American-sounding names)
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Race (African-American vs White, proxied by name); gender (varied for some job categories)
QA notes: Field/correspondence experiment (resume audit). Reports significant race-based callback disparities and lower returns to resume quality for African-American-sounding names; discusses confounds (social class proxy) and limitations (callbacks vs hires; name-based race signal).
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision present: No
SOC content: Yes
SOC snippet: White names receive 50 percent more callbacks for interviews... Discrimination therefore appears to bite twice...
Spec explicitness/testability: Explicit not testable
Spec snippet: We perform a field experiment to measure racial discrimination in the labor market... The results show significant discrimination against African-American names: White names receive 50 percent more callbacks for interviews.
Specification format: Other
Specification present: Yes
Study ID: P088
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: We respond with fictitious resumes to help-wanted ads... measure the number of callbacks each resume receives for interviews.
Validation/testing present: Yes
Venue Type: Journal
Year: 2004