# P096 — Chakraborty2020Fairway

Acceptance criteria stated: Partial
Citation: Chakraborty, Joymallya, Suvodeep Majumder, Zhe Yu, and Tim Menzies. "Fairway: A Way to Build Fair ML Software." In Proceedings of the 28th ACM Joint European Software Engineering Conference and Symposium on the Foundations of Software Engineering (ESEC/FSE '20), 654–665. Virtual Event, USA, Nov 8–13, 2020. ACM. https://doi.org/10.1145/3368089.3409697
DES content: Yes
DES snippet: Proposes Fairway, a combined pipeline: (1) pre-processing to detect and remove/clean ambiguous (potentially biased) training points via training separate models on privileged vs unprivileged groups and removing points where predictions disagree, then (2) in-processing via multi-objective hyperparameter optimization (FAIR_FLASH, FLASH-based SMBO) to reduce fairness metrics while preserving predictive performance (recall/false alarm).
Data Type: Tabular
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: Positions fairness as a critical non-functional requirement for ML software used in high-stakes domains (finance, hiring, admissions, criminal justice, healthcare) and argues bias can be injected across the ML/SE lifecycle; proposes that bias testing and mitigation should be routine parts of ML software development.
Elicitation method: Not described
Elicitation present: Yes
Elicitation snippet: No explicit stakeholder elicitation study; motivation includes a claim that fairness testing/mitigation should be routine in the ML software development lifecycle and highlights practitioner usability concerns (comprehensible method).
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides a concrete, implementable pipeline for bias detection (training-data ambiguity via group-conditioned models + situation testing) and mitigation (multi-objective hyperparameter optimization) with explicit group-fairness metrics, but does not specify deployment-time monitoring, drift handling, or clear acceptance thresholds/decision rules for when a model is “fair enough.”
Governance maturity: Absent
Measurement procedure: Train baseline logistic regression (scikit-learn defaults) and measure recall/FAR and fairness metrics (AOD/EOD). Pre-processing: split data by protected attribute into privileged vs unprivileged groups, train separate models, flag “ambiguous” training points where group-conditioned models disagree, drop them (or suggest relabeling as future work). In-processing: tune model hyperparameters with FAIR_FLASH (CART surrogate model + acquisition) to optimize multiple objectives (higher recall, lower FAR, lower AOD, lower EOD) on validation set; report medians over 10 random shuffles.
Metrics used: Equal Opportunity Difference (EOD) and Average Odds Difference (AOD) (absolute values) computed from confusion matrices for privileged vs unprivileged groups; predictive performance metrics: recall and false alarm rate; additional bias indicator via situation testing (% points where prediction flips when protected attribute is toggled).
Monitoring present: No
Notes: Strong SE-oriented framing: fairness as NFR and lifecycle activity; operationalization is group-metric based + data cleaning + hyperparameter optimization. Does not cover post-deployment monitoring or revision triggers/ownership.
Operationalization present: Yes
Protected attrs / groups: Protected attributes include sex, race, age (dataset-dependent). Privileged/unprivileged group definitions given per dataset (e.g., Adult: male vs female; white vs non-white; COMPAS: caucasian vs not caucasian; etc.).
QA notes: Clear SE motivation and detailed method (pre-process ambiguous points + FAIR_FLASH multi-objective tuning) with explicit metrics (AOD/EOD, recall/FAR) and repeated experiments across 5 datasets; includes threats-to-validity and notes metric shortcomings (class imbalance, sampling, cost). Limited on stakeholder elicitation and on lifecycle governance beyond offline evaluation (no monitoring/revision plan or acceptance thresholds).
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Frames harm as “algorithmic discrimination” that advantages privileged groups (sex/race/etc.) and disadvantages unprivileged groups; uses real examples (e.g., facial recognition, recruiting) to motivate; treats fairness as a socio-technical quality attribute and emphasizes comprehensibility for practitioners.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines fairness for binary classification via group fairness goals and operationalizes with metrics EOD (TPR_U − TPR_P) and AOD = 0.5*[(FPR_U − FPR_P)+(TPR_U − TPR_P)], using absolute values; also uses situation testing (change protected attribute and check prediction change) as a bias indicator.
Specification format: Constraint (formal/informal), NFR statement
Specification present: Yes
Study ID: P096
System Type: Classification
Threshold value: Uses train/validation/test split (70/15/15), repeated experiments (10 shuffles). Uses FLASH stopping criterion via “life” parameter; does not define a domain acceptance threshold for AOD/EOD (treated as lower is better).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates on five UCI datasets (Adult, COMPAS, German Credit, Default Credit, Heart Health) using logistic regression; compares baseline vs pre-processing vs optimization vs Fairway and against selected AIF360 baselines; reports improvements in AOD/EOD with limited performance degradation and reduced situation-testing failures.
Validation/testing present: Yes
Venue Type: Conference
Year: 2020