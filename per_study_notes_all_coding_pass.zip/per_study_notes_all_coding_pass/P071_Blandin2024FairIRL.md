# P071 — Blandin2024FairIRL

Acceptance criteria stated: Yes
Citation: Blandin2024FairIRL
DES content: Yes
DES explicit requirement: Yes
DES snippet: Frames group fairness in classification as an inverse reinforcement learning (IRL) problem: represent accuracy and fairness metrics as weighted reward components and recover expert fairness-preference weights from demonstrations; then optimize a new classifier in a target domain using the learned weights via linear programming.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates that fairness is hard to define in new domains and typically requires manual fine-tuning of fairness trade-offs; proposes a “low-touch” method to adapt fairness preferences across domains and under covariate shift.
Elicitation artifact: Other
Elicitation method: Expert elicitation
Elicitation present: Yes
Elicitation snippet: Infers fairness preferences from expert demonstrations (historical decisions/predictions) rather than repeated interactive elicitation; experts can be humans (e.g., admissions board) or existing fairness algorithms producing predictions.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides an explicit, testable operationalization of “fairness preferences” via learned reward weights and demonstrates cross-domain transfer under covariate shift, but does not specify deployment-time monitoring, acceptance thresholds for release, or governance for revising fairness preferences over time.
Governance maturity: Absent
Measurement procedure: Generate expert demonstrations by training expert fairness classifiers on a first data split, predicting on a second split to produce demonstrations, then run FairIRL to learn reward weights via iterative SVM max-margin separation of expert vs learned feature expectations; compute new classifier by solving a linear program with learned weights (classification-as-MDP special case). Evaluate on held-out split; test robustness to covariate shift (ACSIncome MA→MS) and transfer to new dataset (Adult→Boston Housing).
Metrics used: Fairness metrics used as feature expectations and/or evaluation: demographic parity (DemPar), equal opportunity (EqOpp), true negative rate parity (TNRPar), plus group rates (PR/NR/TPR/TNR per group); evaluates additional metrics not directly represented (e.g., equalized odds-related, predictive parity/negative predictive parity) and accuracy.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Binary sensitive attribute Z∈{0,1}; experiments set race as protected attribute (white vs non-white) in Adult and ACSIncome; Boston Housing uses race as whether proportion of Black residents exceeds median (binary).
QA notes: FAccT’24 paper introduces FairIRL: learn group fairness preference weights from expert demonstrations (human or algorithmic) using inverse RL / max-margin feature matching; represent accuracy and fairness metrics as reward components and solve for classifiers via LP. Evaluates recovery, covariate-shift generalization, and transfer (Adult/ACSIncome/Boston Housing). Notes limitations: biased demonstrators, IRL non-identifiability, incomplete metric coverage (calibration/predictive parity), and includes ethics/positionality/adverse impact statements. No monitoring/revision governance described.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Uses expert/human or algorithmic decision demonstrations as a proxy for fairness preferences; discusses risks of biased demonstrators and non-identifiability, and includes ethics/positionality/adverse impact statements, but does not define deployment governance, monitoring, or revision processes.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines group fairness metrics (e.g., demographic parity, equal opportunity) and models fairness + efficiency as a weighted reward R = w1·RAcc + w2·RDemPar + w3·REqOpp; learns weights w to match expert feature expectations within ε using max-margin IRL-style updates and then solves a linear program to compute a classifier optimizing learned weights.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Study ID: P071
System Type: Classification
Threshold value: Convergence threshold ε used to stop FairIRL iterations when SVM margin/error falls below ε (numeric value not provided in excerpt).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Experiments on Adult, ACSIncome, and Boston Housing show (i) recovery of expert fairness preferences (learned weights align with expert objectives), (ii) generalization under covariate shift (train on MA demos, apply to MS), and (iii) transfer to new dataset without target-domain demonstrations; compares to behavioral cloning baseline.
Validation/testing present: Yes
Venue Type: Conference
Year: 2024