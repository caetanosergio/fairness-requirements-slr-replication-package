# P083 — Li2025TOSEM

Acceptance criteria stated: Partial
Citation: Li2025TOSEM
DES content: Yes
DES snippet: “We evaluate eight state-of-the-art deep learning-based pedestrian detectors across demographic groups…”
Data Type: Image
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV snippet: “This article conducts fairness testing of automated pedestrian detection… in autonomous driving systems.”
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria
Gap summary (1 sentence): Thorough empirical group-fairness testing for pedestrian detection with rich demographic/scenario labeling, but lacks explicit deployment acceptance criteria, monitoring, and revision governance for operational use.
Governance maturity: Absent
Measurement procedure: Manually enrich four real-world driving datasets with demographic labels (gender: male/female; age: adult/child; skin tone: light/dark for BDD100k). Evaluate 8 DL pedestrian detectors (YOLOX, RetinaNet, Faster RCNN, Cascade RCNN, ALFNet, CSP, MGAN, PRNet) on 8,311 images; compute MR per group and EOD; analyze scenarios: brightness (day/night), contrast (RMS contrast levels 1–3), and weather (rainy/non-rainy); repeat experiments 10 times and average.
Metrics used: Group fairness via miss rate (MR) differences (equivalently SPD/EOD for detection). MR = 1 − TP/(TP+FN) with IoU>0.5 as successful detection. Two-proportion z-test with p<0.05 for significance.
Monitoring present: No
Notes: TOSEM 2025 article; fairness measured primarily as MR gaps (EOD/SPD) across demographics; largest bias found for children vs adults (+20.14% undetected on average). Publicly releases labels/code/data for replication.
Operationalization present: Yes
Protected attrs / groups: Sensitive attributes: gender (male/female), age (adult/child), skin tone (light-skin/dark-skin; only BDD100k). Privileged/unprivileged framing used in formulas (adult privileged vs child unprivileged).
QA notes: Empirical fairness testing study for autonomous driving pedestrian detection (vision). Strong dataset augmentation + inter-rater agreement (Cohen’s kappa) for demographic labels; scenario analysis shows fairness shifts (night increases gender bias; children consistently higher MR). Notes fairness-performance tradeoff may not hold under certain brightness/contrast conditions; includes threats to validity and implications for researchers/developers/policy makers.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC snippet: “pedestrian detectors demonstrate significant gender biases during night time, potentially exacerbating the prevalent societal issue of female safety concerns during nighttime out.”
Spec explicitness/testability: Explicit + testable
Spec snippet: “SPD quantifies… EOD quantifies… In summary, we use both SPD and EOD as fairness measures… we present only EOD.”
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P083
System Type: CV
Threshold value: p-value significance threshold 0.05; IoU threshold 0.5 for TP vs FN; MR thresholding for task definition uses detector confidence scoring (standard detector outputs; paper reports MR/EOD rather than a fixed decision threshold).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: “We evaluate eight state-of-the-art deep learning-based pedestrian detectors across demographic groups on large-scale real-world datasets.”
Validation/testing present: Yes
Venue Type: Journal
Year: 2025