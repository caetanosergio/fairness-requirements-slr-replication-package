# P076 — Holstein2019

Acceptance criteria stated: No
Citation: Holstein2019
DES content: Yes
DES explicit requirement: Partial
DES snippet: We identify areas of alignment and disconnect... while the fair ML literature has largely focused on “de-biasing” methods... most of our interviewees report that their teams consider data collection... the most important place to intervene.
Data Type: Other
Decision rule tied to metric: No
Deployment Status: Deployed
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: We investigate the challenges faced by commercial ML product teams... in monitoring for unfairness and taking appropriate action...
Elicitation artifact: Fairness notions list, Other, Stakeholder goals
Elicitation method: Interviews, Surveys
Elicitation present: Yes
Elicitation snippet: Through 35 semi-structured interviews and an anonymous survey of 267 ML practitioners...
End-to-end coverage: Partial
Failure modes: Missing context assumptions, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Contestability/recourse, Error parity, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Empirically elicits industry practitioners’ challenges/needs for fair ML across the development pipeline (data collection, auditing, debugging, human-in-the-loop biases), highlighting major socio-technical gaps and the absence of standardized, measurable acceptance criteria and revision governance for maintaining fairness requirements over time.
Governance maturity: Absent
Measurement procedure: Qualitative synthesis via contextual design (interpretation sessions + affinity diagramming) and quantitative survey (Likert items; percentages) across pipeline stages; not a fairness-metric computation procedure.
Metrics used: Fairness metrics discussed conceptually (between-group disparities; parity in error rates/decisions); also references fairness KPIs/metrics as practitioner need; no single metric adopted as a requirement.
Monitoring present: Yes
Monitoring signals: Monitoring for unfairness post-deployment; complaints, media coverage; auditing slices/subpopulations; fairness metrics/KPIs and automated tests (often missing, noted as need).
Monitoring snippet: We investigate... monitoring for unfairness... teams do not discover serious fairness issues until they receive customer complaints...
Operationalization present: Yes
Protected attrs / groups: Discusses demographics such as race, gender, age; also application-specific cohorts (e.g., native speaker status) and other subpopulations relevant to context; notes sensitive demographics often unavailable at individual level.
QA notes: Strong empirical methods (35 interviews + 267 survey) and detailed themes about practitioner needs. Focus is on needs/support, not on specifying a fairness requirement with measurable metric + threshold. Treat ‘operationalization’ here as operationalization of support needs and auditing processes, not metric-based requirement satisfaction; hence QA3=No and thresholds/acceptance criteria=No.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: We stress that biases and unfairness are fundamentally sociotechnical problems... technically focused research efforts must go hand-in-hand with efforts to improve organizational processes, policies, and education.
Spec explicitness/testability: Implicit
Spec snippet: We provided a broad definition: “Any case where AI/ML systems perform differently for different groups in ways that may be considered undesirable.”
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Users
Study ID: P076
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation method: User study
Validation snippet: We conducted... 35 semi-structured interviews... and an anonymous survey of 267 industry ML practitioners...
Validation/testing present: Yes
Venue Type: Conference
Year: 2019