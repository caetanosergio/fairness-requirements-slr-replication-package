# P063 — Beutel2019PairwiseRecFair

Acceptance criteria stated: No
Citation: Beutel2019PairwiseRecFair
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines pairwise fairness metrics for recommendation rankings using randomized pairwise experiments (positions 2 and 3) to estimate unbiased user preferences, decomposing fairness into overall, intra-group, and inter-group pairwise fairness. Proposes a pairwise regularization term added to pointwise model training to reduce group gaps in pairwise fairness and demonstrates improvements in a large-scale production recommender.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Deployed
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes recommender systems in production can create fairness risks by systematically under-ranking groups of items, affecting visibility and engagement for content producers/providers; notes recommender evaluation is biased due to dynamics and exposure, motivating randomized experiments for unbiased preference estimates.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Missing context assumptions, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Operationalizes recommender ranking fairness with experimentally measurable pairwise metrics and a training-time regularizer that closes inter-group under-ranking gaps in production, but does not state explicit acceptance thresholds or provide lifecycle monitoring/revision governance beyond periodic experimental evaluation.
Governance maturity: Absent
Measurement procedure: Run randomized experiments on a slice of queries by showing a random pair of relevant items in positions 2 and 3 with randomized order; record which item is clicked and subsequent engagement $z$; discretize $z$ into buckets; compute pairwise fairness probabilities and decompose into intra/inter-group. Train pointwise neural ranker with additional pairwise regularizer computed over experimental pair dataset $P$ (balanced by clicked-item group) to improve inter-group pairwise fairness; evaluate in production via relative subgroup vs non-subgroup gaps.
Metrics used: Pairwise fairness / pairwise accuracy metrics (overall, intra-group, inter-group), conditioned on engagement; exposure analysis; compares subgroup vs non-subgroup (relative ratios) and analyzes relation to pointwise metrics (calibration, MSE) showing insufficiency for ranking fairness.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Binary sensitive attribute on items (item-group membership); study focuses on a sensitive subgroup of items (~0.2% of items) vs non-subgroup; notes user-group extension possible but not core.
QA notes: KDD’19 paper introduces pairwise fairness metrics for recommender rankings using randomized pairwise experiments and a pairwise regularization term for pointwise rankers; demonstrates large inter-group gap reduction for a sensitive item subgroup in a production recommender. Strong operationalization and empirical evaluation; lacks stakeholder elicitation, explicit acceptance thresholds, and post-deployment monitoring/revision governance details.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames fairness as avoiding systematic under-exposure/under-ranking of item groups (e.g., demographic group posts) in sociotechnical platforms where creators/providers rely on ranking for voice and visibility; discusses that fairness evaluation depends on experimental measurement and that retrieval-stage fairness assumptions can propagate harms.
Spec explicitness/testability: Explicit + testable
Spec snippet: Specifies pairwise fairness as equality of conditional probabilities of ranking a clicked item above a relevant unclicked item across item groups, conditioned on engagement $z$ (Definitions 1–3), and provides measurement via randomized experiments and discretized engagement buckets.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Users
Study ID: P063
System Type: Ranking
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: Evaluated on a large-scale production recommender system using randomized experiments to estimate preferences and compare fairness gaps before/after pairwise regularization; reports substantial reduction of inter-group pairwise fairness gap (e.g., ~35.6% advantage down to ~2.6% in their production case study).
Validation/testing present: Yes
Venue Type: Conference
Year: 2019