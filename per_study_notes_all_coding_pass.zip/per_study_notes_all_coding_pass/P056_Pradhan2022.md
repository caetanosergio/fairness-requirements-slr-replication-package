# P056 — Pradhan2022

Acceptance criteria stated: Partial
Citation: Pradhan2022
DES content: Yes
DES explicit requirement: Yes
DES snippet: Introduces Gopher, a system for fairness debugging that generates compact, interpretable training-data-based explanations of model bias by finding cohesive subsets of the training data that are root causes, using a notion of causal responsibility (bias reduction when removing or updating a subset) and a top-k pattern mining search with pruning for support and diversity.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes a standard supervised ML pipeline where bias can originate in the training data (measurement errors, misclassifications, imbalance, selection bias, covariate shift, data prep issues, poisoning) and where auditing uses a fairness metric F evaluated on held-out test data (e.g., statistical parity, equal opportunity, predictive parity) w.r.t. a protected attribute S.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides a rigorous, testable framework and system (Gopher) for identifying training-data root causes of fairness violations via causal responsibility and pattern mining, but focuses on offline debugging interventions rather than operational monitoring, long-term governance, or stakeholder-driven acceptance thresholds.
Governance maturity: Absent
Measurement procedure: Compute a fairness metric F on a test set D_test (e.g., difference in positive prediction rate for statistical parity, difference in TPR for equal opportunity, difference in PPV for predictive parity). For a candidate subset S (or pattern-defined subset D(φ)), estimate the change in bias when intervening on training data by deleting or uniformly updating that subset; approximate retraining effects via first/second-order influence functions or one-step gradient descent; rank explanations by interestingness and enforce diversity via containment.
Metrics used: Statistical parity; Equal opportunity; Predictive parity (and notes applicability to other associational and causal notions).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected attribute S (binary in formulation). Experiments use: gender (Adult), age (German), race (SQF).
QA notes: SIGMOD’22 paper introducing Gopher for fairness debugging: patterns over training data subsets + causal responsibility; includes deletion- and update-based explanations with efficient approximations (FO/SO influence, one-step GD) and extensive offline evaluation on benchmark datasets. Strong operationalization and validation; limited stakeholder/elicitation treatment and limited deployment/monitoring governance.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames the motivation as regulatory and social demands for human-understandable explanations and the need to debug discriminatory behavior; discusses fairness as avoiding discrimination w.r.t. protected attributes and motivates actionable interventions on data subsets rather than only reporting bias.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines (i) bias metric F(θ, D_test) where F>0 indicates bias, and uses fairness metrics like statistical parity, equal opportunity, predictive parity; (ii) ‘root cause’ subsets whose removal reduces bias; (iii) causal responsibility RF(S) as relative bias reduction; (iv) pattern interestingness U(φ)=RF(D(φ))/Sup(φ) and diversity via containment threshold to compute top-k explanations.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Other, Regulators
Study ID: P056
System Type: Classification
Threshold value: Bias defined as F(θ,D_test)>0 (unbiased otherwise); uses containment threshold c and support threshold τ for explanation search (not a fixed fairness acceptance threshold).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates Gopher end-to-end on standard fairness datasets (German Credit, Adult Income, Stop-Question-Frisk) with logistic regression, SVM, and a feed-forward NN; compares influence approximation accuracy vs retraining and runtime; reports top-k explanations (patterns, support, bias reduction) and update-based explanations; includes scalability analysis.
Validation/testing present: Yes
Venue Type: Conference
Year: 2022