# P080 — Aggarwal2019

Acceptance criteria stated: No
Citation: Aggarwal2019
DES content: Yes
DES snippet: “Our approach combines two well-established techniques - symbolic execution and local explainability for effective test case generation.”
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: “Individual discrimination” exists when a given individual different from another only in “protected attributes” (e.g., age, gender, race, etc.) receives a different decision outcome…
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria
Gap summary (1 sentence): Strong test-generation/validation for individual discrimination in black-box models, but no stakeholder elicitation, no acceptance thresholds, and no monitoring/revision governance.
Governance maturity: Absent
Measurement procedure: Generate test cases (non-protected attribute combinations) using Symbolic Generation (SG): use seed data + KMeans clustering; derive local decision-tree path using LIME; toggle high-confidence predicates (threshold T1=0.3) for global search; when discriminatory input found, do local symbolic search; check discrimination by enumerating combinations of protected attribute values and comparing outputs.
Metrics used: Individual discrimination (pairwise counterfactual consistency: differing only in protected attribute but different decision). Success score = |Succ|/|Gen| for test generation. Path coverage (decision regions covered via decision tree approximation).
Monitoring present: No
Notes: Uses LIME decision tree path as symbolic-execution ‘path’ for black-box models; uses seed data clustering (KMeans, k=4) and confidence threshold T1=0.3; local search uses ‘sticky solutions’ near discriminatory path; experiments largely on logistic regression models trained on fairness benchmarks (German credit, Adult, Bank marketing, US executions, etc.).
Operationalization present: Yes
Protected attrs / groups: Protected attributes P (examples used in experiments: gender, age, race, sex).
QA notes: Fairness notion is individual discrimination (non-probabilistic, strict equality on non-protected attrs; notes future work for continuous attrs/correlation handling). Black-box test generation via LIME decision-tree path + symbolic toggling; compares vs THEMIS and AEQUITAS across multiple benchmarks; provides threats to validity incl. limits for high-dimensional data and dependence on LIME approximation.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: “a system is said to be fair if for any two valid inputs which differ only in the protected attribute are always assigned the same class”
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P080
System Type: Classification
Thresholds stated: No
Trade-offs managed: Unclear
Validation method: Offline evaluation
Validation snippet: “We empirically compare our technique with the existing algorithms i.e. THEMIS, AEQUITAS and demonstrate the performance improvement…”
Validation/testing present: Yes
Venue Type: Conference
Year: 2019