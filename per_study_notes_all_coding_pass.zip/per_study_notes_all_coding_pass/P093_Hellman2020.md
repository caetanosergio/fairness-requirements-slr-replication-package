# P093 — Hellman2020

Acceptance criteria stated: No
Citation: Hellman, Deborah. "Measuring Algorithmic Fairness." Virginia Law Review 106, no. 4 (June 2020): 811–866. https://www.jstor.org/stable/10.2307/27074708
DES content: Yes
DES snippet: Distinguishes families of fairness measures (predictive parity / calibration vs error-rate parity) and argues they target different tasks (belief vs action). Proposes prioritizing error-ratio parity as an indicator of potential unfairness, and argues overall accuracy improvements can reduce unfairness; also argues legal doctrine is not categorically opposed to using protected traits within algorithms to improve accuracy/fairness.
Decision rule tied to metric: Unclear
Domain: General
ENV content: Yes
ENV snippet: Frames algorithmic decision-making as increasingly common and controversial due to concerns about transparency, accountability, and fairness; uses COMPAS / ProPublica vs Northpointe debate to motivate why measuring fairness is fraught and why base rates + measurement error matter.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Missing context assumptions, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides a clear conceptual, normative, and legal argument for prioritizing error-ratio concerns over calibration as a fairness signal and for permissibility of using protected traits to improve accuracy, but does not provide operational RE artifacts (elicitation, testable acceptance criteria, monitoring signals, or revision governance) to turn these fairness ideas into lifecycle requirements.
Governance maturity: Absent
Measurement procedure: Conceptual/normative legal-philosophical analysis using confusion matrices to define PPV/NPV and error rates; analyzes trade-offs under different base rates and discusses implications of measurement error (e.g., arrests as proxy for crime) and compounding injustice.
Metrics used: Discusses fairness measures rather than proposing a single metric to implement: calibration/predictive parity (PPV/NPV meaning of scores across groups) vs false positive/false negative rates and their ratio (error ratio parity).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Focuses on legally protected groups (especially race; also sex) in algorithmic scoring contexts; uses black/white examples and discusses protected classifications in anti-discrimination law.
QA notes: Strong conceptual + normative framing of fairness measurement (calibration vs error-rate parity) with clear worked examples (confusion matrices) and explicit discussion of measurement error and compounding injustice. It does not provide an empirical evaluation of an algorithm or propose a concrete, testable requirements/monitoring framework; operational guidance is mainly argumentative and legal-doctrinal (when use of protected traits may be permissible) rather than implementable acceptance criteria.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Argues disparities in error ratios matter because they can indicate biased measurement (e.g., arrests vs true offending) or compounding prior injustice, raising moral reasons to scrutinize data and to hesitate in deploying tools that entrench prior inequities.
Spec explicitness/testability: Explicit not testable
Spec snippet: Asks which fairness measure to prioritize when predictive parity (calibration) and error-rate parity cannot both be satisfied under differing base rates; argues predictive parity is about what to believe, while error ratios relate to decision/action and can signal unfairness.
Specification format: Narrative goal, Other
Specification present: Yes
Study ID: P093
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Journal
Year: 2020