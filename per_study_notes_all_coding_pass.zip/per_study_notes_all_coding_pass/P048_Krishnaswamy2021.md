# P048 — Krishnaswamy2021

Acceptance criteria stated: Partial
Citation: Krishnaswamy2021
DES content: Yes
DES explicit requirement: Yes
DES snippet: Introduces two algorithmic frameworks for best-effort group fairness guarantees in classification: (1) Proportional Fairness (PF) classifier when considering all possible groups, and (2) BeFair (Best-effort Fair) approach for more structured group classes (e.g., linearly separable groups), using a minmax/fictitious-play style procedure and convex relaxations.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Frames deployment contexts (criminal justice, credit/lending, healthcare) as high-stakes and motivates fairness due to disparate impact/bias; argues that standard fairness depends on pre-specified protected groups which may be missing, unusable, or mis-specified.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: No revision process/ownership, No thresholds / acceptance criteria, Other, Unstable subgroup definitions
Fairness notions: Error parity, Individual consistency, Other, Outcome parity
Gap summary (1 sentence): Proposes best-effort group fairness guarantees that compare each group’s performance to the best achievable on that group (PF for all subgroups, BeFair for structured subgroup classes), showing empirically improved worst-group fidelity versus ERM, but it remains largely an offline optimization/evaluation approach without operational monitoring or governance processes for maintaining guarantees over time.
Governance maturity: Absent
Measurement procedure: Formal model: define groups g u2286 N, u_g(h) as mean correctness over g, and h*g maximizing u_g over H. For PF: optimize u2211_i ln u_i(h) over randomized classifiers u0394(H) and prove worst-case subgroup guarantees. For BeFair: define err_g(h) and solve min_h err_N(h) subject to best-effort constraints for all g in a structured group class; recast into min-max game, use fictitious play, with learner best response as weighted ERM and adversary best response approximated via convex relaxation; evaluate on Adult and COMPAS datasets using overall accuracy and MAEu03b4.
Metrics used: Group-wise accuracy / error rate (err_g); PF utility u_g(h) and individual utilities u_i(h); MAE_u03b4(h)=max_g err_g(h) u2212 u03b4·err_g(h*g) as evaluation metric for best-effort fidelity; reports overall test accuracy and MAEu03b4 curves for Adult and COMPAS benchmarks.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Motivates protected groups like race and gender but key contribution is handling unknown/unobserved/mis-specified groups. Considers group class G as (a) all subsets of the data (2^N) and (b) structured groups such as linearly separable groups; experiments use Adult/COMPAS (which include sensitive attributes like race/sex, but the framework is not limited to a fixed list).
QA notes: AISTATS 2021 paper defining “best-effort” fairness: guarantee each group g achieves performance close to its own optimum (h*g), addressing harms of absolute parity-style constraints and the problem of unknown/mis-specified groups. Provides PF theoretical guarantees for all subgroups (2^N) and BeFair algorithm for linearly separable groups via min-max formulation, fictitious play, and convex relaxation; evaluates on Adult and COMPAS using MAEu03b4. No stakeholder elicitation methods; governance/monitoring are not treated beyond offline evaluation.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Discusses societal risks and unintended consequences of group mis-specification and reliance on sensitive attributes (legal constraints, treatment parity, heterogeneous populations, resentment), and uses fairness notions (parity/equalized odds) as potentially harmful when groups differ in intrinsic difficulty; positions best-effort guarantees as reducing harm to easier-to-classify groups while still protecting harder groups.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines a best-effort fairness constraint relative to each group’s optimal achievable performance: for all groups g in a class G, guarantee performance of h on g compared with h_g. For G=2^N, PF maximizes u2211_i ln u_i(h) and guarantees u_g(hPF) u2265 |g|/|N| for any perfectly-classifiable subgroup. For structured G (linearly separable groups), formulates BeFair(u03b3): minimize overall error s.t. u2200g, err_g(h) u2264 err_g(h_g)+u03b3 (or u03b4·err_g(h*_g)+u03b3), solved via min-max game with learner/adversary best responses and convexification of the adversary subproblem.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Regulators
Study ID: P048
System Type: Classification
Threshold value: BeFair uses additive u03b3 and multiplicative u03b4 parameters; experiments sweep u03b4 (e.g., 1.0 to 1.30) and report MAE_u03b4, with example results that u03b4u22481.10 yields MAE u22481% on benchmarks (as reported).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Empirical evaluation on Adult (UCI) and COMPAS datasets: compares ERM baselines (logistic regression, AdaBoost) vs PF heuristic and u03b4-BeFair; reports overall test accuracy and computes MAE_u03b4(h) over linearly separable groups for varying u03b4, showing substantial improvements of BeFair over ERM and low MAE for small u03b4>1.
Validation/testing present: Yes
Venue Type: Conference
Year: 2021