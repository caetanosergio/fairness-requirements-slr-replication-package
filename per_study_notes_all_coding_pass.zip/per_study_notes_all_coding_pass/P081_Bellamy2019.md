# P081 — Bellamy2019

Acceptance criteria stated: No
Citation: Bellamy2019
DES content: Yes
DES snippet: “AIF360 is designed as an end-to-end workflow with two goals: (a) ease of use and (b) extensibility.”
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: “Fairness is an increasingly important concern as machine learning models are used to support decision making in high-stakes applications such as mortgage lending, hiring, and prison sentencing.”
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria
Gap summary (1 sentence): Comprehensive fairness metrics+mitigation toolkit and pipeline abstractions, but it does not define domain-specific acceptance thresholds/decision rules and provides limited guidance on governance, monitoring, or revision in deployment.
Governance maturity: Absent
Measurement procedure: Compute dataset and classification fairness metrics via Metric classes over one or two Dataset objects; evaluate mitigation algorithms in pre-/in-/post-processing pipeline (fit/transform/predict). Example evaluation uses 25 random train/val/test splits; fairness metrics computed before/after mitigation and on predicted labels; classifiers include LR/RF/NN.
Metrics used: Toolkit implements bias detection metrics (e.g., disparate impact (DI), statistical parity difference (SPD), average odds difference, equal opportunity difference; generalized entropy index for individual+group unfairness; consistency (individual fairness).
Monitoring present: No
Notes: AIF360 open-source Python toolkit (Apache v2.0) + web demo; designed to bridge research-to-industry. Provides 70+ metrics and 9 mitigation algorithms across pre-/in-/post-processing; scikit-learn-like API; dataset abstraction with protected attributes and provenance pointer to prior dataset state.
Operationalization present: Yes
Protected attrs / groups: Protected attributes (examples: race, sex/gender, age, caste, religion). Privileged vs unprivileged groups defined per protected attribute; favorable vs unfavorable label.
QA notes: Primarily a toolkit/architecture + metrics/algorithms catalog paper; provides terminology and pipeline abstractions (Dataset, Metric, Explainer, Transformer). Includes evaluation on Adult, German Credit, COMPAS with multiple metrics and mitigation algorithms; emphasizes industrial usability, extensibility, documentation, and CI/testing. Mentions explanation capability (reporting; future: localization, recourse, counterfactuals).
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC snippet: “...an interactive Web experience ... for line-of-business users, as well as extensive documentation, usage guidance, and industry-specific tutorials...”
Spec explicitness/testability: Explicit not testable
Spec snippet: “A protected attribute is an attribute that partitions a population into groups… Group fairness is the goal of groups defined by protected attributes receiving similar treatments or outcomes… A fairness metric is a quantification of unwanted bias…”
Specification format: Narrative goal, Other
Specification present: Yes
Study ID: P081
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: “Table 2 provides the datasets, metrics, classifiers, and bias mitigation algorithms used in our experiments.”
Validation/testing present: Yes
Venue Type: Preprint
Year: 2019