# P025 — Zhang2018Adversarial

Acceptance criteria stated: Partial
Citation: Zhang2018Adversarial
DES content: No
Data Type: Multi-modal
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: No
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Missing context assumptions, No revision process/ownership, Other
Fairness notions: Error parity, Outcome parity
Gap summary (1 sentence): Provides explicit, testable fairness constraints and an adversarial operationalization with offline evaluation across tasks, but treats fairness as a design-time model property without stakeholder elicitation, deployment monitoring, or revision governance.
Governance maturity: Absent
Measurement procedure: Adversarial debiasing: train predictor to minimize task loss L_P while reducing adversary’s ability to infer protected variable Z from Ŷ (DemParity) or from (Ŷ,Y) (EqOdds). Update rule uses ∇_W L_P − proj_{∇_W L_P}(∇_W L_A) − α∇_W L_A. Evaluate on (i) toy scenario, (ii) word-embedding analogies (gender subspace via PCA on gender word pairs), and (iii) UCI Adult income prediction with sex as protected attribute; report confusion matrices and subgroup FPR/FNR and z-tests for differences.
Metrics used: Fairness constraints: Demographic Parity, Equality of Odds, Equality of Opportunity (Hardt et al. 2016). Uses group-wise error rates (FPR, FNR, TPR) and confusion matrices; reports achieving equality of odds within ~1% across sex groups on UCI Adult.
Monitoring present: No
Notes: Focus is model-level mitigation via adversarial learning; provides theoretical guarantees under convex/concave assumptions and discusses training instability/local minima and hyperparameter scheduling (α). No deployment monitoring/revision process.
Operationalization present: Yes
Protected attrs / groups: Protected variable Z (examples: gender; zip code as proxy). Experiments report subgroup metrics for sex (Male vs Female); discussion references race/ethnicity and gender.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines Demographic Parity: Ŷ ⟂ Z, i.e., P(Ŷ=ŷ)=P(Ŷ=ŷ|Z=z). Defines Equality of Odds: (Ŷ ⟂ Z)|Y, i.e., P(Ŷ=ŷ|Y=y)=P(Ŷ=ŷ|Z=z,Y=y). Defines Equality of Opportunity as conditional independence on Y=y.
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P025
System Type: Classification
Threshold value: Example operational target: equality of odds achieved within 1% across protected groups (sex) on UCI Adult; no general deployment threshold policy specified.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Reports empirical results on word analogies and UCI Adult; provides subgroup confusion matrices and FPR/FNR, noting debiasing yields near equality of odds with small accuracy change (86.0% vs 84.5%).
Validation/testing present: Yes
Venue Type: Conference
Year: 2018