# P110 — She2025FairSense

Acceptance criteria stated: No
Citation: She2025FairSense
DES content: Yes
DES snippet: FAIRSENSE performs Monte-Carlo simulation to enumerate evolution traces for each system configuration ... performs sensitivity analysis on the space of possible configurations to understand the impact of design options and environmental factors.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV snippet: Many ML-enabled systems operate in a dynamic environment where the predictive decisions made by the system impact the environment, which in turn affects future decision-making.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Monitoring without triggers, No revision process/ownership, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides simulation-based, design-time evaluation of long-term fairness under feedback loops with sensitivity and trade-off analysis across three case studies, but does not specify acceptance thresholds or an explicit post-deployment revision/ownership process in the provided excerpts.
Governance maturity: Absent
Measurement procedure: Monte Carlo simulation to enumerate evolution traces per configuration and environmental parameter setting; compute long-term fairness as average/max increase of fairness gaps over time; perform sensitivity analysis over configuration/environment parameters; trade-off analysis with utility metrics (profit; accuracy/F1; incident discovery/hotspot correctness).
Metrics used: Loan lending: demographic parity gap; mean credit score difference; long-term fairness metrics = average increase (Eq.1) and maximum increase (Eq.2) in fairness gap. Opioid risk: max increase in mean risk-score gap; avg increase in performance gap (accuracy, F1) over time. Predictive policing: average pairwise RPD of district over-policing scores; long-term fairness metrics = max/avg increase in allocation unfairness.
Monitoring present: Yes
Monitoring signals: Track fairness gap and long-term fairness (avg/max increase) across time steps/traces; also track utility metrics (bank profit; accuracy/F1; discovered incidents and hotspot correctness).
Monitoring snippet: FAIRSENSE helps ... plan for mitigations and monitoring to maintain fairness when the system is deployed in the real world.
Operationalization present: Yes
Protected attrs / groups: Loan lending: race (White vs Black). Opioid risk scoring: gender (male vs female). Predictive policing: districts (allocation fairness across districts).
QA notes: Updated using case-study excerpt: specifies protected groups (race, gender, districts), fairness metrics (DP gap, mean score gap, RPD), long-term fairness metrics (avg/max increase), and decision policies/threshold parameters (doctor threshold; hotspot allocation; group-specific credit thresholds). Acceptance criteria and explicit revision triggers/ownership not shown in excerpts.
QA pass: Pass
QA score: 7.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: N
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: Yes
SOC snippet: A long-term fairness issue arises as a result of a feedback loop between a system and its environment: Decisions made by an ML-enabled system induce certain changes or shifts in the environment, which, in turn, can influence the ensuing system behavior.
Spec explicitness/testability: Explicit + testable
Spec snippet: Given a fairness requirement, FAIRSENSE performs Monte-Carlo simulation to enumerate evolution traces for each system configuration.
Specification present: Yes
Study ID: P110
System Type: Classification
Threshold value: Loan lending: group-specific credit score thresholds (dynamic; values not in excerpt). Opioid risk scoring: doctor threshold in [0.3, 0.4, 0.45, 0.5, 0.55, 0.6, 0.7]. Predictive policing: allocate police to top 50 hotspot cells; discovery rates varied (0.8–1.0 hotspot, 0.2–0.5 other).
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: We demonstrate FAIRSENSE’s potential utility through three real-world case studies: Loan lending, opioids risk scoring, and predictive policing.
Validation/testing present: Yes
Venue Type: Conference
Year: 2025