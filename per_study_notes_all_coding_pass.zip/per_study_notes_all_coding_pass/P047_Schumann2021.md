# P047 — Schumann2021

Acceptance criteria stated: No
Citation: Schumann2021
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes MIAP: an updated annotation protocol producing exhaustive person bounding boxes on a 100k-image subset, plus attribute labels for perceived gender presentation and perceived age range, specifically to enable fairness analysis and study effects of partial annotations.
Data Type: Image
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Highlights that large CV datasets use partial, non-exhaustive annotations; warns that systematic missing person boxes can yield misleading fairness evaluation and biased detectors, especially when subgroup labels (man/woman/boy/girl) interact with the annotation pipeline and societal norms.
Elicitation artifact: Other
Elicitation method: Expert elicitation, Other
Elicitation present: Yes
Elicitation snippet: Annotation guidelines remind annotators that gender-expression norms vary across cultures/time and instruct them to avoid rigid stereotype-based rules; includes explicit instructions and examples to mitigate unconscious bias and to use “unknown” when uncertain.
End-to-end coverage: Partial
Failure modes: Missing context assumptions, Other, Unstable subgroup definitions
Fairness notions: Error parity, Other, Procedural fairness
Gap summary (1 sentence): Introduces MIAP, an exhaustive person-annotation subset of Open Images with perceived gender-presentation and age-range labels designed for fairness research, showing how partial annotation pipelines can encode societal norms and create systematic missing ground truth, but it does not provide deployment-time monitoring/revision governance and explicitly restricts use of these labels to fairness research rather than building gender/age classifiers.
Governance maturity: Absent
Measurement procedure: Analyze Open Images annotation pipeline (image-level labels proposed by classifiers + human verification → boxes for most specific positive labels) and show how person subclasses cause systematic omissions when collapsing to person. Create MIAP by relabeling 100k images (70k train, 30k val/test) with at least one person-subtree positive label: draw exhaustive person boxes; label each box with perceived gender presentation and perceived age range; compare original vs MIAP box counts per split/attribute; compute nPMI(Missing,label)−nPMI(Not Missing,label) to identify attributes correlated with missing boxes.
Metrics used: Dataset bias/fairness support metrics: counts of missing vs added person boxes; subgroup distribution comparisons; normalized pointwise mutual information (nPMI) to measure association between missing boxes and attribute labels; motivates downstream fairness evaluation via disaggregated metrics across gender-presentation and age-range slices (e.g., equality of opportunity) but does not itself define model-level acceptance thresholds.
Monitoring present: No
Notes: Set Thresholds stated = No and Acceptance criteria = No because the paper focuses on dataset annotation and bias analysis rather than specifying acceptance thresholds for model fairness.
Operationalization present: Yes
Protected attrs / groups: Perceived gender presentation (predominantly feminine, predominantly masculine, unknown) and perceived age range (young, middle, older, unknown) for each person box; explicitly distinguishes presentation from identity/actual age. Notes skin tone (e.g., Fitzpatrick type) as important but not covered.
QA notes: AIES’21 poster paper introducing MIAP (More Inclusive Annotations for People), a 100k-image relabeling of Open Images with exhaustive person boxes plus attributes for perceived gender presentation and perceived age range. Key fairness contribution is showing how the original person-subtree labeling and partial-annotation pipeline creates systematic missing boxes correlated with gendered/age-related labels and image context, which can distort both training and fairness evaluation. Provides statistical analysis (nPMI), count comparisons, and explicit intended-use/ethics caveats (do not build gender/age classifiers). Limitations include remaining imbalance (predominantly masculine), no skin tone attribute, and partial coverage of other taxonomy elements (relationships/triplets not re-annotated).
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Explicitly discusses how annotation procedures interact with societal norms and language (e.g., gender stereotypes, ‘girl’ vs ‘boy’) and cautions against harmful uses of gender/age labeling; recommends using labels for fairness evaluation only and not for deploying gender/age classifiers.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines a relabeling protocol: select images with any positive person-subtree label, draw boxes around all visible people, and assign attributes for perceived gender presentation (predominantly feminine/masculine/unknown) and perceived age range (young/middle/older/unknown); provides quantitative comparisons and statistics (e.g., nPMI) to analyze missing-box patterns.
Specification format: Constraint (formal/informal), Narrative goal, Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other
Study ID: P047
System Type: CV
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Validates the annotation changes via comparative analysis on 100k-image subset: reports added-box rate (~30% images with additional boxes), box-count deltas by attribute and split, and statistical association (nPMI) between missing boxes and attribute labels; provides examples/visualizations of new boxes.
Validation/testing present: Yes
Venue Type: Conference
Year: 2021