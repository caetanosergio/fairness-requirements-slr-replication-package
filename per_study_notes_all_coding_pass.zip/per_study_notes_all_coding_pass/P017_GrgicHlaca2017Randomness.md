# P017 — GrgicHlaca2017Randomness

Acceptance criteria stated: Partial
Citation: GrgicHlaca2017Randomness
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes random classifier ensembles: an ensemble Cens selects one classifier Ck at random per case according to p(j). Shows formal properties: ensembles preserve equality of treatment; preserve equality of impact for acceptance-rate and TPR/TNR definitions; may fail for predictive value definitions; and ensembles of unfair classifiers can still meet parity constraints and improve accuracy–fairness trade-offs.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: Policing
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames a socio-technical risk of replacing diverse human decision makers with a single scalable algorithm: loss of decision-process diversity. Motivates randomness/assignment analogies from courts (random judge panels) as an ENV-level fairness condition (equal chance of being judged by different ‘schools of thought’).
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, Other
Fairness notions: Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Shows that randomness via classifier ensembles can preserve or even improve standard parity-based fairness and accuracy–fairness trade-offs and motivates distributional (intra-group) fairness requirements, but provides no lifecycle monitoring or revision mechanisms to maintain these fairness properties under drift or changing contexts.
Governance maturity: Absent
Measurement procedure: Construct an ensemble of classifiers {Cj} with sampling distribution p(j); for a user x, sample a classifier then output its decision. Analyze fairness via expectations over the ensemble randomness; show when linearity of expectation preserves impact parity. Provide synthetic examples where unfair classifiers combined stochastically meet fairness constraints and improve accuracy–fairness trade-offs versus single constrained classifier. (Evaluation details beyond examples not fully specified in excerpt.)
Metrics used: Fairness metrics discussed: equality of treatment; equality of impact measured by acceptance rate into positive/negative class; TPR/TNR; predictive positive/negative value (PPV/NPV) with caveat. New distributional fairness (intra-group): whether beneficial outcome probabilities are evenly distributed within a sensitive group (e.g., all members have equal chance), not only equal group rates.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Assumes one binary sensitive attribute z ∈ {0,1} (e.g., gender or race). Examples use men vs women; mentions race in motivating domains (COMPAS).
QA notes: Highlights a RE-relevant requirement gap: algorithmization reduces decision-process diversity. Proposes random ensembles as a design mechanism with formal fairness properties across several parity metrics, and introduces distributional fairness (intra-group equal chance) as a new requirement notion enabled by randomness. Evidence is primarily analytical + illustrative synthetic examples; no deployment monitoring/revision/governance process described.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: p
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Discusses operational implications of randomness: reduced gaming (‘fence around the law’), smoother expected outcomes near boundaries, and motivates new “distributional fairness” notions capturing intra-group fairness (even distribution of beneficial-outcome chance within a group), beyond standard inter-group parity metrics. No governance/monitoring plan is specified.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines ensemble classifier Cens: select Ck from {Cj} with probability p(j), output Cens(x)=Ck(x). Equality of treatment: prediction independent of sensitive attribute. Equality of impact: equal beneficial-outcome rates across groups for acceptance-rate or TPR/TNR definitions; not guaranteed for PPV/NPV since conditioning sets vary across Cj. Introduces distributional fairness idea: within-group equality of chance at beneficial outcomes.
Specification format: Constraint (formal/informal)
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P017
System Type: Classification
Threshold value: No fixed numeric thresholds; fairness is expressed as parity equalities on expected rates (and distributional fairness as equal probabilities within group).
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Simulation
Validation snippet: Uses constructed synthetic decision scenarios to demonstrate three properties (fairness preservation, unfair-to-fair ensembles, and improved accuracy–fairness trade-offs) and motivates distributional fairness via illustrative examples.
Validation/testing present: Yes
Venue Type: Preprint
Year: 2017