# P070 — Rateike2024LongTermPolicies

Acceptance criteria stated: Yes
Citation: Rateike2024LongTermPolicies
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes a framework to design a time-independent decision policy that converges to a targeted fair stationary state, modeling dynamics as a time-homogeneous Markov chain and optimizing policies using Markov Chain Convergence Theorem (irreducibility + aperiodicity) constraints to ensure unique convergence.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: Lending
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates that in dynamical systems, decisions affect individuals and future data distributions; neglecting these feedback effects can increase inequalities and unfairness in the long term, and frequent policy updates can erode public trust due to temporal inconsistency.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides a formal, testable long-term fairness specification and policy optimization framework for dynamical decision systems with explicit ε-level constraints, but does not address deployment-time monitoring, drift handling, or governance/ownership for revising fairness targets and policies in practice.
Governance maturity: Absent
Measurement procedure: Model dynamics as time-homogeneous Markov chain with transition kernel induced by policy π (and environment mechanisms g, ℓ). Impose Markov Chain Convergence Theorem conditions (irreducible + aperiodic) on the policy-induced kernel to ensure unique stationary distribution, and optimize π to reach targeted fair equilibrium. Validate via semi-synthetic simulations initialized from real data (FICO, COMPAS), comparing long-term policy vs short-term policies; analyze robustness to covariate shift and distinguish short-term (distribution) vs long-term (transition kernel) interventions.
Metrics used: Uses long-term (stationary) group fairness targets/constraints such as equality of opportunity unfairness EOPUnf, demographic parity/sufficiency (mentioned), return parity / equal acceptance rate (related work). Evaluates utility U and EOPUnf over time; reports equilibrium utility/unfairness and cumulative measures in simulations.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Uses sensitive attribute S (e.g., gender or race) with group-conditional feature distributions μ_t(x|s). Example domains: lending (credit score X; S as race or gender; Y repayment), COMPAS recidivism (race), admissions (mentioned).
QA notes: FAccT’24 paper formalizes long-term group fairness in dynamical systems using time-homogeneous Markov chains and Markov Chain Convergence Theorem constraints to guarantee unique convergence to a stationary distribution targeted to satisfy fairness constraints (e.g., EOP at equilibrium with ε=0.01). Highlights delayed feedback and trust issues with frequent policy updates; distinguishes short-term interventions on state distribution from long-term interventions on transition kernel; validates with semi-synthetic simulations on FICO and COMPAS. No concrete deployment monitoring/revision governance specified.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Discusses societal/policy interventions (e.g., subsidies) as mechanisms to improve short-term fairness during convergence without changing the long-term equilibrium; frames interventions and trust/consistency as sociotechnical concerns but does not specify real-world governance roles or operational monitoring.
Spec explicitness/testability: Explicit + testable
Spec snippet: Formalizes long-term fair policy objective as finding a policy π such that a targeted fair distribution is a stationary distribution (μ_s = μ_s P_s^π) and policy-induced Markov chains satisfy convergence criteria; defines optimization min_π J_LT(μ,π) s.t. C_LT(μ,π)≥0 and C_conv(P_s^π)≥0.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Study ID: P070
System Type: Decision support
Threshold value: Example: tolerated unfairness ε = 0.01 (EOP constraint at equilibrium).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Simulation
Validation snippet: Semi-synthetic simulations based on real-world datasets (FICO loan repayment; COMPAS recidivism) show convergence to targeted ε-fair equilibrium, temporal stability vs short-term updated policies, robustness to covariate shift, and effects of short-term vs long-term interventions.
Validation/testing present: Yes
Venue Type: Conference
Year: 2024