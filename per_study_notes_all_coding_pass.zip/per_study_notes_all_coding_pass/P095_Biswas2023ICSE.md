# P095 — Biswas2023ICSE

Acceptance criteria stated: Partial
Citation: Biswas, Sumon, and Hridesh Rajan. "Fairify: Fairness Verification of Neural Networks." In 2023 IEEE/ACM 45th International Conference on Software Engineering (ICSE), 1546–1558. 2023. https://doi.org/10.1109/ICSE48619.2023.00134
DES content: Yes
DES snippet: Proposes Fairify, an SMT-based method to verify individual fairness in ReLU neural networks using input partitioning plus (sound + heuristic) pruning of inactive neurons, returning UNSAT (certification) or SAT with counterexample, and supporting relaxed and targeted verification queries.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV snippet: Motivates need for formal guarantees of algorithmic fairness in critical decision-making domains (criminal sentencing, hiring, loans) and positions Fairify as a developer-oriented verification method for already-trained neural networks deployed/used in production settings.
Elicitation artifact: Other
Elicitation method: Surveys
Elicitation present: Yes
Elicitation snippet: Uses practitioner needs from Holstein et al. (CHI 2019) to motivate targeted verification + counterexamples for internal buy-in and debugging (“give me a hundred examples…”).
End-to-end coverage: Partial
Failure modes: Governance absent, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides an explicit, testable specification and SMT-based certification/counterexample workflow for individual fairness (including relaxations and targeted queries) on already-trained ReLU neural networks, but does not define real-world acceptance criteria beyond time budgets nor provide monitoring/revision governance for maintaining fairness post-deployment.
Governance maturity: Absent
Measurement procedure: Encodes fairness as SMT constraints using two copies of the NN; computes weakest precondition of output activation to simplify postcondition; uses input partitioning; prunes provably inactive ReLU neurons via interval bound propagation + per-neuron SMT checks, and optionally prunes additional near-inactive neurons via profiling heuristics; solves split-queries with Z3 to return SAT with counterexample or UNSAT certification, otherwise UNK under timeout; aggregates per-partition results.
Metrics used: Fairness property is individual fairness (and ε-relaxed individual fairness, targeted fairness) expressed as satisfiability constraints over two copies of a neural network; outputs compared for classification disagreement; also reports partitions SAT/UNSAT/UNK and pruning/compression ratios.
Monitoring present: No
Notes: Core contribution is verification (certification/counterexample) for individual fairness on already-trained ReLU NNs using SMT + pruning. Strong for operationalization/specification; weaker for lifecycle governance (monitoring/revision in production).
Operationalization present: Yes
Protected attrs / groups: Protected attributes P include race, sex, age (varies by dataset). Individual fairness compares inputs differing only in protected attributes; evaluated on fairness-critical datasets (Adult Census, German Credit, Bank Marketing).
QA notes: Strong technical paper: formalizes individual fairness (and ε-/targeted variants) as SMT constraints over two NN copies; details algorithm (partitioning + sound/heuristic pruning) and reports evaluation on 25 real-world NNs with timeouts, SAT/UNSAT/UNK outcomes, and pruning ratios. Limitations include restricted NN types (ReLU fully connected), structured/tabular datasets, and lack of production monitoring/revision governance; ethics discussion is mainly via threats-to-validity rather than deeper socio-legal analysis.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Frames fairness verification as necessary for socially sensitive decisions; uses protected attributes (race, sex, age) and individual fairness (“similar individuals should receive similar treatment”) as the normative fairness criterion; emphasizes practical developer needs for diagnosis via counterexamples and targeted verification.
Spec explicitness/testability: Explicit + testable
Spec snippet: Definition 1 (Individual Fairness): no pair (x, x′) such that non-protected attributes are equal, protected attribute differs, and model outputs differ; plus relaxations (ε-fairness) and targeted fairness (additional linear constraints on input).
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P095
System Type: Classification
Threshold value: Timeout budgets (soft-timeout per split-query; hard-timeout overall). Relaxation parameter ε for ε-fairness; maximum partition size (MS) for partitioning; heuristic pruning tolerance (e.g., 5%).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Formal verification, Offline evaluation
Validation snippet: Evaluated on 25 real-world neural networks from 4 sources; shows baseline SMT cannot verify within days while Fairify verifies most queries within an hour and provides SAT/UNSAT/UNK plus counterexamples; reports pruning/compression ratios and coverage per partition.
Validation/testing present: Yes
Venue Type: Conference
Year: 2023