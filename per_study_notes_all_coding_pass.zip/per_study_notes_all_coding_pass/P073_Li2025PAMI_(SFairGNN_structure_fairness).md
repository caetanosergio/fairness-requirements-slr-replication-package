# P073 — Li2025PAMI (SFairGNN / structure fairness)

Acceptance criteria stated: No
Citation: Li2025PAMI
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines “structure fairness” for GNNs and proposes SFairGNN to mitigate structure unfairness amplified by message passing. SFairGNN combines (i) neighborhood expansion (structure debiasing) for marginal nodes and (ii) hop-aware attentive information aggregation with hop fusion (SEQ/AVG/MAX) to improve structure fairness while maintaining downstream accuracy.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivation frames sociotechnical harm: nodes at the periphery (“marginal nodes”) in social networks can be treated unfairly compared to central nodes; argues fairness issues in graphs should include structure-induced unfairness beyond protected-attribute fairness (e.g., age/gender).
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Provides a measurable definition of structure fairness for GNNs (via PCC/STD over centrality) and an effective mitigation (SFairGNN) with extensive offline evaluation, but lacks explicit acceptance thresholds and does not address deployment-time monitoring or requirements revision/governance as graph structure and populations change.
Governance maturity: Absent
Measurement procedure: Bin/cluster nodes by centrality (closeness/eigenvector) and compute per-bin accuracy; compute PCC between centrality and accuracy and STD across bins as fairness indicators. Mitigation: neighborhood expansion strengthens connections for marginal nodes via a debiased adjacency matrix (strengthen edges involving marginal nodes), generating multi-hop neighbor sets up to hop h; hop-aware attentive aggregation learns attention weights per hop and fuses hop-wise embeddings (SEQ/AVG/MAX). Evaluated on node classification datasets (Cora, CiteSeer, PubMed, CoraFull, Photo, Physics) against GCN/GAT/GraphSAGE.
Metrics used: Structure fairness metrics: PCC (Pearson correlation coefficient between centrality and accuracy) and STD (standard deviation of accuracy across centrality bins). Also reports overall node classification accuracy (ACC).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Not sensitive-attribute-based; groups are defined by structural position. Marginal vs central nodes identified using centrality metrics (closeness centrality, eigenvector centrality) and a threshold (“margin line”) where nodes with s_i ≤ line are treated as marginal.
QA notes: Coded from provided excerpt (abstract, method, and experimental summary). Focus is “structure fairness” (marginal nodes by centrality) rather than protected attributes; defines PCC/STD fairness metrics; proposes SFairGNN (neighborhood expansion + hop-aware attention + hop fusion) and evaluates on multiple graph benchmarks. Stakeholder elicitation and deployment governance/monitoring are not described; acceptance thresholds are not specified.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Uses social-network/job-market examples (Twitter attention; LinkedIn/job market marginalization) to explain why peripheral nodes should not be depreciated; notes the “margin line” threshold has sociological meaning and should be set seriously, but does not describe organizational governance, deployment monitoring, or revision responsibilities.
Spec explicitness/testability: Explicit + testable
Spec snippet: Specifies structure fairness as reducing dependence between a node’s structural position (centrality) and downstream task performance. Measures fairness using PCC (Pearson correlation between centrality and accuracy) and STD (std dev of accuracy across centrality bins), aiming for PCC close to 0 and lower STD while keeping overall ACC comparable.
Specification format: Constraint (formal/informal), Narrative goal
Specification present: Yes
Stakeholders Mentioned: Affected groups
Study ID: P073
System Type: Classification
Threshold value: Uses a heuristic “margin line” threshold on centrality to label marginal nodes; explores line values (e.g., 0.1–0.9) and hop number h (e.g., 1–5) in sensitivity analysis. No explicit acceptance threshold stated for PCC/STD beyond “close to 0 / lower is better.”
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Reports experiments on multiple real-world graph benchmarks showing SFairGNN improves structure fairness metrics (lower STD; PCC nearer 0) versus baseline GNNs while maintaining overall accuracy; includes ablations on fusion method and sensitivity analyses for hop number and margin line.
Validation/testing present: Yes
Venue Type: Journal
Year: 2025