# P106 — Borkan2019WWW

Acceptance criteria stated: No
Citation: Borkan, Daniel, Lucas Dixon, Jeffrey Sorensen, Nithum Thain, and Lucy Vasserman. “Nuanced Metrics for Measuring Unintended Bias with Real Data for Text Classification.” In Companion Proceedings of the 2019 World Wide Web Conference (WWW ’19 Companion), May 13–17, 2019, San Francisco, CA, USA. ACM, 10 pages. https://doi.org/10.1145/3308560.3317593
DES content: Yes
DES explicit requirement: Yes
Data Type: Text
Decision rule tied to metric: Yes
Deployment Status: Deployed
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Introduces a robust, threshold-agnostic metric suite and a large identity-labeled real-comment test set for diagnosing unintended identity bias in toxicity classifiers via score-distribution analysis, but leaves acceptance thresholds and deployment-time monitoring/revision processes unspecified.
Governance maturity: Absent
Measurement procedure: Define unintended bias as performance variation across designated identity groups under an equality-of-odds style framing (with assumption of reliable labels). Propose 5 threshold-agnostic metrics capturing different score-distribution shifts and mis-orderings across subgroup/background. Evaluate metrics on (1) a synthetic template-based test set and (2) a new large human-labeled dataset of 1.8M online comments (450k with identity-reference labels). Demonstrate metrics by comparing two public toxicity models (Perspective API TOXICITY@1 vs TOXICITY@6) and analyzing where mitigation improves or fails (especially short vs long comments).
Metrics used: Threshold-agnostic unintended-bias evaluation suite: Subgroup AUC; BPSN AUC (Background Positive, Subgroup Negative); BNSP AUC (Background Negative, Subgroup Positive); Positive AEG and Negative AEG (Average Equality Gaps) based on TPR/TNR across all thresholds and equivalent Mann–Whitney U formulations.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Identity groups referenced in text (crowd-labeled): gender (male, female, transgender, other), sexual orientation, religion, race/ethnicity, disability (plus ‘other’ categories).
QA notes: Metric + evaluation dataset paper (for unintended bias in text classifiers). Strong: clear motivation (identity-linked score skew), formal metric definitions (AUC variants + AEGs) and properties, robustness to class imbalance, and validation on synthetic and large human-labeled datasets with analysis of mitigation differences across comment length. Partial: relies on assumption of reliable labels and a curated identity list; no explicit decision threshold/acceptance criterion for ‘acceptable’ bias; no post-deployment monitoring or revision governance beyond future-work suggestions.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
Spec explicitness/testability: Explicit + testable
Spec snippet: “We introduce a suite of threshold-agnostic metrics that provide a nuanced view of this unintended bias … considering the various ways that a classifier’s score distribution can vary across designated groups.”
Specification format: Constraint (formal/informal), NFR statement
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Users
Study ID: P106
System Type: NLP
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Applies the metric suite to synthetic and large human-labeled real-comment datasets and compares two deployed toxicity models (TOXICITY@1 vs TOXICITY@6), showing bias skewed toward toxicity for identity-related content and partial mitigation improvements.
Validation/testing present: Yes
Venue Type: Conference
Year: 2019