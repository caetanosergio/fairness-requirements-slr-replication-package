# P072 — Han2024SFairGNN

Acceptance criteria stated: No
Citation: Han2024SFairGNN
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines and targets “structure fairness” for GNNs: marginal nodes (identified via centrality) exhibit worse downstream task performance; proposes SFairGNN with (i) neighborhood expansion (structure debiasing) to add neighbors for marginal nodes and (ii) hop-aware attentive aggregation to fuse multi-hop information, improving fairness while maintaining accuracy.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames a sociotechnical concern that individuals at the periphery of social graphs (marginal nodes) can be unfairly depreciated by graph learning systems, which may particularly affect underprivileged communities; argues graph-structure-induced unfairness should be addressed beyond protected-attribute fairness.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Introduces measurable “structure fairness” for GNNs and a mitigation (SFairGNN) with strong offline evaluation, but lacks explicit acceptance thresholds and does not address deployment-time monitoring or revision governance as graph structures and populations evolve.
Governance maturity: Absent
Measurement procedure: Cluster/bin nodes by centrality (closeness/eigenvector) and compare per-bin average accuracy; compute PCC between centrality and accuracy and STD across bins as fairness indicators. SFairGNN mitigates structure unfairness by expanding neighborhoods for marginal nodes using a debiased adjacency matrix (only strengthen edges for marginal nodes) and multi-hop neighbor sets (up to hop h), then applies hop-aware attention aggregation and hop fusion (SEQ/AVG/MAX) to compute embeddings. Evaluated on node classification across multiple benchmark graphs (Cora, CiteSeer, PubMed, CoraFull, Photo, Physics) comparing against GCN/GAT/GraphSAGE.
Metrics used: Structure-fairness metrics: PCC (Pearson correlation coefficient between centrality and accuracy) and STD (standard deviation of accuracy across bins of centrality). Also reports overall node classification accuracy (ACC).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Not based on sensitive attributes; groups defined by structural position. Identifies marginal vs central nodes using centrality measures (closeness centrality, eigenvector centrality) and a threshold (“margin line”) to label nodes as marginal (s_i ≤ line) vs central.
QA notes: SIGKDD Explorations (Vol 25, Issue 2, 2024) article proposes “structure fairness” in graphs: marginal nodes (by centrality) are disadvantaged in GNN downstream accuracy; defines fairness metrics PCC and STD relating centrality to accuracy; proposes SFairGNN (neighborhood expansion + hop-aware attentive aggregation) and evaluates on multiple benchmark graphs with ablations. Motivates via social-network/job-market scenarios and notes sociological meaning of centrality thresholding, but provides no deployment monitoring/revision governance.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Motivating examples (Twitter attention, LinkedIn/job market) connect structural marginalization to fairness harms; notes margin line hyperparameter has sociological meaning and should be set carefully, but does not specify stakeholder governance, monitoring, or revision procedures.
Spec explicitness/testability: Explicit + testable
Spec snippet: Operationalizes “structure fairness” as reducing dependence of node classification performance on node structural position (centrality). Uses quantitative fairness metrics PCC (Pearson correlation between centrality and accuracy) and STD (std dev of accuracy across centrality bins); aims for PCC close to 0 and lower STD, while maintaining overall ACC.
Specification format: Constraint (formal/informal), Narrative goal
Specification present: Yes
Study ID: P072
System Type: Classification
Threshold value: Uses a heuristic threshold “margin line” (line) on centrality to define marginal nodes; values explored in sensitivity analysis (e.g., 0.1–0.9). No acceptance threshold specified for PCC/STD beyond “close to 0 / lower is better.”
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Experiments on six real-world benchmark graph datasets show SFairGNN improves structure fairness metrics (lower STD and PCC nearer 0) relative to baseline GNNs while keeping overall accuracy comparable; includes ablations for fusion methods and sensitivity analyses for hop number and margin line.
Validation/testing present: Yes
Venue Type: Journal
Year: 2024