# P039 — Polyzotis2019

Acceptance criteria stated: Partial
Citation: Polyzotis2019
DES content: Yes
DES explicit requirement: Yes
DES snippet: Describes a deployed data validation system (part of TFX/TF Data Validation) with three components: Data Analyzer (summary statistics), Data Validator (schema-based anomaly detection + suggested schema updates), and Model Unit Tester (schema-guided synthetic data / fuzz testing to catch training-code assumptions). Supports single-batch validation, inter-batch validation (drift + training-serving skew), and model unit testing workflows.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Deployed
Domain: General
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Assumes production ML pipelines where training and serving data evolve continuously and can contain structured, code-induced errors (schema-free data, training-serving skew, drift) that ML models may “soldier on” through; emphasizes feedback loops where serving logs become training data, amplifying small data bugs.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Monitoring without triggers, No thresholds / acceptance criteria, Other
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Presents a production-deployed, schema-driven data validation and model unit-testing framework (TFDV/TFX) that operationalizes continuous monitoring for anomalies, drift, and training-serving skew with actionable alerts and schema co-evolution, but it does not explicitly connect data validation to fairness/protected-group harms or define governance beyond schema ownership/versioning.
Governance maturity: Mature
Measurement procedure: Compute per-batch summary statistics (Data Analyzer). Validate each batch vs schema constraints (Data Validator) to flag anomalies and suggest schema updates as data evolves. For inter-batch checks, compare training vs serving and successive batches: feature-level joins for feature skew, distribution distance for distribution skew, including estimation with Dirichlet priors. Use schema to generate synthetic data for fuzz-style unit tests of training code to reveal mismatches between code assumptions and schema/data. Report production deployment evidence and case studies.
Metrics used: Operational metrics: anomaly categories and alerting; distribution distance metrics (d∞ and also L1/d1 discussed) for drift/skew; empirical validation from deployment (e.g., schema edit counts across pipelines; anomaly firing/fix rates; unit-test execution counts and failure rate; A/B win from removing skew).
Monitoring present: Yes
Monitoring signals: Schema violations (missing/new features, type/domain violations, value-count issues), training-serving skew (feature/value mismatches), distribution drift/skew (d∞/d1 distances), and model unit-test failures indicating training-code assumptions not reflected in schema.
Monitoring snippet: System continuously validates each incoming training/serving batch against schema, monitors training-serving skew and distribution drift, and generates anomaly alerts plus suggested schema edits; emphasizes catching errors early before they propagate through feedback loops.
Operationalization present: Yes
QA notes: SysML 2019 paper describing TensorFlow Data Validation within TFX. Strong operational RE relevance: explicit schema constraints, monitoring signals, drift/skew metrics, and an iterative human-in-the-loop workflow (schema inference + suggested edits + versioning) plus schema-guided fuzz/unit tests for training code. Empirical support comes from production deployment stats and case studies rather than controlled experiments. Fairness is not a primary focus, but the work is directly about monitoring/validation and preventing silent failures in ML pipelines.
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Yes
Revision present: Yes
Revision snippet: Schema is inferred initially then manually curated and evolves with data via user-reviewed suggested edits; stored in version control and treated as a production asset, with iterative updates when anomalies reflect natural data evolution (otherwise code fixes are required).
Revision trigger defined: Yes
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames data validation as necessary for reliability and safety of ML systems, reducing outages and engineering burden; focuses on operational accountability via high-precision, actionable alerts to on-call engineers (spammy/non-actionable alerts are ignored), but does not directly address protected groups or discrimination.
Spec explicitness/testability: Explicit + testable
Spec snippet: Codifies expected data properties via an ML-oriented schema (types, domains, presence, value counts, lifecycle stage, drift/skew comparators) and validates each batch against it, producing interpretable anomaly categories and suggested schema edits. For distribution drift/skew, argues standard statistical tests (e.g., chi-square) are too sensitive at scale and uses interpretable distribution-distance metrics like d∞(p,q)=max_i|p_i−q_i| with thresholds, with statistical estimation via Dirichlet priors. Adds schema-guided model unit tests by generating synthetic examples conforming to schema to expose hidden assumptions in training code (e.g., log of negative values).
Specification format: Constraint (formal/informal), Other, Policy/rule
Specification present: Yes
Stakeholders Mentioned: Developers, Org leadership, Other
Study ID: P039
System Type: Multi-task/Other
Threshold value: User-tuned thresholds for distribution distance (e.g., “allow changes up to 1% per value” for d∞). Confidence level example alpha=0.01 for chi-square is discussed as problematic at scale; drift/skew comparators are encoded in schema constraints.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation, Other
Validation snippet: Validation includes (a) production deployment evidence at Google/TFX scale (petabytes/day; hundreds of teams), with aggregate statistics on schema co-evolution, anomaly frequencies, and unit-test failures, and (b) case studies including a 2% install-rate lift after fixing training-serving feature skew in a recommender pipeline and faster debugging/migration wins.
Validation/testing present: Yes
Venue Type: Conference
Year: 2019