# P069 — Luo2024FairCLIP

Acceptance criteria stated: No
Citation: Luo2024FairCLIP
DES content: Yes
DES explicit requirement: Yes
DES snippet: Introduces Harvard-FairVLMed (fundus image + clinical note; rich demographics; ground-truth labels) to study fairness of medical vision-language models; evaluates CLIP/BLIP2 and proposes FairCLIP (optimal transport / Sinkhorn distance regularizer) to align overall vs subgroup feature-similarity distributions, achieving a performance–fairness trade-off.
Data Type: Multi-modal
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Healthcare
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames fairness in healthcare as ethical/legal requirement tied to patient safety and equity; motivates that biases by race, gender, ethnicity, language can lead to adverse outcomes and disparities (glaucoma underdiagnosis higher in Black communities).
Elicitation artifact: Other
Elicitation method: Expert elicitation, Other
Elicitation present: Yes
Elicitation snippet: Clinical notes are de-identified with Presidio + rules, then verified by four medical experts; fairness study is enabled by collecting/curating demographic attributes (age, gender, race, ethnicity, preferred language, marital status) and defining glaucoma labels using VF-test criteria.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides a fairness-oriented multimodal clinical dataset and an OT-based in-training mitigation (FairCLIP) with clear group metrics, but does not specify deployment-time acceptance thresholds, monitoring signals, or revision governance for sustaining fairness in clinical use.
Governance maturity: Absent
Measurement procedure: Builds Harvard-FairVLMed: 10k patients with SLO fundus images + de-identified clinical notes (2015–2022). Labels glaucoma vs non-glaucoma via VF test criteria (e.g., mean deviation thresholds and VF hemifield/PSD). De-identifies notes via Presidio + rules + expert verification; summarizes notes with LLMs (GPT-4, PMC-LLAMA, Med42) to fit text encoder constraints. Evaluates fairness of CLIP/BLIP2 via linear probing and zero-shot transfer; FairCLIP adds Sinkhorn-distance loss between overall and subgroup distributions of CLIP similarity matrix diagonal Mi,i during pretraining/fine-tuning.
Metrics used: Fairness metrics: Demographic Parity Difference (DPD), Difference in Equalized Odds (DEOdds), Equity-Scaled AUC (ES-AUC), Group-wise AUC; also reports overall AUC. Uses subgroup comparisons across race (Asian/Black/White), gender (Female/Male), ethnicity (Non-Hispanic/Hispanic), preferred language (English/Spanish/Others).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Protected/identity attributes: age, gender, race, ethnicity, preferred language, marital status. Reported subgroup results for race (Asian, Black, White), gender (Female, Male), ethnicity (Non-Hispanic, Hispanic), language (English, Spanish, Others/Unknown).
QA notes: CVPR’24 paper contributes (1) Harvard-FairVLMed dataset (fundus + clinical notes with detailed demographics and ground-truth glaucoma labels) for fairness analysis in medical vision-language models, and (2) FairCLIP, an optimal-transport/Sinkhorn regularizer to align overall vs subgroup distributions for improved fairness–performance trade-off. Strong operationalization with DPD/DEOdds/ES-AUC/group-wise AUC and extensive ablations; includes IRB + de-identification/expert verification, but no deployment monitoring/revision/acceptance criteria.
QA pass: Pass
QA score: 9
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: N
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Includes clinical governance/compliance elements for dataset creation (IRB approval, de-identification pipeline, expert verification of de-identification) but does not define operational deployment governance, monitoring, or revision processes for fairness in clinical use.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines group fairness objectives as reducing disparities across identity groups using measurable metrics (DPD, DEOdds, ES-AUC, group-wise AUC). FairCLIP objective minimizes distance between overall distribution of image-text similarity scores and group-conditional distributions using Sinkhorn distance.
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P069
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Experiments on Harvard-FairVLMed evaluate CLIP/BLIP2 (natural vs medical pretraining) across protected attributes using AUC and fairness metrics (DPD, DEOdds, ES-AUC, group-wise AUC); compares CLIP vs FairCLIP and runs ablations (note summarization, multimodal vs vision-only features, medical vs natural vision encoder, adversarial fairness baseline).
Validation/testing present: Yes
Venue Type: Conference
Year: 2024