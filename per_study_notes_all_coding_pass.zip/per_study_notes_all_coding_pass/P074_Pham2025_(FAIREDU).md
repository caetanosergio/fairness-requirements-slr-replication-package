# P074 — Pham2025 (FAIREDU)

Acceptance criteria stated: No
Citation: Pham2025FAIREDU
DES content: Yes
DES explicit requirement: Partial
DES snippet: Proposes FAIREDU, a multiple regression-based “debug data” method to reduce fairness disparities across multiple sensitive features (intersectional assessment) while minimizing impact on predictive performance; reports large reductions in Disparate Impact and Statistical Parity Difference on public/private datasets.
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Frames fairness harms in education as long-term and life-shaping: biases in assessments/admissions/personalized learning can reinforce inequities for marginalized groups (e.g., gender, race, socioeconomic status), affecting trajectories and mobility.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria
Fairness notions: Outcome parity
Gap summary (1 sentence): Provides an offline fairness-mitigation method (FAIREDU) for educational ML that improves group disparity metrics across multiple sensitive features while preserving performance, but does not specify explicit acceptance thresholds or any deployment-time monitoring and revision governance.
Governance maturity: Absent
Measurement procedure: Runs experiments on six public datasets and one private dataset; evaluates fairness improvements using DI and SPD (reports up to 96.7% reduction in DI for Gender on Oulad and up to 88.55% reduction in SPD for Gender on Adult) while tracking predictive performance; compares against state-of-the-art methods.
Metrics used: Disparate Impact (DI); Statistical Parity Difference (SPD). (Mentions reducing fairness disparities while maintaining predictive performance.)
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive features include gender and race; introduction also mentions socioeconomic status (education context). Method aims to address fairness across multiple sensitive features (intersectional), but specific protected-group definitions per dataset are not fully detailed in this excerpt.
QA notes: Coded from provided abstract + intro excerpt only. Paper targets education applications and emphasizes intersectional fairness across multiple sensitive features; reports DI/SPD improvements and maintaining performance via offline experiments. No stakeholder elicitation, explicit thresholds, or monitoring/revision processes in excerpt.
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: p
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: No
SOC explicit requirement: No
Spec explicitness/testability: Explicit not testable
Spec snippet: Goal stated as improving fairness across multiple sensitive features while maintaining model performance; fairness evaluated via disparity metrics (e.g., DI, SPD) but no explicit acceptance thresholds/requirements statement is provided in the excerpt.
Specification format: Narrative goal
Specification present: Yes
Stakeholders Mentioned: Affected groups
Study ID: P074
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Experimental evaluation on multiple datasets (six public + one private) shows FAIREDU reduces DI/SPD disparities substantially while maintaining high predictive performance; reports comparison vs state-of-the-art methods.
Validation/testing present: Yes
Venue Type: Journal
Year: 2025