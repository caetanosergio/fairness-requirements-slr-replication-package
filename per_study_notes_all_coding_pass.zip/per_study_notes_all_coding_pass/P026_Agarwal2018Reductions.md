# P026 — Agarwal2018Reductions

Acceptance criteria stated: Partial
Citation: Agarwal2018Reductions
DES content: No
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: General
ENV content: No
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Missing context assumptions, No revision process/ownership, Other
Fairness notions: Error parity, Other, Outcome parity
Gap summary (1 sentence): Provides a general, testable operationalization of fairness requirements (DP/EO and other conditional-moment constraints) with explicit tolerance ε and strong algorithmic/finite-sample guarantees, but remains design-time and does not address stakeholder elicitation, deployment monitoring, or requirements revision over time.
Governance maturity: Absent
Measurement procedure: Reduces fair classification (empirical constrained optimization) to repeated cost-sensitive classification via Lagrangian saddle-point game between Q-player and λ-player; solves with exponentiated gradient algorithm. Uses black-box cost-sensitive learner (e.g., weighted logistic regression, gradient-boosted trees). Finite-sample/statistical guarantees via Rademacher complexity; explores accuracy–fairness trade-offs via varying ε and (optionally) grid search for small constraint sets.
Metrics used: DP and EO constraints expressed as conditional moment (expectation) equalities/inequalities; constraint violation measured as max_a |E[h(X)|A=a] − E[h(X)]| for DP and max_{a,y} |E[h(X)|A=a,Y=y] − E[h(X)|Y=y]| for EO. Uses cost-sensitive classification reduction and returns randomized classifier Q over H minimizing empirical error under constraints.
Monitoring present: No
Notes: Core contribution is an algorithmic RE-style operationalization: fairness requirements as explicit linear constraints with tolerance ε, solved via reductions to cost-sensitive classification; provides finite-sample guarantees and does not require protected attribute at test time (though experiments include A in X for fair comparison). No monitoring/revision lifecycle process.
Operationalization present: Yes
Protected attrs / groups: Protected attribute A (pre-defined; examples include race, sex; also discusses proxy features like zipcode correlated with race). Experiments: Adult (gender; also gender+race as combined attribute), COMPAS (race: Black vs White), LSAC bar passage (race: Black vs White), Dutch census (gender).
QA notes: Uses constrained optimization (error minimization under DP/EO constraints) and reductions to cost-sensitive learning (exp-gradient saddle point) to produce randomized classifier with minimal empirical error; evaluates across multiple datasets and reports trade-off curves. Does not cover socio-technical governance or post-deployment lifecycle practices beyond offline evaluation.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines Demographic Parity (DP): h(X) ⟂ A, i.e., P[h(X)=ŷ|A=a]=P[h(X)=ŷ] (equiv. E[h(X)|A=a]=E[h(X)]). Defines Equalized Odds (EO): h(X) ⟂ A | Y, i.e., P[h(X)=ŷ|A=a,Y=y]=P[h(X)=ŷ|Y=y] (equiv. E[h(X)|A=a,Y=y]=E[h(X)|Y=y]). Expresses fairness as linear inequalities on conditional moments Mμ(h) ≤ c.
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P026
System Type: Classification
Threshold value: Constraint slack ε used as tolerance: ε ∈ {0.001, …, 0.1}; sets ĉ_k = ε for all constraints to allow small violations. Mentions four-fifths rule (4/5) as motivation for DP.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates reductions vs baselines (post-processing, reweighting, relabeling, unconstrained) on Adult, COMPAS, LSAC bar passage, and Dutch census; plots test error vs fairness-constraint violation with confidence intervals.
Validation/testing present: Yes
Venue Type: Conference
Year: 2018