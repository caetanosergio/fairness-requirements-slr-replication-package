# P044 — Creager2020

Acceptance criteria stated: Partial
Citation: Creager2020
DES content: Yes
DES explicit requirement: Yes
DES snippet: Uses causal DAGs/structural causal models with policy interventions do(f→π) to unify dynamical fairness literature; enables simulation when dynamics known and off-policy estimation when dynamics unknown; provides empirical off-policy estimation improvements in lending.
Data Type: Other
Decision rule tied to metric: Yes
Deployment Status: Conceptual
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates fairness in domains with long-term effects (lending, education, recommenders) and emphasizes that repeated deployment in changing environments yields long-term fairness implications distinct from short-term ones.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, Missing context assumptions, Monitoring without triggers, No revision process/ownership, Other
Fairness notions: Contextual/legal compliance, Error parity, Individual consistency, Other, Procedural fairness
Gap summary (1 sentence): Provides a causal-SCM framework to specify and evaluate fairness interventions in dynamical systems (including off-policy estimation from observational data and simulation/sensitivity when dynamics are known), but does not define deployment-time monitoring/revision governance for keeping fairness requirements valid in production systems.
Governance maturity: Absent
Measurement procedure: Defines SCMs for sequential settings (Fair-MDP, lending, repeated classification) and uses do-operator for atomic/policy interventions. Shows off-policy evaluation from observational trajectories by identifying backdoor sets and applying doubly robust estimators; validates via lending experiment (historical MAXPROF data → evaluate/learn EQOPP-type policy). Also demonstrates on-policy simulation when dynamics known, including multi-actor interventions (credit bureau) and long-term sensitivity analysis of policies under model mismatch.
Metrics used: Interventional/policy-evaluation quantities (e.g., E_{do(f_T→π)}[U] utility, E_{do(f_T→π)}[Δ_j] group score change); equal opportunity gap δEqOpp = |P(T=1|Y=1,A=0) − P(T=1|Y=1,A=1)|; demographic parity and max-profit/EO threshold policies in lending example; repeated classification/disparity amplification model; long-term outcomes XK in Fair-MDP; off-policy estimator error comparisons (regression vs doubly robust).
Monitoring present: No
Notes: Trade-offs managed set to Yes (explicit fairness–utility trade-off via λ; discusses estimation bias/variance trade-offs; evaluates welfare/fairness under different interventions).
Operationalization present: Yes
Protected attrs / groups: Uses sensitive attribute A explicitly (e.g., two groups in lending with group-specific thresholds); repeated classification uses latent groups Z with changing proportions α_k; discusses group and individual outcomes under interventions.
QA notes: ICML’20 paper proposing causal DAGs/SCMs as a unifying framework for fairness in dynamical systems. Key contribution is making policy interventions explicit and leveraging causal identification (backdoor) to improve off-policy evaluation (doubly robust estimators) from historical data, plus using SCM modularity for simulation, multi-actor interventions (credit bureau), multi-step extensions, and sensitivity analysis. Strong operationalization of causal estimands; lacks concrete post-deployment governance/monitoring process for real systems.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Highlights usefulness of causal graphs for communicating assumptions to non-technical stakeholders/policy makers and for scrutinizing assumptions in fairness-sensitive settings; discusses regulators and ethical constraints that make online testing of policies difficult.
Spec explicitness/testability: Explicit not testable
Spec snippet: Frames fairness evaluation/learning in dynamical systems as estimating interventional quantities under policy interventions (e.g., E_{p^{do(f_T→π)}}[U], E_{p^{do(f_T→π)}}[Δ_j], δEqOpp) using SCMs; focuses on causal estimands rather than requirements statements for deployment.
Specification format: Constraint (formal/informal), Narrative goal
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P044
System Type: Decision support
Threshold value: Group-specific thresholds τ_j for lending policies; fairness–utility trade-off hyperparameter λ in V_π = U − λ·δEqOpp; credit-bureau intervention example uses τ_CB = 600; multi-step horizon K/steps varied in simulations.
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation, Simulation
Validation snippet: Empirically compares off-policy estimators (regression vs doubly robust) in a lending SCM, showing improved estimation error and improved learned policy objective V_π; also runs on-policy simulations for extensions (credit bureau intervention, multi-step robustness/sensitivity).
Validation/testing present: Yes
Venue Type: Conference
Year: 2020