# P091 — MetcalfMoss2019

Acceptance criteria stated: No
Citation: MetcalfMoss2019
DES content: Yes
Data Type: Other
Decision rule tied to metric: No
Deployment Status: Conceptual
Domain: General
ENV content: Yes
Elicitation artifact: Other
Elicitation method: Interviews, Other
Elicitation present: Yes
Elicitation snippet: Interviews with 17 people who either “own ethics” in their formal role or have made addressing ethics within their companies/industry a personal mission, supplemented with ethnographic and textual qualitative data.
End-to-end coverage: Partial
Failure modes: Governance absent, No thresholds / acceptance criteria, Other
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Provides a qualitative account of how “ethics owners” institutionalize ethics inside tech firms and shows how corporate logics (meritocracy, technological solutionism, market fundamentalism) can turn ethics into performative checklists and risk-management, but it does not specify testable fairness requirements, metrics, thresholds, monitoring signals, or revision governance.
Governance maturity: Absent
Measurement procedure: Not described as quantitative measurement; analysis is conceptual/qualitative: ethnographic + interviews + textual sources to identify how “ethics” is institutionalized and how corporate logics shape practices and pitfalls.
Metrics used: None (no fairness metrics; discusses ethics practices such as checklists, “red teaming,” risk accounting, codes/principles).
Monitoring present: No
Notes: Key findings: three dominant tech logics (meritocracy, technological solutionism, market fundamentalism) shape ethics work; highlights pitfalls: normalizing ethical mishaps (normalization of deviance; “fail fast”) and blinkered isomorphism (industry imitation + ethics-washing/cargo-cult performances).
Operationalization present: Yes
Protected attrs / groups: Not scoped to a specific protected attribute; references societal harms including racial bias in risk assessments and facial recognition; also #metoo/#timesup (sexism/racism).
QA notes: Strong qualitative grounding (ethnographic + 17 interviews) and clear conceptual framing of “ethics owners” + corporate logics. Operationalization is discussed as organizational practices (checklists, red teaming, risk accounting, codes/principles) rather than measurable fairness requirements. No evaluation/validation of interventions and no lifecycle monitoring/revision specifics.
QA pass: Pass
QA score: 7.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: p
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
Spec explicitness/testability: Implicit
Spec snippet: Ethics owners develop strategies to “align everyday practices with corporate logics” and translate external norms (e.g., UN Universal Declaration of Human Rights) into internally tractable practices; ethics risks being operationalized as checklists/toolkits that imply ethics “has been done.”
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators, Users
Study ID: P091
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Journal
Year: 2019