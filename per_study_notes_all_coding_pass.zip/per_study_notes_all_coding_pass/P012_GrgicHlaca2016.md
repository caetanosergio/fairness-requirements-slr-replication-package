# P012 — GrgicHlaca2016

Acceptance criteria stated: No
Citation: GrgicHlaca2016
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines process fairness measures over a model’s feature set and studies feature selection as a design-time mechanism: remove features judged ‘uncomfortable/unfair’ by users and analyze resulting accuracy and outcome fairness trade-offs across all 512 feature subsets (logistic regression on COMPAS).
Data Type: Tabular
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Policing
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates fairness notions by reference to anti-discrimination laws and legal decision contexts, but broadens beyond legally protected sensitive features to societal judgments of feature use (moral norms, privacy regulations, precedents).
Elicitation artifact: Fairness notions list, Other
Elicitation method: Surveys
Elicitation present: Yes
Elicitation snippet: Recruits 100 US AMT workers and asks, for each of 9 features, whether it is fair to use (a priori), fair if it increases accuracy, and fair if it increases racial disparity; computes % judging each feature fair and uses these as inputs to process fairness measures.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Provides explicit, testable process-fairness requirements grounded in stakeholder judgments for feature selection and quantifies trade-offs with outcome fairness and accuracy on COMPAS, but lacks acceptance thresholds and does not address monitoring or revision to keep process fairness valid as norms and data shift over time.
Governance maturity: Absent
Measurement procedure: Collect fairness judgments for each candidate feature via survey (Q1–Q3). For each feature subset F' (2^9 = 512), train logistic regression on COMPAS ProPublica data with repeated random 50/50 train-test splits (10 runs) and compute accuracy. Compute outcome fairness as disparity in misclassification rates between White vs non-White. Compute the three process fairness measures using the conditioned user sets per feature depending on whether adding the feature increases accuracy or increases disparity, then compare trade-offs among accuracy, outcome fairness, and process fairness across subsets.
Metrics used: Process fairness metrics: feature-a priori fairness, feature-accuracy fairness, and feature-disparity fairness computed from survey-based user sets (intersection across used features divided by |U|). Outcome fairness metric: disparity in mistreatment via |FPR_w−FPR_nw| + |FNR_w−FNR_nw| (Eq.6) and outcome fairness = − outcome unfairness (Eq.7). Also reports prediction accuracy (logistic regression) under different feature subsets.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive/protected-style features include race, gender, and age; outcome fairness computed between Whites vs non-Whites; survey explicitly asks about feature fairness including race/gender/age and how judgments change if feature increases racial disparity.
QA notes: Strongly requirements-relevant for RQ1/RQ2 as it defines an explicit, testable notion of procedural/process fairness grounded in stakeholder judgments of feature use (including conditional on accuracy and disparity effects), then operationalizes it and empirically maps trade-offs against outcome fairness and accuracy on COMPAS. Does not address monitoring/revision over time or governance beyond one-off elicitation.
QA pass: Pass
QA score: 9.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Uses a user survey (AMT, US workers) to elicit societal judgments about feature fairness (Q1–Q3) and defines fairness as a fraction of users who consider all used features fair; connects process fairness to moral philosophy (deontological vs utilitarian) and distinguishes process vs outcome fairness, but does not provide governance/monitoring procedures post-deployment.
Spec explicitness/testability: Explicit + testable
Spec snippet: Process fairness of a classifier using feature set F' is defined as the fraction of users who judge every feature in F' as fair; defines three quantitative measures: feature-a priori fairness (Eq.1), feature-accuracy fairness (Eq.2–3), and feature-disparity fairness (Eq.4–5), based on user sets U_f, U^Acc_f, U^Disp_f and measured changes in accuracy/disparity when adding/removing a feature.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Regulators, Users
Study ID: P012
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation, User study
Validation snippet: Empirical evaluation on COMPAS ProPublica dataset with logistic regression across 512 feature subsets and repeated train/test splits; user study (100 AMT workers) to estimate feature fairness judgments; analyzes trade-offs between accuracy, process fairness, and outcome fairness.
Validation/testing present: Yes
Venue Type: Workshop
Year: 2016