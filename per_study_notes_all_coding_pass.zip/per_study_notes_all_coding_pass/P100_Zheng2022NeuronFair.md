# P100 — Zheng2022NeuronFair

Acceptance criteria stated: No
Citation: Zheng2022NeuronFair
DES content: Yes
DES snippet: We propose NeuronFair ... quantitatively interprets DNNs’ fairness violations ... and uses the interpretation results to guide the generation of more diverse instances ... and can handle both structured and unstructured data.
Data Type: Multi-modal
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: No
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Individual consistency, Other
Gap summary (1 sentence): NeuronFair operationalizes fairness as individual discrimination (IDIs) and proposes an interpretable white-box testing pipeline (ActDiff/AS curve/AUC, biased-neuron-guided generation) validated on multiple datasets, but does not provide lifecycle monitoring or revision mechanisms beyond pre-deployment testing.
Governance maturity: Absent
Measurement procedure: Compute neuron ActDiff between paired instances differing only in sensitive attribute; plot AS curve (percentage of neurons above ActDiff thresholds) and compute AUC; identify biased layer and biased neurons using threshold Td at intersection of AS curve with y=x; generate IDIs in global+local phases guided by biased neurons with dynamic loss and momentum; evaluate on 7 datasets and compare with Aequitas, SymbGen, ADF, EIDIG.
Metrics used: Individual discrimination via IDI determination (Def.1: prediction differs when only sensitive attributes differ). Discrimination metric: AUC area under AS curve based on neuron activation difference (ActDiff) across layers.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Gender, race, age (Adult); gender, age (German Credit, Bank Marketing); race (COMPAS); gender (MEPS); gender, race (CelebA-IN, LFW-IN face detection).
QA notes: From abstract+method+evaluation excerpts: proposes interpretable white-box fairness testing for DNNs by identifying biased neurons; defines individual discrimination/IDI; introduces ActDiff/AS curve/AUC metric; evaluates generation effectiveness/efficiency/diversity and fairness improvement via retraining across 7 datasets (structured + image). Threats to validity discuss attribute correlation, single sensitive attribute at a time, and white-box access assumptions.
QA pass: Pass
QA score: 7.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: N
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision present: No
SOC content: No
Spec explicitness/testability: Explicit + testable
Spec snippet: Individual discrimination exists when two valid inputs which differ only in the sensitive attributes but receive a different prediction result from a given DNN ...
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P100
System Type: Classification
Threshold value: ActDiff threshold interval step=0.005; discrimination threshold Td defined as AS curve intersection with y=x (example Td=0.33); activation threshold for 'activated neurons' > 0.5 in biased neuron coverage eval; image step_size_g=0.15; other hyperparameters per Table 2.
Thresholds stated: Partial
Trade-offs managed: Unclear
Validation method: Offline evaluation
Validation snippet: Extensive evaluations across 7 datasets and the corresponding DNNs demonstrate NeuronFair’s superior performance ... compared with Aequitas, SymbGen, ADF, and EIDIG.
Validation/testing present: Yes
Venue Type: Conference
Year: 2022