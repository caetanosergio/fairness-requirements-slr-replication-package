# P046 — Vasudevan2020

Acceptance criteria stated: Partial
Citation: Vasudevan2020
DES content: Yes
DES explicit requirement: Yes
DES snippet: Presents LiFT (LinkedIn Fairness Toolkit) architecture and system design for scalable fairness measurement integrated across the ML lifecycle (before/during/after training and online serving), including distributed computation (Spark), caching, and configurable APIs/UDF extensibility.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Deployed
Domain: Other
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Frames fairness risks in web-scale ML applications trained on biased feedback/judgments and deployed in search/recommendation and safety products; emphasizes real-world constraints: large distributed datasets, production pipelines, and fairness drift over time.
Elicitation present: Yes
Elicitation snippet: Explicitly calls for fairness decisions to be guided by social, ethical, and legal dimensions and inputs from a diverse set of key stakeholders; discusses stakeholder alignment when metrics conflict (e.g., precision vs recall trade-off).
End-to-end coverage: Full loop
Failure modes: Missing context assumptions, Monitoring without triggers, Other, Unstable subgroup definitions
Fairness notions: Error parity, Individual consistency, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Provides an end-to-end, production-oriented framework (LiFT) for scalable fairness measurement integrated across the ML lifecycle with statistical significance testing and monitoring signals, but leaves key governance questions (who sets fairness thresholds, how to resolve conflicting metrics, and when/how to trigger mitigation or rollback) largely to organizational stakeholder processes rather than specifying concrete operational requirements.
Governance maturity: Developing
Measurement procedure: Implements Spark-based pipeline: join labels/scores with protected-attribute dataset, build cached virtual dataset, compute distributions/benefit vectors, then compute fairness metrics either single-node (on aggregated Distribution/BenefitMap) or distributed (on cached dataset). Supports pre- and post-training measurement and (limited) mitigation via preprocessing reweighting; includes permutation testing using sampling (≈100k points) for power. Evaluated on 3 LinkedIn production pipelines (D1/D2 classifiers; D3 ranking model) plus UCI Adult dataset (oversampled to 10M) to show scalability and interpretability trade-offs among metrics.
Metrics used: Training data: representativeness and label-distribution metrics including KL divergence, Jensen–Shannon divergence, Lp norms, total variation distance, and label-distribution demographic parity δ_DP. Post-training/model: predicted-score distribution distances; equalized odds δ_EO; performance metrics across groups (AUC/AUROC, accuracy, PPV/precision, TPR/recall, FPR/FNR); aggregate inequality metrics (Generalized Entropy Index, Theil L/T) over benefit vectors; permutation tests for statistically significant subgroup differences (p-values).
Monitoring present: Yes
Monitoring signals: Ongoing fairness metric measurement in online serving; drift detection with respect to fairness; track trends of fairness metrics over time (e.g., GEI/EO) plus statistical tests.
Monitoring snippet: Online serving stage measures and monitors fairness metrics continuously, supports A/B tests, and can detect model drift with respect to fairness.
Operationalization present: Yes
Protected attrs / groups: Uses protected attributes such as gender (male/female/unknown) and country in LinkedIn deployments; discusses missing/uncertain protected attributes (volunteered vs inferred) and the need to account for uncertainty; notes additional segments (education qualifications) may be relevant.
QA notes: CIKM’20 applied research paper introducing LinkedIn Fairness Toolkit (LiFT) for scalable fairness measurement in production ML systems. Strong RE-relevant contribution: explicit lifecycle integration (pre/during/post training + online), distributed computation design (Spark, caching, hybrid single-node/distributed), configurable metrics/UDF extensibility, and statistical testing for subgroup performance gaps. Discusses practical challenges: data quality and small samples, protected attribute availability/uncertainty, impossibility trade-offs (precision/recall/FPR under prevalence differences), and need for multi-stakeholder governance. Mitigation coverage is limited (preprocessing variant), with open problems for end-to-end product fairness and streaming/nearline mitigation.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: Yes
Revision snippet: Suggests iterative metric selection and model/data updates when unfairness is detected; highlights need for stakeholder consensus and notes hooks across lifecycle to enable repeated measurement and mitigation, but does not specify concrete operational owners/triggers beyond monitoring and stakeholder processes.
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Notes potential discrimination/harms for disadvantaged groups; stresses socio-technical governance: selecting fairness notions requires consensus across stakeholders (product, legal, policy, PR, engineering, ML) and careful handling of protected-attribute data and uncertainty.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines deployment requirements for fairness tooling: flexibility (library + production workflows), scalability (distributed computation), integration hooks across ML lifecycle; formalizes fairness measurements such as δ_DP(g1,g2)=|P(Y=1|G=g1)−P(Y=1|G=g2)| for label distribution and δ_EO(y,g1,g2)=|P(Ŷ=1|Y=y,G=g1)−P(Ŷ=1|Y=y,G=g2)| for equalized odds.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Org leadership, Other, Regulators
Study ID: P046
System Type: Classification
Threshold value: Uses statistical significance testing (permutation tests with p-values) and notes need for decision thresholds/CI/SE to make bias thresholds clearer; does not prescribe universal numeric thresholds (application-specific).
Thresholds stated: Yes
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Deployed in three LinkedIn ML pipelines (datasets up to ~28M records) and evaluated on UCI Adult; reports resource utilization (GB-hours) for fairness metric computation vs training/scoring and shows ability to compute multiple metrics at scale; provides deployment case insights and lessons learned.
Validation/testing present: Yes
Venue Type: Conference
Year: 2020