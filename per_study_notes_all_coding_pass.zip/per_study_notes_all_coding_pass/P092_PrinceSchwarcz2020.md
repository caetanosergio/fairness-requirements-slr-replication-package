# P092 — PrinceSchwarcz2020

Acceptance criteria stated: No
Citation: Prince, Anya E.R., and Daniel Schwarcz. "Proxy Discrimination in the Age of Artificial Intelligence and Big Data." Iowa Law Review 105 (2020): 1257–1318. https://scholarship.law.umn.edu/faculty_articles/682
DES content: Yes
DES snippet: Defines proxy discrimination as a subset of disparate impact where the usefulness of a facially neutral practice derives (at least in part) from the disparate impact itself; argues AI + big data make unintentional but rational proxy discrimination more likely by discovering less intuitive proxies when direct protected-class data are excluded.
Decision rule tied to metric: Unclear
Domain: General
ENV content: Yes
ENV snippet: Frames the problem as a fundamental challenge to antidiscrimination regimes in real-world socio-technical domains (insurance, employment, criminal justice) due to expanded data collection and opacity; emphasizes regulators’/firms’ limited ability to understand model behavior and the legal structure of ‘directly predictive’ protected traits.
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Missing context assumptions, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Contextual/legal compliance, Other, Procedural fairness
Gap summary (1 sentence): Clarifies proxy discrimination as distinct from general disparate impact and argues AI systems will inevitably seek proxies for directly predictive protected traits, motivating policy/technical strategies (data collection, transparency, approved-factor rules, and de-proxying models) but without specifying implementable lifecycle monitoring/revision mechanisms.
Governance maturity: Absent
Measurement procedure: Conceptual legal analysis with illustrative hypotheticals and econometric intuition (e.g., controlling for protected traits to test whether a variable’s predictive power derives from proxying).
Metrics used: Not a technical metrics paper; discusses disparate impact generally and uses conceptual/econometric framing (omitted variable bias) to explain proxies.
Monitoring present: No
Notes: Use for RQ1/RQ3: provides strong conceptual foundations on proxies, ‘directly predictive’ protected traits, and why removing protected attributes is insufficient; also provides a policy strategy menu (approved factors, protected-class data collection/disclosure, de-proxying statistical models).
Operationalization present: Yes
Protected attrs / groups: Discusses legally protected classes broadly (race, sex, disability, genetics, preexisting conditions) and how algorithms can reconstruct or proxy for protected attributes via correlated variables (e.g., ZIP code, behavioral data).
QA notes: Conceptual legal analysis (not an empirical/technical system paper). Strong on objectives, detailed argument structure, and practical policy relevance; weak on technical operationalization and empirical validation because it does not propose or test concrete metrics/thresholds or implementations. Discusses ethical/legitimacy implications and policy strategies, but provides no lifecycle monitoring/revision procedure or acceptance criteria.
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: Y
Revision present: No
SOC content: Yes
SOC snippet: Analyzes normative harms: proxy discrimination undermines goals of antidiscrimination regimes that aim to prevent outcome disparities for protected groups, even when discrimination is ‘rational’; discusses societal goals such as risk sharing, anti-stereotyping, preventing chilling effects, and reversing past discrimination.
Spec explicitness/testability: Explicit not testable
Spec snippet: Introduces the key condition for proxy discrimination: a facially neutral practice producing disparate impact constitutes proxy discrimination only when the practice’s usefulness derives in part from producing that disparate impact. Distinguishes intentional vs unintentional proxy discrimination and direct (causal/opaque) vs indirect proxy discrimination pathways in AI contexts.
Specification format: Narrative goal, Other
Specification present: Yes
Study ID: P092
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Journal
Year: 2020