# P049 — Agarwal2021

Acceptance criteria stated: No
Citation: Agarwal2021
DES content: Yes
DES explicit requirement: Yes
DES snippet: Proposes NIFTY, a unified framework to learn fair and stable GNN representations by (1) adding a Siamese/triplet-style objective that aligns embeddings across noisy and counterfactual graph views, and (2) modifying the GNN architecture with layer-wise Lipschitz (spectral) normalization of weights to improve message passing robustness and promote counterfactual fairness/stability.
Data Type: Other
Decision rule tied to metric: Unclear
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV explicit requirement: Yes
ENV snippet: Motivates that GNN representations are used in real-world/high-stakes settings and must be both fair (avoid discriminatory bias tied to sensitive attributes) and stable (robust to small perturbations/attacks on graph structure and node attributes). Introduces application contexts and datasets in criminal justice (bail/recidivism) and financial lending (credit risk/default).
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Drift not addressed, No revision process/ownership, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Individual consistency, Other, Outcome parity
Gap summary (1 sentence): NIFTY unifies counterfactual fairness and stability for GNN representations via augmentation-based objectives and Lipschitz-normalized message passing, demonstrating strong offline improvements on fairness and robustness metrics in high-stakes graph datasets, but it does not specify operational acceptance thresholds or monitoring/revision governance for maintaining these properties after deployment.
Governance maturity: Absent
Measurement procedure: Generate augmented graph views by (a) masking/noising non-sensitive attributes, (b) flipping binary sensitive attribute to create counterfactual node ũ_s, and (c) dropping edges with probability p_e. Train encoder ENC with Siamese-style objective L_s using cosine distance and stop-gradient; jointly optimize with downstream BCE classification loss L_c using λ. Architecturally, compute per-layer Lipschitz constants via spectral norm and normalize weights W_a^k to bound embedding sensitivity; theoretically derive bounds (product of layer norms) for stability and counterfactual unfairness.
Metrics used: Counterfactual unfairness rate (percent of test nodes whose predicted label changes when sensitive attribute is flipped); instability rate (percent whose prediction changes under random attribute noise/edge perturbations); group fairness metrics ΔSP (statistical parity difference) and ΔEO (equal opportunity difference); predictive performance AUROC and F1-score.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Binary sensitive attribute s per dataset: gender (German credit), race (recidivism/bail), age (credit defaulter). Counterfactual fairness is operationalized by flipping s; group fairness measured via ΔSP and ΔEO between s=0 vs s=1 groups.
QA notes: UAI 2021 paper proposing NIFTY to jointly enforce counterfactual fairness and stability in GNN embeddings. Clear formal definitions, objective (λ-weighted task + similarity loss), architectural Lipschitz/spectral normalization, theoretical bounds, and extensive offline evaluation/ablation on lending and criminal-justice graphs. No stakeholder elicitation process; governance/monitoring over time not covered; fairness acceptance criteria/thresholds not specified beyond tunable λ and perturbation parameters.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: p
Revision ownership defined: No
Revision present: No
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Frames fairness as avoiding discriminatory bias and specifically targets invariance to sensitive attributes (e.g., gender, race, age) in high-stakes decisions. Discusses fairness notions (group, individual, counterfactual) and evaluates both counterfactual unfairness and group fairness gaps (ΔSP, ΔEO) on datasets with protected attributes.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines requirements for the encoder ENC: counterfactual fairness ENC(u)=ENC(ũ_s) when flipping sensitive attribute s; stability via Lipschitz continuity |ENC(ũ)−ENC(u)|_p ≤ L|b̃_u−b_u|_p under attribute/edge perturbations. Specifies NIFTY training objective min[(1−λ)L_c + λ L_s], where L_s is a (stop-grad) similarity loss aligning embeddings of original nodes with their perturbed and counterfactual counterparts, and adds layer-wise weight normalization using Lipschitz/spectral norms to bound representation changes; provides theorems bounding stability and counterfactual unfairness.
Specification format: Constraint (formal/informal), Policy/rule
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other
Study ID: P049
System Type: Multi-task/Other
Threshold value: Regularization coefficient λ controls trade-off between task loss and fairness/stability objective (used λ=0.6; sensitivity over λ). Perturbation probabilities p_n (attribute) and p_e (edge drop) are parameters; no fixed acceptance thresholds for fairness metrics are specified.
Thresholds stated: Partial
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Evaluates NIFTY on three constructed graph datasets (German credit, Recidivism/bail, Credit defaulter) across five GNN backbones (GCN, GraphSAGE, JK, GIN, InfoMax). Reports AUROC/F1 plus unfairness/instability rates and ΔSP/ΔEO; includes ablation (objective vs architecture) and sensitivity to λ; compares against FairGCN and RobustGCN baselines.
Validation/testing present: Yes
Venue Type: Conference
Year: 2021