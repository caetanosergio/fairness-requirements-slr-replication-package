# P068 — Jung2024CounterfactuallyFairImages

Acceptance criteria stated: No
Citation: Jung2024CounterfactuallyFairImages
DES content: Yes
DES explicit requirement: Yes
DES snippet: Defines and studies the relationship between counterfactual fairness (CF) and group fairness (equalized odds) for image classifiers; constructs counterfactual image benchmarks (CelebA-CF, LFW-CF) using IP2P editing plus human filtering/verification; proposes Counterfactual Knowledge Distillation (CKD) to reduce reliance on a latent shortcut attribute G (e.g., hair length) so CF-achieving models can also satisfy group fairness.
Data Type: Image
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Motivates fairness in societal computer vision deployments (e.g., facial recognition, job interview video analysis) and frames harms as discrimination against individuals/groups; discusses ethical terminology choice (“sex” not “gender”) and cautions about normative harms from dichotomizing gender.
Elicitation artifact: Other
Elicitation method: Expert elicitation, Other, Surveys
Elicitation present: Yes
Elicitation snippet: Human annotation is used to curate and verify counterfactual image pairs: five annotators filter edited pairs as “correct/incorrect” using guidelines over 10 perceived facial attributes; additional annotators validate sensitive-attribute change and non-sensitive preservation, reporting high reliability.
End-to-end coverage: Partial
Failure modes: Drift not addressed, Governance absent, No thresholds / acceptance criteria, Other
Fairness notions: Error parity, Individual consistency, Other
Gap summary (1 sentence): Provides strong dataset+metric operationalization and evidence that CF does not imply EO-based group fairness in image settings (due to latent shortcut attribute G), but does not define acceptance thresholds, monitoring signals, or revision/governance mechanisms for maintaining fairness over time in deployment.
Governance maturity: Absent
Measurement procedure: Creates counterfactual image pairs by editing test images of CelebA and LFW with Instruct-Pix2Pix prompts that alter sex-related visual characteristics while preserving identity and non-sensitive attributes; filters low-quality pairs via human votes; verifies reliability via additional annotators (sensitive attribute change + non-sensitive preservation). Evaluates models on original test sets for accuracy/DEO and on CelebA-CF/LFW-CF for CD. Provides theory (Theorem 4.1) that EO disparity is upper bounded by model sensitivity to latent attribute G, motivating CKD that distills a teacher more robust to G while enforcing counterfactual pairing.
Metrics used: Counterfactual fairness metric: Counterfactual Disparity (CD) = E[1{Ŷ_a→a' ≠ Ŷ}]. Group fairness metric: Equalized Odds disparity (DEO) = max_{y,y'} |P(Ŷ=y'|A=0,Y=y) - P(Ŷ=y'|A=1,Y=y)|. Also uses accuracy; introduces robustness-to-G metric RFP (rate of flipped predictions under G manipulation).
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive attribute: sex (binary, using term “sex” to avoid social-identity connotations). Target labels: CelebA blond hair; LFW smiling. Discusses latent shortcut attribute G correlated with A (e.g., hair length; accessories).
QA notes: NeurIPS’24 (Datasets & Benchmarks) paper contributes counterfactual image benchmarks (CelebA-CF, LFW-CF) + theoretical/empirical analysis of CF vs EO group fairness in image SCMs with latent shortcut attribute G, and proposes CKD to reduce reliance on G. Strong on operationalization (CD, DEO, RFP), dataset curation with human validation, and empirical comparisons; lacks deployment-time acceptance criteria, monitoring, and change management.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: No
SOC snippet: Discusses societal impacts and ethical considerations of representing sex via perceived facial attributes; provides cautions for dataset use but does not specify governance, monitoring, or organizational processes for deployed systems.
Spec explicitness/testability: Explicit + testable
Spec snippet: Operationalizes CF as prediction invariance between an image and its counterfactual with sensitive attribute intervened; operationalizes GF via equalized odds (EO). Defines CD (counterfactual disparity) and DEO (disparity of EO) as measurable violations.
Specification format: Constraint (formal/informal)
Specification present: Yes
Study ID: P068
System Type: CV
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation
Validation snippet: Empirical evaluation across CelebA/CelebA-CF and LFW/LFW-CF compares Scratch, CF-aware methods (Scratch+aug, CP), individual-fairness methods, and CKD on CD, DEO, and accuracy; includes additional experiments (synthetic CIFAR-10B) and ablations showing CKD improves DEO while maintaining low CD when robustness to G is distilled.
Validation/testing present: Yes
Venue Type: Conference
Year: 2024