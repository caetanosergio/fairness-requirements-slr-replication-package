# P090 — Fishkin2014

Acceptance criteria stated: No
Citation: Fishkin2014
DES content: No
Data Type: Other
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: Focus on the structure of opportunities society offers and how it can be expanded (unitary vs pluralistic opportunity structures).
Elicitation present: No
End-to-end coverage: None
Fairness notions: Other, Procedural fairness
Gap summary (1 sentence): Conceptual theory of equal opportunity framed as reducing societal bottlenecks and expanding pluralistic pathways, but not operationalized into measurable requirements, metrics, acceptance criteria, or governance processes.
Governance maturity: Absent
Monitoring present: No
Operationalization present: No
Protected attrs / groups: Class/socioeconomic status; race; gender; disability (discussed as sources of bottlenecks/segregation and unequal opportunity)
QA notes: Book review summary of Fishkin (2014): proposes opportunity pluralism and anti-bottleneck principle; identifies qualification/developmental/instrumental bottlenecks; discusses family/merit/starting gate/individuality problems for equality-of-opportunity theories and implications for policy and anti-discrimination.
QA pass: Pass
QA score: 6.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: p
Revision present: No
SOC content: Yes
SOC snippet: Bottlenecks (qualification, developmental, instrumental-good) reduce opportunity pluralism; anti-bottleneck principle aims to eliminate or help people through/around bottlenecks.
Spec explicitness/testability: Explicit not testable
Spec snippet: Fishkin argues for "opportunity pluralism" and an "anti-bottleneck principle" to expand and diversify opportunity structures rather than fixate on a single metric of equal opportunity.
Specification format: Narrative goal, Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Org leadership, Regulators, Users
Study ID: P090
System Type: Multi-task/Other
Thresholds stated: No
Trade-offs managed: Yes
Validation/testing present: No
Venue Type: Journal
Year: 2014