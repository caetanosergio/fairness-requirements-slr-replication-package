# P058 — Mambreyan2022

Acceptance criteria stated: No
Citation: Mambreyan2022
DES content: Yes
DES explicit requirement: Yes
DES snippet: Demonstrates dataset bias in deception detection by training a classifier to predict sex from features and then using predicted sex as a proxy ‘lie detector’ (predict lie for females, truth for males). Shows this biased proxy achieves performance comparable to state-of-the-art deception detectors on biased datasets, and that purported SOTA techniques fail on an unbiased dataset.
Data Type: Multi-modal
Decision rule tied to metric: No
Deployment Status: Prototype
Domain: Other
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes deception detection is evaluated using supervised ML on small video-based datasets (Real-life Trial: 121 clips; Bag-of-Lies: 325 recordings; Miami University: 320 clips) and that dataset composition and cross-validation design can induce spurious correlations between sensitive attributes (notably biological sex) and the truth/lie label, enabling high reported performance without learning deception.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: Partial
Failure modes: Governance absent, Other, Unstable subgroup definitions
Fairness notions: Contextual/legal compliance, Error parity, Other
Gap summary (1 sentence): Shows that headline deception-detection performance can be largely explained by dataset bias (especially sex imbalance) and weak evaluation practices on small datasets, and calls for bias-aware dataset design and sanity checks, but does not provide a deployment-ready fairness requirement with acceptance thresholds or monitoring/revision governance.
Governance maturity: Absent
Measurement procedure: Train sex classifiers on extracted features (micro-expression vectors, IDT features, gaze features). On test points, predict sex and use it as a proxy for deception (lie if predicted female, truth if predicted male). Compare to classifiers trained normally on truth/lie labels. Use identity-disjoint cross-validation (10-fold for Real-life Trial, 3-fold for Bag-of-Lies) repeated across multiple random fold samplings to quantify variance; evaluate generalization by testing SOTA techniques on a deliberately unbiased dataset (Miami University deception dataset) where all identities have equal truth/lie balance.
Metrics used: Accuracy; AUC; sex-prediction accuracy implicitly; compares biased proxy vs truth/lie-trained classifiers; discusses overestimation from dataset bias and discrimination risk w.r.t. sensitive attributes.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Biological sex (male/female) is the primary sensitive attribute analyzed; paper notes potential other sensitive attributes (race, age) and other incidental dataset properties (background, clothing, pose) that could be exploited.
QA notes: ICPR 2022 paper auditing deception detection datasets for sex bias: constructs bias-only proxy via sex prediction and shows comparable performance to prior SOTA on biased datasets; evaluates generalization on an unbiased dataset where performance drops to chance. Strong operationalization and offline evaluation; recommendations focus on dataset design/sanity checks rather than lifecycle monitoring/governance.
QA pass: Pass
QA score: 8.5
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: p
QA7 Stakeholders/elicitation addressed: N
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: Yes
Revision snippet: Recommends future datasets minimize bias (equal truth/lie per subject, consistent setting per subject) and that researchers perform sensibility checks for dataset bias before claiming high deception-detection performance; does not define an operational post-deployment revision process.
Revision trigger defined: No
SOC content: Yes
SOC explicit requirement: Yes
SOC snippet: Highlights ethical risks of AI lie detectors and argues that biased models are discriminatory w.r.t. sensitive attributes (sex, and potentially race/age) and can create harmful false expectations for media/governments; recommends bias-aware dataset construction and sensibility checks before claims of high-stakes capability.
Spec explicitness/testability: Explicit + testable
Spec snippet: Operationalizes ‘dataset bias’ by (i) measuring label imbalance across sex in datasets (e.g., females lie more in both Real-life Trial and Bag-of-Lies), and (ii) constructing a bias-only predictor: learn sex from features, then map sex→lie/truth. Evaluates via cross-validation with identity-disjoint folds and reports accuracy/AUC ranges across repeated fold samplings to show variance.
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Developers, Other, Regulators, Users
Study ID: P058
System Type: Classification
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Audit, Offline evaluation
Validation snippet: Performs offline experiments on three datasets (Real-life Trial, Bag-of-Lies, Miami University) with identity-disjoint CV; reports that bias-only proxy achieves comparable performance to SOTA on biased datasets and that SOTA techniques drop to chance on the unbiased dataset; includes sensitivity analysis via repeated fold resampling and reports min/mean/max metrics.
Validation/testing present: Yes
Venue Type: Conference
Year: 2022