# P094 — Bietti2020FAccT

Acceptance criteria stated: No
Citation: Bietti, Elettra. "From Ethics Washing to Ethics Bashing: A View on Tech Ethics from Within Moral Philosophy." In Proceedings of the 2020 Conference on Fairness, Accountability, and Transparency (FAT\ '20)*, 210–219. Barcelona, Spain, Jan 27–30, 2020. ACM. https://doi.org/10.1145/3351095.3372860
DES content: Yes
DES snippet: Conceptualizes and critiques two patterns: “ethics washing” (industry instrumentalization of ethics language/structures to justify self-regulation) and “ethics bashing” (trivializing ethics/moral philosophy by equating it with corporate ethics boards or dismissing it as mere PR/ivory-tower). Proposes ethics as a mode of inquiry to evaluate competing tech policy strategies.
Decision rule tied to metric: No
Domain: General
ENV content: Yes
ENV snippet: Frames “ethics” rhetoric in tech policy as contested and often weaponized to support deregulation/self-regulation; situates discussion in real governance episodes (e.g., Google ATEAC) and argues we need to view technology ethics from within moral philosophy rather than only as corporate governance structures.
Elicitation method: Not described
Elicitation present: No
End-to-end coverage: None
Failure modes: Governance absent, Missing context assumptions, Monitoring without triggers, No revision process/ownership, No thresholds / acceptance criteria, Other
Gap summary (1 sentence): Provides a strong conceptual and normative governance critique of tech-ethics rhetoric (ethics washing vs ethics bashing) and defends moral philosophy as inquiry, but offers no operational RE artifacts (elicitation outputs, measurable acceptance criteria, monitoring signals, or revision ownership) for implementing governance over time.
Governance maturity: Absent
Measurement procedure: Conceptual analysis from moral philosophy: defines ethics washing and ethics bashing; analyzes limitations/roles of moral philosophy (instrumental vs intrinsic value), and discusses governance implications via illustrative cases and argumentation (no empirical measurement).
Metrics used: Not applicable (conceptual/philosophical governance critique; no technical fairness metrics).
Monitoring present: No
Notes: Primarily useful for RQ1/RQ3 at the governance/ethics layer: clarifies why ethics codes/boards can be performative and how critiques can accidentally trivialize moral inquiry; supports framing governance requirements beyond ‘principles lists’.
Operationalization present: No
Protected attrs / groups: Not focused on protected attributes directly; discusses impacts on marginalized stakeholders and references anti-LGBT backlash case (ATEAC), and broader social justice concerns in tech governance.
QA notes: Conceptual/philosophical paper with clear definitions and structured argument; strong relevance for governance and ethics-inquiry framing. No empirical validation, no technical operationalization, and no lifecycle monitoring/revision process (ownership/triggers/acceptance criteria) beyond critique and recommendations.
QA pass: Pass
QA score: 8
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: N
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: N
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC snippet: Argues that ethics washing can shift burdens to marginalized stakeholders and narrow public imagination; stresses the role of moral philosophy in dialogue, principled reasoning, and scrutinizing power/inequality within technology governance debates.
Spec explicitness/testability: Implicit
Spec snippet: Normative claim: tech policy should move beyond both “ethics washing” and “ethics bashing” by treating ethics as an intrinsically valuable mode of inquiry that can assess governance strategies, rather than reducing ethics to boards/codes or to corporate cover.
Specification format: Narrative goal, Other
Specification present: Yes
Study ID: P094
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Not described
Validation/testing present: No
Venue Type: Conference
Year: 2020