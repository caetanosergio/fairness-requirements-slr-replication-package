# P061 — Ghai2023DBIAS

Acceptance criteria stated: No
Citation: Ghai2023DBIAS
DES content: Yes
DES explicit requirement: Yes
DES snippet: Presents D-BIAS, a visual interactive human-in-the-loop system that infers a causal network (PC algorithm + SEM), allows users to refine the causal model, audit bias with multiple fairness metrics, and mitigate bias by deleting/weakening unfair causal edges; it then simulates a minimally-distorted debiased dataset that can be downloaded for downstream ML training.
Data Type: Tabular
Decision rule tied to metric: Yes
Deployment Status: Prototype
Domain: General
ENV content: Yes
ENV explicit requirement: Partial
ENV snippet: Assumes algorithmic bias arises from sensitive attributes (e.g., gender, race) and proxy variables in tabular data, and that fairness is context-dependent and cannot be fully automated; also assumes causal discovery from data may be imperfect due to sampling bias or missing attributes, requiring expert refinement.
Elicitation artifact: Context model, Other
Elicitation method: Expert elicitation
Elicitation present: Yes
Elicitation snippet: Human-in-the-loop workflow where users inject domain knowledge by directing/reversing/adding/deleting causal edges and judging which causal paths/edges are unfair before debiasing.
End-to-end coverage: Partial
Failure modes: Missing context assumptions, Other, Unstable subgroup definitions
Fairness notions: Error parity, Individual consistency, Other, Outcome parity, Procedural fairness
Gap summary (1 sentence): Provides an end-to-end HITL causal-model-based workflow to audit and mitigate bias in tabular datasets with explicit fairness/utility/distortion metrics and empirical/user-study evaluation, but does not define deployment-time monitoring or governance for how debiasing decisions should be managed over time.
Governance maturity: Absent
Measurement procedure: Infer initial causal graph with PC algorithm and quantify edge strengths with (linear / multinomial logit) SEM; user refines graph with add/delete/direct/reverse operations guided by BIC delta. Audit bias by selecting sensitive attribute(s) or custom intersectional groups and computing dataset-level and classifier-level fairness metrics (3-fold CV) plus utility and distortion. Mitigate bias by deleting/weakening unfair causal edges; generate debiased dataset by selectively simulating impacted nodes in topological order using modified SEM with controlled randomness and rescaling to match original distributions; evaluate trade-offs and export debiased data.
Metrics used: Fairness: statistical parity difference, individual fairness (kNN label disagreement), accuracy difference, false negative rate difference, false positive rate difference. Utility: accuracy, F1. Distortion: Gower distance between original and debiased rows. Also uses BIC score change for causal-model refinement and supports subgroup/intersectional comparisons.
Monitoring present: No
Operationalization present: Yes
Protected attrs / groups: Sensitive attributes such as gender and race; supports subgroup and intersectional groups (e.g., Black females vs White males) via custom group selection.
QA notes: D-BIAS (TVCG 2023) is a visual analytics, human-in-the-loop debiasing system using causal discovery (PC) + SEM and interactive causal graph editing to identify proxy-mediated bias and generate a minimally distorted debiased dataset. Strong operationalization and evaluation (3 datasets + user study) with explicit fairness/utility/distortion trade-offs; acknowledges causal discovery assumptions and misuse risks; no monitoring/revision governance for ongoing deployment.
QA pass: Pass
QA score: 10
QA1 Defined objectives/requirements: Y
QA10 Future directions/implications: Y
QA2 Approach described in detail: Y
QA3 Representation/operationalization specified: Y
QA4 Cross-domain vs domain-scoped: Y
QA5 Practical/research value: Y
QA6 Trade-offs discussed: Y
QA7 Stakeholders/elicitation addressed: Y
QA8 Validation/evaluation discussed: Y
QA9 Limitations/threats/ethics: Y
Revision ownership defined: Unclear
Revision present: No
Revision trigger defined: Unclear
SOC content: Yes
SOC explicit requirement: Partial
SOC snippet: Motivates fairness/accountability/trust/interpretability concerns in high-stakes domains (hiring, healthcare, law enforcement). Discusses that human involvement can improve trust and accountability but also introduces risk of misuse or biased interventions; recommends responsible choice of user and auditability via logs.
Spec explicitness/testability: Explicit + testable
Spec snippet: Defines bias as unfair causal effect of sensitive attribute on outcome (direct path = disparate treatment; indirect via proxy = disparate impact) and operationalizes mitigation as deleting/weakening unfair causal edges. Provides explicit computation procedures for fairness/utility/distortion metrics and for simulating debiased data (Algorithm 1/2, Eq. 2).
Specification format: Constraint (formal/informal), Other
Specification present: Yes
Stakeholders Mentioned: Affected groups, Auditors/Compliance, Developers, Org leadership, Other, Users
Study ID: P061
System Type: Decision support
Thresholds stated: No
Trade-offs managed: Yes
Validation method: Offline evaluation, User study
Validation snippet: Evaluates D-BIAS on three datasets (Synthetic Hiring, Adult Income, COMPAS) and reports improvements across multiple fairness metrics with small utility loss and limited distortion; also conducts a controlled user study (n=10) comparing against a baseline tool on usability, interpretability, accountability, and trust.
Validation/testing present: Yes
Venue Type: Journal
Year: 2023